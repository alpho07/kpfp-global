-- Adminer 4.8.1 MySQL 8.0.42-0ubuntu0.24.10.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `kpfp` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `kpfp`;

DROP TABLE IF EXISTS `academic_history`;
CREATE TABLE `academic_history` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `academic_university` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_start_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_completion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_diplomas` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `academic_history_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `academic_history` (`id`, `checklist`, `application_id`, `scholarship_id`, `academic_university`, `academic_start_date`, `academic_completion`, `academic_diplomas`, `institution_id`, `created_at`, `updated_at`) VALUES
(5,	1,	49,	18,	'Cillum et dolor quib',	'10-May-2018',	'Ducimus dicta quibu',	'Doloremque est sint',	NULL,	'2025-05-14 11:49:39',	'2025-05-14 11:49:39'),
(6,	1,	49,	18,	'Debitis eius quaerat',	'22-Sep-1999',	'Soluta suscipit labo',	'Repudiandae molestia',	NULL,	'2025-05-14 11:49:39',	'2025-05-14 11:49:39'),
(7,	1,	49,	18,	'Eaque iusto dolores',	'24-Jan-2017',	'Qui lorem aperiam in',	'Sed dolorem perspici',	NULL,	'2025-05-14 11:49:39',	'2025-05-14 11:49:39'),
(8,	1,	49,	18,	'Amet quis eos culp',	'23-Jun-2008',	'Rem culpa labore nem',	'Eveniet ipsum inci',	NULL,	'2025-05-14 11:49:39',	'2025-05-14 11:49:39'),
(9,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44'),
(10,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44'),
(11,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44'),
(12,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44'),
(45,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22'),
(46,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22'),
(47,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22'),
(48,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22'),
(281,	4,	19,	28,	'Sit aut qui aut mag',	'28-Oct-2015',	'Ullam odit quibusdam',	'Deleniti incidunt q',	NULL,	'2025-05-20 15:47:54',	'2025-05-20 15:47:54'),
(282,	4,	19,	28,	'Enim tempora omnis e',	'21-Oct-2013',	'Sint non enim hic di',	'Adipisci omnis conse',	NULL,	'2025-05-20 15:47:54',	'2025-05-20 15:47:54'),
(283,	4,	19,	28,	'Tempor neque nihil s',	'01-Mar-1977',	'Harum rerum amet re',	'Ut assumenda minus q',	NULL,	'2025-05-20 15:47:54',	'2025-05-20 15:47:54'),
(284,	4,	19,	28,	'Inventore amet rem',	'27-Feb-2010',	'In voluptas impedit',	'Cillum nihil neque l',	NULL,	'2025-05-20 15:47:54',	'2025-05-20 15:47:54'),
(409,	5,	19,	30,	'Sunt nesciunt est',	'25-Jul-1998',	'Quos in cupiditate c',	'Amet maiores molest',	NULL,	'2025-05-21 03:57:53',	'2025-05-21 03:57:53'),
(410,	5,	19,	30,	'Veniam non laborum',	'13-Jul-2015',	'Est eu eum a volupta',	'Modi mollitia commod',	NULL,	'2025-05-21 03:57:53',	'2025-05-21 03:57:53'),
(411,	5,	19,	30,	'Numquam quisquam nos',	'23-Jan-1981',	'Duis consequat Sit',	'At qui sapiente temp',	NULL,	'2025-05-21 03:57:53',	'2025-05-21 03:57:53'),
(412,	5,	19,	30,	'Non provident harum',	'11-Sep-2024',	'Repudiandae itaque s',	'Mollitia ex exceptur',	NULL,	'2025-05-21 03:57:53',	'2025-05-21 03:57:53');

DROP TABLE IF EXISTS `applicants_uploads`;
CREATE TABLE `applicants_uploads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `document_id` int NOT NULL,
  `course_id` int NOT NULL,
  `institution_id` int NOT NULL,
  `file_path` longtext NOT NULL,
  `version` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `applicants_uploads` (`id`, `student_id`, `document_id`, `course_id`, `institution_id`, `file_path`, `version`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	49,	1,	18,	9,	'files/personal_documents/9/18/49_Maya_/49_Maya__application_letter_1_v1.pdf',	1,	'2025-05-14 11:48:10',	'2025-05-14 11:48:10',	NULL),
(2,	49,	2,	18,	9,	'files/personal_documents/9/18/49_Maya_/49_Maya__cv_2_v1.pdf',	1,	'2025-05-14 11:48:32',	'2025-05-14 11:48:32',	NULL),
(3,	49,	3,	18,	9,	'files/personal_documents/9/18/49_Maya_/49_Maya__certificates_3_v1.pdf',	1,	'2025-05-14 11:48:44',	'2025-05-14 11:48:44',	NULL),
(4,	49,	4,	18,	9,	'files/personal_documents/9/18/49_Maya_/49_Maya__national_id_4_v1.pdf',	1,	'2025-05-14 11:48:56',	'2025-05-14 11:48:56',	NULL),
(5,	49,	15,	18,	9,	'files/personal_documents/9/18/49_Maya /49_Maya _signed_pre_auth_form_15_v1.pdf',	1,	'2025-05-14 11:50:40',	'2025-05-14 11:50:40',	NULL),
(6,	49,	16,	18,	9,	'files/personal_documents/9/18/49_Maya /49_Maya _blank_or_raw_bonding_form_16_v1.pdf',	1,	'2025-05-14 11:55:24',	'2025-05-14 11:55:24',	NULL),
(7,	49,	17,	18,	9,	'files/personal_documents/9/18/49_Maya /49_Maya _fully_filled_bonding_and_form_17_v1.zip',	1,	'2025-05-14 11:56:35',	'2025-05-14 11:56:35',	NULL),
(8,	50,	2,	7,	8,	'files/personal_documents/8/7/50_MAHTHIR_/50_MAHTHIR__cv_2_v1.pdf',	1,	'2025-05-14 14:37:35',	'2025-05-14 14:37:35',	NULL),
(9,	50,	4,	7,	8,	'files/personal_documents/8/7/50_MAHTHIR_/50_MAHTHIR__national_id_4_v1.pdf',	1,	'2025-05-14 14:38:23',	'2025-05-14 14:38:23',	NULL),
(10,	50,	3,	7,	8,	'files/personal_documents/8/7/50_MAHTHIR_/50_MAHTHIR__certificates_3_v1.pdf',	1,	'2025-05-14 14:38:53',	'2025-05-14 14:38:53',	NULL),
(11,	50,	4,	7,	8,	'files/personal_documents/8/7/50_MAHTHIR_/50_MAHTHIR__national_id_4_v2.pdf',	2,	'2025-05-14 14:39:43',	'2025-05-14 14:39:43',	NULL),
(12,	19,	1,	28,	5,	'files/personal_documents/5/28/19_Super_/19_Super__application_letter_1_v1.pdf',	1,	'2025-05-20 15:26:33',	'2025-05-20 15:26:33',	NULL),
(13,	19,	2,	28,	5,	'files/personal_documents/5/28/19_Super_/19_Super__cv_2_v1.pdf',	1,	'2025-05-20 15:27:25',	'2025-05-20 15:27:25',	NULL),
(14,	19,	3,	28,	5,	'files/personal_documents/5/28/19_Super_/19_Super__certificates_3_v1.pdf',	1,	'2025-05-20 15:27:33',	'2025-05-20 15:27:33',	NULL),
(15,	19,	4,	28,	5,	'files/personal_documents/5/28/19_Super_/19_Super__national_id_4_v1.pdf',	1,	'2025-05-20 15:27:41',	'2025-05-20 15:27:41',	NULL),
(16,	19,	1,	30,	5,	'files/personal_documents/5/30/19_Super_/19_Super__application_letter_1_v1.pdf',	1,	'2025-05-21 03:38:24',	'2025-05-21 03:38:24',	NULL),
(17,	19,	2,	30,	5,	'files/personal_documents/5/30/19_Super_/19_Super__cv_2_v1.pdf',	1,	'2025-05-21 03:46:14',	'2025-05-21 03:46:14',	NULL),
(18,	19,	3,	30,	5,	'files/personal_documents/5/30/19_Super_/19_Super__certificates_3_v1.pdf',	1,	'2025-05-21 03:46:23',	'2025-05-21 03:46:23',	NULL),
(19,	19,	4,	30,	5,	'files/personal_documents/5/30/19_Super_/19_Super__national_id_4_v1.pdf',	1,	'2025-05-21 03:51:13',	'2025-05-21 03:51:13',	NULL),
(20,	19,	1,	30,	5,	'files/personal_documents/5/30/19_Super_/19_Super__application_letter_1_v2.pdf',	2,	'2025-05-21 03:55:02',	'2025-05-21 03:55:02',	NULL),
(21,	19,	2,	30,	5,	'files/personal_documents/5/30/19_Super_/19_Super__cv_2_v2.pdf',	2,	'2025-05-21 03:55:26',	'2025-05-21 03:55:26',	NULL),
(22,	19,	3,	30,	5,	'files/personal_documents/5/30/19_Super_/19_Super__certificates_3_v2.pdf',	2,	'2025-05-21 03:57:20',	'2025-05-21 03:57:20',	NULL),
(23,	19,	14,	30,	5,	'files/personal_documents/5/30/19_Super /19_Super _proof_of_payment_14_v1.pdf',	1,	'2025-05-21 04:21:28',	'2025-05-21 04:21:28',	NULL),
(24,	19,	17,	30,	5,	'files/personal_documents/5/30/19_Super /19_Super _fully_filled_bonding_and_form_17_v1.pdf',	1,	'2025-05-21 04:31:03',	'2025-05-21 04:31:03',	NULL);

DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `application_date` date DEFAULT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preffered_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `county` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `town_city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `affiliated_hospital` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `years_worked` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preauth_inst_no_of_work_yrs` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `national_id_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monthly_salary` double(8,2) DEFAULT NULL,
  `phone_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `age_years` int DEFAULT NULL,
  `date_to_begin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `speciality` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_institution_with` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `funding_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `funding_source_yes_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supervisor_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supervisor_full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supervisor_designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supervisor_phone_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supervisor_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supervisor_department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_surname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_first_contact_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_secondcontact_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_relationship` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorized` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verification_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorized_form` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Not Uploaded',
  `short_listing_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `short_listed_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonding_form` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Not Sent',
  `stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0%',
  `comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `verified_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_verified` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'No',
  `proof_of_payment` int DEFAULT NULL,
  `release_and_bonding_form` int DEFAULT '0',
  `institution_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `applications` (`id`, `checklist`, `application_id`, `scholarship_id`, `application_date`, `first_name`, `surname`, `preffered_name`, `country`, `county`, `town_city`, `affiliated_hospital`, `years_worked`, `preauth_inst_no_of_work_yrs`, `license_no`, `registration_no`, `national_id_pass`, `job_group`, `monthly_salary`, `phone_no`, `email_`, `gender`, `date_of_birth`, `age_years`, `date_to_begin`, `speciality`, `training_institution_with`, `funding_source`, `funding_source_yes_desc`, `supervisor_title`, `supervisor_full_name`, `supervisor_designation`, `supervisor_phone_no`, `supervisor_email`, `supervisor_department`, `emergency_first_name`, `emergency_surname`, `emergency_title`, `emergency_first_contact_no`, `emergency_secondcontact_no`, `emergency_email`, `emergency_relationship`, `reference_previous_1`, `reference_previous_2`, `reference_previous_3`, `authorized`, `verification_status`, `authorized_form`, `short_listing_status`, `short_listed_by`, `bonding_form`, `stage`, `comments`, `status`, `verified_by`, `payment_verified`, `proof_of_payment`, `release_and_bonding_form`, `institution_id`, `created_at`, `updated_at`) VALUES
(1,	1,	49,	18,	'2025-05-14',	'Charlotte',	'Carpenter',	'Blair Cox',	'Kenya',	'turkana',	'Velit iusto ut obcae',	'Exercitation sit re',	'1973',	'Dolor ex dolor sunt',	'Ea ullamco dolore ve',	'Quae cupiditate ab a',	'At magnam at sint hi',	'Culpa eligendi id fu',	6.00,	'+1 (687) 343-6714',	'lulu@mailinator.com',	'male',	'2004-01-15',	21,	'14-Jun-2021',	'Excepteur fugiat au',	'Soluta est dolor su',	'No',	'95',	'Dolorem incididunt i',	'Sierra Griffin',	'Ullamco quasi invent',	'+1 (175) 434-4425',	'vicanynyp@mailinator.com',	'Ut nulla molestias n',	'Kato',	'Dyer',	'Sed eum ut eaque dol',	'Iure rerum voluptate',	'Aute aliqua Veniam',	'zekyxefy@mailinator.com',	'Officia nemo culpa',	'no',	'no',	'no',	NULL,	NULL,	'5',	'None',	NULL,	'6',	'100%',	NULL,	'Selected',	NULL,	'No',	NULL,	7,	NULL,	'2025-05-14 11:49:35',	'2025-05-14 11:56:35'),
(2,	2,	19,	3,	'2025-05-14',	'Super',	NULL,	NULL,	'Kenya',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'super@admin.com',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'Not Uploaded',	'None',	NULL,	'Not Sent',	'0%',	NULL,	'Pending',	NULL,	'No',	NULL,	0,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44'),
(3,	3,	50,	7,	'2025-05-14',	'MAHTHIR',	'MOHAMED',	'SHEIKH',	'Kenya',	'machakos',	'Machakos',	'Muumandu Health Center -machakos county',	'2',	'3',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'mahthirgalgalo11@gmail.com',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'Not Uploaded',	'None',	NULL,	'Not Sent',	'0%',	NULL,	'Pending',	NULL,	'No',	NULL,	0,	NULL,	'2025-05-14 14:33:21',	'2025-05-14 14:42:22'),
(4,	4,	19,	28,	'2025-05-20',	'Rafael',	'Mullen',	'Sebastian Fox',	'Kenya',	'taita taveta',	'Est dolores qui lab',	'Eu aute odio omnis e',	'1977',	'Enim est sunt nost',	'Incidunt libero aut',	'In quia dolor est fa',	'Velit quidem aliquid',	'Saepe in ducimus in',	2.00,	'+1 (618) 344-4401',	'pydixibu@mailinator.com',	'male',	'2016-01-19',	9,	'2025-05-15',	'Ipsum commodo id sit',	'Tenetur consequatur',	'No',	'67',	'Eum nobis sint harum',	'Abbot Wolf',	'Quaerat magna in vol',	'+1 (409) 397-1677',	'tady@mailinator.com',	'Nulla necessitatibus',	'Edan',	'Thornton',	'Quia dolores neque e',	'Vel similique exerci',	'Accusamus dignissimo',	'toxuqofu@mailinator.com',	'Odio exercitationem',	'yes',	'no',	'yes',	NULL,	NULL,	'Not Uploaded',	'None',	NULL,	'Not Sent',	'25%',	NULL,	'Pending',	NULL,	'No',	NULL,	0,	NULL,	'2025-05-20 15:13:52',	'2025-05-20 15:48:08'),
(5,	5,	19,	30,	'2025-05-21',	'Philip',	'Hughes',	'Sloane Rodgers',	'Kenya',	'muranga',	'Exercitationem autem',	'Autem aut aut et exe',	'1981',	'Modi culpa non veri',	'Eum alias similique',	'Illo officia volupta',	'Animi expedita iust',	'Cupiditate consequat',	12.00,	'+1 (398) 338-8738',	'syrehet@mailinator.com',	'female',	'2016-01-19',	9,	'08-Sep-2018',	'Minim illo dicta quo',	'Et lorem ut sed labo',	'No',	'26',	'Veniam sint ea tem',	'Kiona Potter',	'Possimus unde non i',	'+1 (533) 275-2139',	'botulebi@mailinator.com',	'Iusto dolorem dolor',	'Ima',	'Barnes',	'Dolore facilis aut u',	'Ad cum sit eos volup',	'Earum tempor consect',	'jicugadok@mailinator.com',	'Aperiam temporibus d',	'yes',	'no',	'no',	NULL,	NULL,	'Not Uploaded',	'None',	NULL,	'Not Sent',	'50%',	NULL,	'Pending',	NULL,	'No',	23,	24,	NULL,	'2025-05-21 03:38:57',	'2025-05-21 04:31:03');

DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('123456|92.255.57.103',	'i:1;',	1745371441),
('123456|92.255.57.103:timer',	'i:1745371441;',	1745371441),
('admin@gettingrealagain.com|80.64.30.32',	'i:1;',	1745374634),
('admin@gettingrealagain.com|80.64.30.32:timer',	'i:1745374634;',	1745374634),
('admin@gettingrealagain.com|92.255.57.103',	'i:1;',	1745371525),
('admin@gettingrealagain.com|92.255.57.103:timer',	'i:1745371525;',	1745371525),
('admin|80.64.30.32',	'i:2;',	1745375138),
('admin|80.64.30.32:timer',	'i:1745375137;',	1745375137),
('admin|92.255.57.103',	'i:1;',	1745371649),
('admin|92.255.57.103:timer',	'i:1745371649;',	1745371649),
('alpho07@gmail.com|197.232.156.209',	'i:1;',	1747228653),
('alpho07@gmail.com|197.232.156.209:timer',	'i:1747228653;',	1747228653),
('brightshamil@gmail.com|102.215.79.226',	'i:1;',	1747167674),
('brightshamil@gmail.com|102.215.79.226:timer',	'i:1747167674;',	1747167674),
('demo|80.64.30.32',	'i:1;',	1745374918),
('demo|80.64.30.32:timer',	'i:1745374918;',	1745374918),
('editor|80.64.30.32',	'i:1;',	1745374665),
('editor|80.64.30.32:timer',	'i:1745374665;',	1745374665),
('gettingrealagain|80.64.30.32',	'i:1;',	1745375041),
('gettingrealagain|80.64.30.32:timer',	'i:1745375041;',	1745375041),
('gettingrealagain|92.255.57.103',	'i:1;',	1745371147),
('gettingrealagain|92.255.57.103:timer',	'i:1745371147;',	1745371147),
('jq123456|92.255.57.103',	'i:1;',	1745371433),
('jq123456|92.255.57.103:timer',	'i:1745371433;',	1745371433),
('jqadmin@gettingrealagain.com|80.64.30.32',	'i:1;',	1745374627),
('jqadmin@gettingrealagain.com|80.64.30.32:timer',	'i:1745374627;',	1745374627),
('jqadmin@gettingrealagain.com|92.255.57.103',	'i:1;',	1745371517),
('jqadmin@gettingrealagain.com|92.255.57.103:timer',	'i:1745371517;',	1745371517),
('jqadmin|80.64.30.32',	'i:2;',	1745375130),
('jqadmin|80.64.30.32:timer',	'i:1745375130;',	1745375130),
('jqadmin|92.255.57.103',	'i:1;',	1745371642),
('jqadmin|92.255.57.103:timer',	'i:1745371642;',	1745371642),
('jqdemo|80.64.30.32',	'i:1;',	1745374911),
('jqdemo|80.64.30.32:timer',	'i:1745374911;',	1745374911),
('jqeditor|80.64.30.32',	'i:1;',	1745374658),
('jqeditor|80.64.30.32:timer',	'i:1745374658;',	1745374658),
('jqgettingrealagain|80.64.30.32',	'i:1;',	1745375034),
('jqgettingrealagain|80.64.30.32:timer',	'i:1745375034;',	1745375034),
('jqgettingrealagain|92.255.57.103',	'i:1;',	1745371140),
('jqgettingrealagain|92.255.57.103:timer',	'i:1745371140;',	1745371140),
('jqmanager|80.64.30.32',	'i:1;',	1745374880),
('jqmanager|80.64.30.32:timer',	'i:1745374880;',	1745374880),
('jqsupport|80.64.30.32',	'i:1;',	1745374972),
('jqsupport|80.64.30.32:timer',	'i:1745374972;',	1745374972),
('jqtest|80.64.30.32',	'i:1;',	1745374848),
('jqtest|80.64.30.32:timer',	'i:1745374848;',	1745374848),
('jqtesting|80.64.30.32',	'i:1;',	1745374942),
('jqtesting|80.64.30.32:timer',	'i:1745374942;',	1745374942),
('mahthirgalgalo11@gmail.com|154.159.252.194',	'i:1;',	1747233006),
('mahthirgalgalo11@gmail.com|154.159.252.194:timer',	'i:1747233006;',	1747233006),
('manager|80.64.30.32',	'i:1;',	1745374887),
('manager|80.64.30.32:timer',	'i:1745374887;',	1745374887),
('nniirrcn@formtest.guru|104.23.187.205',	'i:1;',	1744764140),
('nniirrcn@formtest.guru|104.23.187.205:timer',	'i:1744764140;',	1744764140),
('nniirrcn@formtest.guru|104.23.187.236',	'i:1;',	1744764141),
('nniirrcn@formtest.guru|104.23.187.236:timer',	'i:1744764141;',	1744764141),
('nniirrcn@formtest.guru|104.23.190.134',	'i:1;',	1744764139),
('nniirrcn@formtest.guru|104.23.190.134:timer',	'i:1744764139;',	1744764139),
('nniirrcn@formtest.guru|162.158.154.165',	'i:1;',	1744764139),
('nniirrcn@formtest.guru|162.158.154.165:timer',	'i:1744764139;',	1744764139),
('nniirrcn@formtest.guru|162.158.154.174',	'i:1;',	1744764140),
('nniirrcn@formtest.guru|162.158.154.174:timer',	'i:1744764140;',	1744764140),
('nniirrcn@formtest.guru|172.70.230.67',	'i:1;',	1744764141),
('nniirrcn@formtest.guru|172.70.230.67:timer',	'i:1744764141;',	1744764141),
('root|197.232.156.209',	'i:1;',	1747045242),
('root|197.232.156.209:timer',	'i:1747045242;',	1747045242),
('spatie.permission.cache',	'a:3:{s:5:\"alias\";a:3:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";}s:11:\"permissions\";a:43:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:22:\"user_management_access\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:17:\"permission_create\";s:1:\"c\";s:3:\"web\";}i:2;a:3:{s:1:\"a\";i:3;s:1:\"b\";s:15:\"permission_edit\";s:1:\"c\";s:3:\"web\";}i:3;a:3:{s:1:\"a\";i:4;s:1:\"b\";s:15:\"permission_show\";s:1:\"c\";s:3:\"web\";}i:4;a:3:{s:1:\"a\";i:5;s:1:\"b\";s:17:\"permission_delete\";s:1:\"c\";s:3:\"web\";}i:5;a:3:{s:1:\"a\";i:6;s:1:\"b\";s:17:\"permission_access\";s:1:\"c\";s:3:\"web\";}i:6;a:3:{s:1:\"a\";i:7;s:1:\"b\";s:11:\"role_create\";s:1:\"c\";s:3:\"web\";}i:7;a:3:{s:1:\"a\";i:8;s:1:\"b\";s:9:\"role_edit\";s:1:\"c\";s:3:\"web\";}i:8;a:3:{s:1:\"a\";i:9;s:1:\"b\";s:9:\"role_show\";s:1:\"c\";s:3:\"web\";}i:9;a:3:{s:1:\"a\";i:10;s:1:\"b\";s:11:\"role_delete\";s:1:\"c\";s:3:\"web\";}i:10;a:3:{s:1:\"a\";i:11;s:1:\"b\";s:11:\"role_access\";s:1:\"c\";s:3:\"web\";}i:11;a:3:{s:1:\"a\";i:12;s:1:\"b\";s:11:\"user_create\";s:1:\"c\";s:3:\"web\";}i:12;a:3:{s:1:\"a\";i:13;s:1:\"b\";s:9:\"user_edit\";s:1:\"c\";s:3:\"web\";}i:13;a:3:{s:1:\"a\";i:14;s:1:\"b\";s:9:\"user_show\";s:1:\"c\";s:3:\"web\";}i:14;a:3:{s:1:\"a\";i:15;s:1:\"b\";s:11:\"user_delete\";s:1:\"c\";s:3:\"web\";}i:15;a:3:{s:1:\"a\";i:16;s:1:\"b\";s:11:\"user_access\";s:1:\"c\";s:3:\"web\";}i:16;a:3:{s:1:\"a\";i:17;s:1:\"b\";s:17:\"discipline_create\";s:1:\"c\";s:3:\"web\";}i:17;a:3:{s:1:\"a\";i:18;s:1:\"b\";s:15:\"discipline_edit\";s:1:\"c\";s:3:\"web\";}i:18;a:3:{s:1:\"a\";i:19;s:1:\"b\";s:15:\"discipline_show\";s:1:\"c\";s:3:\"web\";}i:19;a:3:{s:1:\"a\";i:20;s:1:\"b\";s:17:\"discipline_delete\";s:1:\"c\";s:3:\"web\";}i:20;a:3:{s:1:\"a\";i:21;s:1:\"b\";s:17:\"discipline_access\";s:1:\"c\";s:3:\"web\";}i:21;a:3:{s:1:\"a\";i:22;s:1:\"b\";s:18:\"institution_create\";s:1:\"c\";s:3:\"web\";}i:22;a:3:{s:1:\"a\";i:23;s:1:\"b\";s:16:\"institution_edit\";s:1:\"c\";s:3:\"web\";}i:23;a:3:{s:1:\"a\";i:24;s:1:\"b\";s:16:\"institution_show\";s:1:\"c\";s:3:\"web\";}i:24;a:3:{s:1:\"a\";i:25;s:1:\"b\";s:18:\"institution_delete\";s:1:\"c\";s:3:\"web\";}i:25;a:3:{s:1:\"a\";i:26;s:1:\"b\";s:18:\"institution_access\";s:1:\"c\";s:3:\"web\";}i:26;a:3:{s:1:\"a\";i:27;s:1:\"b\";s:13:\"course_create\";s:1:\"c\";s:3:\"web\";}i:27;a:3:{s:1:\"a\";i:28;s:1:\"b\";s:11:\"course_edit\";s:1:\"c\";s:3:\"web\";}i:28;a:3:{s:1:\"a\";i:29;s:1:\"b\";s:11:\"course_show\";s:1:\"c\";s:3:\"web\";}i:29;a:3:{s:1:\"a\";i:30;s:1:\"b\";s:13:\"course_delete\";s:1:\"c\";s:3:\"web\";}i:30;a:3:{s:1:\"a\";i:31;s:1:\"b\";s:13:\"course_access\";s:1:\"c\";s:3:\"web\";}i:31;a:3:{s:1:\"a\";i:32;s:1:\"b\";s:17:\"enrollment_create\";s:1:\"c\";s:3:\"web\";}i:32;a:3:{s:1:\"a\";i:33;s:1:\"b\";s:15:\"enrollment_edit\";s:1:\"c\";s:3:\"web\";}i:33;a:3:{s:1:\"a\";i:34;s:1:\"b\";s:15:\"enrollment_show\";s:1:\"c\";s:3:\"web\";}i:34;a:3:{s:1:\"a\";i:35;s:1:\"b\";s:17:\"enrollment_delete\";s:1:\"c\";s:3:\"web\";}i:35;a:3:{s:1:\"a\";i:36;s:1:\"b\";s:17:\"enrollment_access\";s:1:\"c\";s:3:\"web\";}i:36;a:3:{s:1:\"a\";i:37;s:1:\"b\";s:9:\"full_menu\";s:1:\"c\";s:3:\"web\";}i:37;a:3:{s:1:\"a\";i:38;s:1:\"b\";s:12:\"list_USERS_1\";s:1:\"c\";s:3:\"web\";}i:38;a:3:{s:1:\"a\";i:39;s:1:\"b\";s:11:\"super_user2\";s:1:\"c\";s:3:\"web\";}i:39;a:3:{s:1:\"a\";i:40;s:1:\"b\";s:15:\"finance_manager\";s:1:\"c\";s:3:\"web\";}i:40;a:3:{s:1:\"a\";i:41;s:1:\"b\";s:19:\"application_manager\";s:1:\"c\";s:3:\"web\";}i:41;a:3:{s:1:\"a\";i:43;s:1:\"b\";s:19:\"institution_access_\";s:1:\"c\";s:3:\"web\";}i:42;a:3:{s:1:\"a\";i:44;s:1:\"b\";s:15:\"all_file_filter\";s:1:\"c\";s:3:\"web\";}}s:5:\"roles\";a:0:{}}',	1747822941),
('support|80.64.30.32',	'i:1;',	1745374979),
('support|80.64.30.32:timer',	'i:1745374979;',	1745374979),
('test|80.64.30.32',	'i:1;',	1745374855),
('test|80.64.30.32:timer',	'i:1745374855;',	1745374855),
('testing|80.64.30.32',	'i:1;',	1745374949),
('testing|80.64.30.32:timer',	'i:1745374949;',	1745374949),
('zoho_access_token',	's:70:\"1000.b9f8c64f4e8e38bbdf1238f5776b0d1d.9ed3ce288bbcf57aa9af4145e304b8a1\";',	1747803389);

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `checklists`;
CREATE TABLE `checklists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `application_id` bigint NOT NULL,
  `scholarship_id` bigint NOT NULL,
  `aof_govt` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `aof_ea` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `commitment` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `not_beneficiary` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `completed_application` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `personal_statement` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cv` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `certs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `national_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `checklists_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `checklists` (`id`, `application_id`, `scholarship_id`, `aof_govt`, `aof_ea`, `commitment`, `not_beneficiary`, `completed_application`, `personal_statement`, `cv`, `certs`, `national_id`, `created_at`, `updated_at`, `deleted_at`, `course_id`, `institution_id`) VALUES
(1,	49,	18,	'on',	NULL,	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 11:47:56',	'2025-05-14 11:47:56',	NULL,	NULL,	9),
(2,	19,	3,	'on',	NULL,	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:12',	'2025-05-14 13:17:12',	NULL,	NULL,	4),
(3,	50,	7,	'on',	NULL,	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:32:50',	'2025-05-14 14:32:50',	NULL,	NULL,	8),
(4,	19,	28,	'on',	NULL,	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-20 15:13:19',	'2025-05-20 15:43:40',	NULL,	NULL,	5),
(5,	19,	30,	'on',	'on',	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-21 03:38:06',	'2025-05-21 03:38:06',	NULL,	NULL,	5);

DROP TABLE IF EXISTS `course_application`;
CREATE TABLE `course_application` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `student_id` int NOT NULL,
  `year` int NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `sponsorship_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `payment_verified` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'pending',
  `sponsorship_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_application_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `course_category`;
CREATE TABLE `course_category` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_category_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_category` (`id`, `name`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	'Higher National Diploma',	'2025-05-02 06:49:58',	'2025-05-02 06:49:58',	NULL),
(2,	'POST-MMED',	'2025-05-02 06:54:37',	'2025-05-02 06:54:37',	NULL),
(3,	'Certificate',	'2025-05-02 07:31:34',	'2025-05-02 07:31:34',	NULL);

DROP TABLE IF EXISTS `course_discipline`;
CREATE TABLE `course_discipline` (
  `course_id` int unsigned DEFAULT NULL,
  `discipline_id` int unsigned DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  KEY `course_id_fk_538846` (`course_id`),
  KEY `discipline_id_fk_538846` (`discipline_id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_discipline_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`),
  CONSTRAINT `course_id_fk_538846` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `discipline_id_fk_538846` FOREIGN KEY (`discipline_id`) REFERENCES `disciplines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_discipline` (`course_id`, `discipline_id`, `institution_id`) VALUES
(7,	1,	NULL),
(8,	1,	NULL),
(9,	1,	NULL),
(10,	1,	NULL),
(11,	1,	NULL),
(12,	1,	NULL),
(13,	1,	NULL),
(14,	1,	NULL),
(15,	1,	NULL),
(16,	1,	NULL),
(17,	1,	NULL),
(18,	1,	NULL),
(19,	1,	NULL),
(20,	1,	NULL),
(21,	1,	NULL),
(22,	1,	NULL),
(23,	1,	NULL),
(24,	1,	NULL),
(25,	1,	NULL),
(26,	1,	NULL),
(27,	1,	NULL),
(28,	1,	NULL),
(29,	1,	NULL),
(30,	1,	NULL),
(31,	1,	NULL),
(32,	1,	NULL),
(33,	1,	NULL),
(34,	1,	NULL),
(35,	1,	NULL),
(1,	1,	NULL),
(2,	1,	NULL),
(3,	1,	NULL),
(4,	1,	NULL),
(5,	1,	NULL),
(6,	1,	NULL);

DROP TABLE IF EXISTS `course_manager`;
CREATE TABLE `course_manager` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sponsor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `month_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  `application_start_date` date DEFAULT NULL,
  `application_end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_manager_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_manager` (`id`, `name`, `sponsor`, `category_id`, `month_id`, `created_at`, `updated_at`, `institution_id`, `application_start_date`, `application_end_date`) VALUES
(1,	'Paediatric Critical Care Nursing (PCCN)',	NULL,	1,	2,	'2025-05-02 07:33:19',	'2025-05-02 07:33:19',	NULL,	NULL,	NULL),
(2,	'Paediatric Nursing (PNT)',	NULL,	1,	2,	'2025-05-02 07:42:02',	'2025-05-02 07:42:02',	NULL,	NULL,	NULL),
(3,	'Midwifery',	NULL,	1,	1,	'2025-05-02 07:42:15',	'2025-05-02 07:42:15',	NULL,	NULL,	NULL),
(4,	'Neonatal Nursing',	NULL,	1,	2,	'2025-05-02 07:42:28',	'2025-05-02 07:42:28',	NULL,	NULL,	NULL),
(5,	'Paediatric Oncology Nursing',	NULL,	1,	2,	'2025-05-02 07:42:43',	'2025-05-02 07:42:43',	NULL,	NULL,	NULL),
(6,	'Ophthalmology and cataract surgery',	NULL,	1,	2,	'2025-05-02 07:42:58',	'2025-05-02 07:42:58',	NULL,	NULL,	NULL),
(7,	'Audiology and hearing technology',	NULL,	1,	2,	'2025-05-02 07:43:12',	'2025-05-02 07:43:12',	NULL,	NULL,	NULL),
(8,	'Orthopaedic technology specialisation in  prosthetics/orthotics',	NULL,	1,	2,	'2025-05-02 07:43:24',	'2025-05-02 07:43:24',	NULL,	NULL,	NULL),
(9,	'Ophthalmology advanced refraction and low vision',	NULL,	1,	2,	'2025-05-02 07:43:36',	'2025-05-02 07:43:36',	NULL,	NULL,	NULL),
(10,	'Speech and language therapy',	NULL,	1,	2,	'2025-05-02 07:43:55',	'2025-05-02 07:43:55',	NULL,	NULL,	NULL),
(11,	'Low vision and assistive technology',	NULL,	1,	2,	'2025-05-02 07:44:19',	'2025-05-02 07:44:19',	NULL,	NULL,	NULL),
(12,	'Neonatology',	NULL,	2,	2,	'2025-05-02 07:44:50',	'2025-05-02 07:44:50',	NULL,	NULL,	NULL),
(13,	'Paediatric Neurology',	NULL,	2,	2,	'2025-05-02 07:45:04',	'2025-05-02 07:45:04',	NULL,	NULL,	NULL),
(14,	'Paediatric Emergency & Critical Care Medicine',	NULL,	2,	2,	'2025-05-02 07:45:22',	'2025-05-02 07:45:22',	NULL,	NULL,	NULL),
(15,	'Paediatric Endocrinology',	NULL,	2,	2,	'2025-05-02 07:45:37',	'2025-05-02 07:45:37',	NULL,	NULL,	NULL),
(16,	'Paediatric Haemato-oncology',	NULL,	2,	2,	'2025-05-02 07:45:48',	'2025-05-02 07:45:48',	NULL,	NULL,	NULL),
(17,	'Paediatric Clinical Infectious Diseases',	NULL,	2,	2,	'2025-05-02 07:46:11',	'2025-05-20 10:49:23',	NULL,	'2025-05-20',	'2025-06-27'),
(18,	'Paediatric Gastroenterology',	NULL,	2,	2,	'2025-05-02 07:46:27',	'2025-05-02 07:51:00',	NULL,	NULL,	NULL),
(19,	'Paediatric Cardiology',	NULL,	2,	2,	'2025-05-02 07:46:51',	'2025-05-02 07:46:51',	NULL,	NULL,	NULL),
(20,	'Paediatric Pulmonology',	NULL,	2,	2,	'2025-05-02 07:47:09',	'2025-05-02 07:47:09',	NULL,	NULL,	NULL),
(21,	'Paediatric Nephrology',	NULL,	2,	2,	'2025-05-02 08:50:02',	'2025-05-02 08:50:02',	NULL,	NULL,	NULL),
(22,	'Test Course',	NULL,	1,	1,	'2025-05-20 10:27:14',	'2025-05-20 10:27:14',	NULL,	'2025-05-20',	'2025-05-30');

DROP TABLE IF EXISTS `course_months`;
CREATE TABLE `course_months` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_months` (`id`, `name`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	'2.5 Years',	'2025-05-02 07:30:52',	'2025-05-02 07:30:52',	NULL),
(2,	'2 Years',	'2025-05-02 07:31:02',	'2025-05-02 07:31:02',	NULL);

DROP TABLE IF EXISTS `course_uploads`;
CREATE TABLE `course_uploads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `national_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nck_lic` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nck_cert` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `kcse_cse` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `passport` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `application_letter` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `dip_deg` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  `institution_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `manager_id` int DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` decimal(15,2) DEFAULT NULL,
  `application_start_date` date DEFAULT NULL,
  `application_end_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_fk_538844` (`institution_id`),
  CONSTRAINT `institution_fk_538844` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `courses` (`id`, `manager_id`, `description`, `price`, `application_start_date`, `application_end_date`, `created_at`, `updated_at`, `deleted_at`, `institution_id`) VALUES
(1,	3,	'<p>Course Description</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:32:41',	'2025-05-02 08:32:41',	NULL,	4),
(2,	12,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:35:07',	'2025-05-02 08:35:07',	NULL,	4),
(3,	13,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:35:31',	'2025-05-02 08:35:31',	NULL,	4),
(4,	18,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:35:50',	'2025-05-02 08:35:50',	NULL,	4),
(5,	19,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:36:20',	'2025-05-02 08:36:20',	NULL,	4),
(6,	20,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:36:42',	'2025-05-02 08:36:42',	NULL,	4),
(7,	1,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:37:08',	'2025-05-02 08:37:08',	NULL,	8),
(8,	2,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:37:22',	'2025-05-02 08:37:22',	NULL,	8),
(9,	5,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:37:39',	'2025-05-02 08:37:39',	NULL,	8),
(10,	6,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:38:01',	'2025-05-02 08:38:01',	NULL,	11),
(11,	7,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:38:17',	'2025-05-02 08:38:17',	NULL,	11),
(12,	8,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:38:32',	'2025-05-02 08:38:32',	NULL,	11),
(13,	9,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:38:49',	'2025-05-02 08:38:49',	NULL,	11),
(14,	10,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:39:06',	'2025-05-02 08:39:06',	NULL,	11),
(15,	11,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:39:18',	'2025-05-02 08:39:18',	NULL,	11),
(16,	4,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:39:44',	'2025-05-02 08:39:44',	NULL,	1),
(18,	5,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:41:59',	'2025-05-02 08:41:59',	NULL,	9),
(19,	12,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:42:48',	'2025-05-02 08:42:48',	NULL,	9),
(20,	13,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:45:26',	'2025-05-02 08:45:26',	NULL,	9),
(21,	14,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:45:41',	'2025-05-02 08:45:41',	NULL,	9),
(22,	16,	'<p>&nbsp;</p>',	NULL,	'2025-06-01',	'2025-07-31',	'2025-05-02 08:45:58',	'2025-05-02 08:45:58',	NULL,	9),
(23,	12,	'<p>&nbsp;</p>',	NULL,	'2025-05-22',	'2025-05-30',	'2025-05-02 08:46:22',	'2025-05-20 11:07:47',	NULL,	5),
(24,	14,	'<p>&nbsp;</p>',	NULL,	'2025-03-05',	'2025-05-05',	'2025-05-02 08:46:40',	'2025-05-20 11:07:11',	NULL,	5),
(25,	15,	'<p>&nbsp;</p>',	NULL,	'2025-04-01',	'2025-05-08',	'2025-05-02 08:47:46',	'2025-05-20 11:04:57',	NULL,	5),
(26,	16,	'<p>&nbsp;</p>',	NULL,	'2025-05-30',	'2025-07-23',	'2025-05-02 08:47:59',	'2025-05-20 11:03:59',	NULL,	5),
(27,	17,	'<p>&nbsp;</p>',	NULL,	'2025-05-29',	'2025-06-26',	'2025-05-02 08:48:15',	'2025-05-20 11:03:36',	NULL,	5),
(28,	18,	'<p>&nbsp;</p>',	NULL,	'2025-04-15',	'2025-07-31',	'2025-05-02 08:48:32',	'2025-05-20 11:03:15',	NULL,	5),
(29,	21,	'<p>&nbsp;</p>',	NULL,	'2025-05-15',	'2025-06-27',	'2025-05-02 08:50:20',	'2025-05-20 11:02:48',	NULL,	5),
(30,	20,	'<p>&nbsp;</p>',	NULL,	'2025-05-01',	'2025-05-30',	'2025-05-02 08:50:38',	'2025-05-20 11:02:20',	NULL,	5),
(31,	2,	'<p>cssds</p>',	NULL,	'2025-05-01',	'2025-05-19',	'2025-05-20 11:25:47',	'2025-05-20 11:25:47',	NULL,	4);

DROP TABLE IF EXISTS `disciplines`;
CREATE TABLE `disciplines` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `disciplines_name_unique` (`name`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `disciplines_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `disciplines` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`, `institution_id`) VALUES
(1,	'Scholarships',	NULL,	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `disclaimer`;
CREATE TABLE `disclaimer` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `disclaimer_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disclaimer_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `disclaimer_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `disclaimer` (`id`, `checklist`, `application_id`, `scholarship_id`, `disclaimer_1`, `disclaimer_2`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	1,	49,	18,	'Agree',	'Agree',	'2025-05-14 11:49:44',	'2025-05-14 11:49:44',	NULL),
(2,	4,	19,	28,	'Agree',	'Agree',	'2025-05-20 15:48:08',	'2025-05-20 15:48:08',	NULL),
(3,	5,	19,	30,	'Agree',	'Agree',	'2025-05-21 03:58:08',	'2025-05-21 03:58:08',	NULL);

DROP TABLE IF EXISTS `employment`;
CREATE TABLE `employment` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `previous_organization` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_organization_from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_organization_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_job_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_supervisor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_responsibilities` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_phone_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `employment_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `employment` (`id`, `checklist`, `application_id`, `scholarship_id`, `previous_organization`, `previous_organization_from`, `reference_previous_organization_to`, `reference_previous_job_title`, `reference_previous_supervisor`, `reference_previous_responsibilities`, `reference_previous_phone_no`, `created_at`, `updated_at`, `institution_id`) VALUES
(4,	1,	49,	18,	'Wilkins and Case Traders',	'1988-05-09',	'1976-01-09',	'Quaerat dignissimos',	'duvytoc@mailinator.com',	'Voluptas adipisicing',	'8',	'2025-05-14 11:49:39',	'2025-05-14 11:49:39',	NULL),
(5,	1,	49,	18,	'Kramer and Alford Trading',	'Bryan Bentley Trading',	'Berger and Brown Co',	'Quis porro cillum vo',	'wohypidup@mailinator.com',	'Similique quibusdam',	'+1 (844) 936-8062',	'2025-05-14 11:49:39',	'2025-05-14 11:49:39',	NULL),
(6,	1,	49,	18,	'Powell Macdonald Inc',	'Langley and Howe Associates',	'Brady Woodward Inc',	'Asperiores rerum exc',	'xevub@mailinator.com',	'Eum at quae perferen',	'66',	'2025-05-14 11:49:39',	'2025-05-14 11:49:39',	NULL),
(7,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44',	NULL),
(8,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44',	NULL),
(9,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44',	NULL),
(34,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22',	NULL),
(35,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22',	NULL),
(36,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22',	NULL),
(211,	4,	19,	28,	'Keller and Decker Associates',	'1973-06-13',	'1980-04-19',	'Quisquam quas invent',	'zetawizur@mailinator.com',	'Ad ut saepe laborios',	'70',	'2025-05-20 15:47:54',	'2025-05-20 15:47:54',	NULL),
(212,	4,	19,	28,	'Manning Peck LLC',	'Vaughan and Bailey Plc',	'Rosales Parks Inc',	'Earum quidem quos di',	'xoji@mailinator.com',	'Est eiusmod sint aut',	'+1 (986) 857-3457',	'2025-05-20 15:47:54',	'2025-05-20 15:47:54',	NULL),
(213,	4,	19,	28,	'Mccormick Lara Plc',	'Underwood Dudley Co',	'Horn and Hughes Inc',	'Ut occaecat quos cor',	'masolupa@mailinator.com',	'Magna dolor eum et q',	'43',	'2025-05-20 15:47:54',	'2025-05-20 15:47:54',	NULL),
(307,	5,	19,	30,	'Hanson and Moran Traders',	'2019-11-25',	'2021-09-26',	'Sequi nisi obcaecati',	'fyqyxum@mailinator.com',	'Aliqua Recusandae',	'12',	'2025-05-21 03:57:53',	'2025-05-21 03:57:53',	NULL),
(308,	5,	19,	30,	'Molina and Hamilton Co',	'Bowers and Lancaster LLC',	'Lindsey and Hodge Associates',	'Non laboriosam dele',	'zigot@mailinator.com',	'Dicta enim voluptate',	'+1 (909) 801-9332',	'2025-05-21 03:57:53',	'2025-05-21 03:57:53',	NULL),
(309,	5,	19,	30,	'Melendez Medina Traders',	'Holmes and Crosby Plc',	'Carson and Barnett Co',	'Totam aut voluptatem',	'dozerepu@mailinator.com',	'Illo harum labore Na',	'14',	'2025-05-21 03:57:53',	'2025-05-21 03:57:53',	NULL);

DROP TABLE IF EXISTS `enrollments`;
CREATE TABLE `enrollments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'awaiting',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `course_id` int unsigned NOT NULL,
  `institution_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_fk_538851` (`user_id`),
  KEY `course_fk_538852` (`course_id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_fk_538852` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`),
  CONSTRAINT `user_fk_538851` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `institutions`;
CREATE TABLE `institutions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `institutions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `institutions` (`id`, `name`, `email`, `phone`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Kenyatta National School of Nursing',	'knhadmin@knh.or.ke',	'+254 020 2726300, +254 709854000, +254 730643000',	'2023-12-09 03:50:17',	'2025-05-06 06:17:25',	NULL),
(3,	'KPFP Scholarships Admin',	'KPFP',	NULL,	'2025-02-06 03:46:45',	'2025-02-06 03:46:45',	NULL),
(4,	'The Aga Khan University',	'mc.ea@aku.edu',	'+254 20 366 2232',	'2025-02-06 03:46:45',	'2025-05-06 06:15:30',	NULL),
(5,	'The University Of Nairobi (UON)',	'info@uonbi.ac.ke',	'(+254) 020-4910000',	'2025-02-06 03:46:45',	'2025-05-06 06:14:22',	NULL),
(8,	'Gertrude\'s Children\'s Hospital',	'trainingschool@gerties.org',	'+254 759 297589',	'2025-01-29 16:10:55',	'2025-05-06 06:12:16',	NULL),
(9,	'MOI University',	'info@mu.ac.ke',	'+254 790 940 508, +254 736 138 770',	'2025-04-02 07:26:42',	'2025-05-06 06:09:53',	NULL),
(11,	'Kenya Medical Training College (KMTC)',	'admissions@kmtc.ac.ke',	'-',	'2025-05-02 04:28:42',	'2025-05-06 06:07:22',	NULL);

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `jobs` (`id`, `queue`, `payload`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
(1,	'default',	'{\"uuid\":\"f3c82792-355a-4324-9ac1-afb76c49320a\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159228,	1746159228),
(2,	'default',	'{\"uuid\":\"4b0e0153-b862-407e-bcde-226515e8bef8\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:2;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159521,	1746159521),
(3,	'default',	'{\"uuid\":\"65872d3c-bd19-44bb-90f5-19d608b21f54\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:3;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159631,	1746159631),
(4,	'default',	'{\"uuid\":\"3d0cf4cc-3866-4a18-b232-6094176fea68\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:4;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159734,	1746159734),
(5,	'default',	'{\"uuid\":\"6544e8b8-2cb7-4fa3-be30-d07d4adcaa7b\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:5;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159908,	1746159908),
(6,	'default',	'{\"uuid\":\"08c42c1c-8227-45ea-944d-87261ce0ba2b\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:6;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159981,	1746159981),
(7,	'default',	'{\"uuid\":\"0463d444-f1d6-48c8-83c6-f8c38ccb2ce7\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746160122,	1746160122);

DROP VIEW IF EXISTS `master_course_app`;
CREATE TABLE `master_course_app` (`id` int, `payment_verified` varchar(20), `course` varchar(255), `category` varchar(255), `period` varchar(267), `status` varchar(20), `phone` varchar(20), `gender` varchar(10), `dob` date, `application_id` int unsigned, `name` varchar(152), `created_at` timestamp, `age` bigint, `national_id` varchar(100), `nck_lic` varchar(100), `nck_cert` varchar(100), `kcse_cse` varchar(100), `passport` varchar(100), `sponsorship_id` varchar(100), `institution_id` int unsigned);


DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_column` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `media_chk_1` CHECK (json_valid(`manipulations`)),
  CONSTRAINT `media_chk_2` CHECK (json_valid(`custom_properties`)),
  CONSTRAINT `media_chk_3` CHECK (json_valid(`responsive_images`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`, `institution_id`) VALUES
(2,	'App\\Models\\Institution',	9,	'5dc1040a-5f33-4012-94b4-d0fc96e7a2b0',	'logo',	'6814479f50a77_Moi_University_logo',	'6814479f50a77_Moi_University_logo.jpg',	'image/jpeg',	'public',	'public',	66098,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:18:41',	'2025-05-02 04:18:41',	NULL),
(3,	'App\\Models\\Institution',	8,	'd4279371-ca59-4775-856c-b837c0bae1e1',	'logo',	'681447f89f49f_gertrudes logo',	'681447f89f49f_gertrudes-logo.png',	'image/png',	'public',	'public',	8522,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:20:31',	'2025-05-02 04:20:31',	NULL),
(4,	'App\\Models\\Institution',	5,	'4b2ae472-7e97-45f4-8f7b-b3b7dfb57e26',	'logo',	'681448755e639_UoN Logo_0',	'681448755e639_UoN-Logo_0.jpg',	'image/jpeg',	'public',	'public',	212528,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:22:14',	'2025-05-02 04:22:14',	NULL),
(5,	'App\\Models\\Institution',	4,	'ad8bb258-aa4c-4257-86f5-cfeadd0bca0f',	'logo',	'6814492277413_agh khan university',	'6814492277413_agh-khan-university.jpg',	'image/jpeg',	'public',	'public',	14217,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:25:08',	'2025-05-02 04:25:08',	NULL),
(6,	'App\\Models\\Institution',	1,	'11376e46-6169-420c-a4dd-fb18ca71f1ea',	'logo',	'6814496c101b5_kenyatta transparent_logo',	'6814496c101b5_kenyatta-transparent_logo.png',	'image/png',	'public',	'public',	211324,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:26:21',	'2025-05-02 04:26:21',	NULL),
(7,	'App\\Models\\Institution',	11,	'6f183d20-144b-4124-9c2a-156eb3705cb7',	'logo',	'681449f7bf6c4_KMTC cropped-download',	'681449f7bf6c4_KMTC-cropped-download.jpg',	'image/jpeg',	'public',	'public',	11814,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:28:42',	'2025-05-02 04:28:42',	NULL);

DROP TABLE IF EXISTS `messaging`;
CREATE TABLE `messaging` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` bigint DEFAULT NULL,
  `receiver_id` bigint DEFAULT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `messaging_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `messaging` (`id`, `sender_id`, `receiver_id`, `message`, `user`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	19,	48,	'Hello You',	'19',	'2025-05-14 05:43:32',	'2025-05-14 05:43:32',	NULL);

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2,	'2016_06_01_000001_create_oauth_auth_codes_table',	1),
(3,	'2016_06_01_000002_create_oauth_access_tokens_table',	1),
(4,	'2016_06_01_000003_create_oauth_refresh_tokens_table',	1),
(5,	'2016_06_01_000004_create_oauth_clients_table',	1),
(6,	'2016_06_01_000005_create_oauth_personal_access_clients_table',	1),
(7,	'2019_10_30_000001_create_media_table',	1),
(11,	'2019_10_30_000005_create_disciplines_table',	1),
(12,	'2019_10_30_000006_create_institutions_table',	1),
(13,	'2019_10_30_000007_create_courses_table',	1),
(14,	'2019_10_30_000008_create_enrollments_table',	1),
(15,	'2019_10_30_000009_create_permission_role_pivot_table',	1),
(16,	'2019_10_30_000010_create_role_user_pivot_table',	1),
(17,	'2019_10_30_000011_create_course_discipline_pivot_table',	1),
(18,	'2019_10_30_000012_add_relationship_fields_to_users_table',	1),
(19,	'2019_10_30_000013_add_relationship_fields_to_courses_table',	1),
(20,	'2019_10_30_000014_add_relationship_fields_to_enrollments_table',	1),
(41,	'2023_12_10_183057_create_table_checklist',	2),
(43,	'2023_12_13_175407_create_table_academic_history',	2),
(44,	'2023_12_13_175808_create_table_qualification_attained',	2),
(45,	'2023_12_13_180030_create_table_professional_references',	2),
(46,	'2023_12_13_180339_create_table_employment',	2),
(47,	'2023_12_13_180845_create_table_disclaimer',	3),
(50,	'2023_12_18_101952_create_table_messaging',	4),
(51,	'2023_12_20_170127_create_payment_proofs_table',	5),
(52,	'2023_12_13_143416_create_applications_table',	6),
(53,	'2024_05_20_122311_create_categories_table',	7),
(54,	'2024_05_21_122311_create_course_months_table',	8),
(55,	'2024_05_21_122312_create_course_manager_table',	9),
(58,	'0001_01_01_000002_create_jobs_table',	11),
(60,	'0001_01_01_000001_create_cache_table',	12),
(62,	'2019_10_30_000002_create_permissions_table',	13),
(63,	'2019_10_30_000003_create_roles_table',	13),
(65,	'2014_10_12_100000_create_password_resets_table',	14),
(70,	'2025_01_01_000000_create_users_table',	15),
(72,	'2025_01_27_061326_create_landlord_tenants_table',	16);

DROP TABLE IF EXISTS `mode_of_payments`;
CREATE TABLE `mode_of_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `institution_id` int unsigned DEFAULT NULL,
  `mobile_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `mobile_paybill` int DEFAULT NULL,
  `mobile_paybill_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `mobile_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `bank_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `bank_branch` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `account_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `account_number` int DEFAULT NULL,
  `amount` float(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `mode_of_payments_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `mode_of_payments` (`id`, `institution_id`, `mobile_name`, `mobile_paybill`, `mobile_paybill_no`, `mobile_number`, `bank_name`, `bank_branch`, `account_name`, `account_number`, `amount`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	8,	'MPESA',	1,	'001001',	NULL,	'Barclays Bank',	'Nairobi',	'Gerties Nursing School',	100010001,	2000.00,	'Yes',	'2025-03-26 04:41:23',	'2025-05-04 17:49:01',	NULL),
(2,	4,	'MPESA',	6489898,	'15556',	NULL,	'Lewis Sweet',	'Omnis reiciendis qui',	'Philip Larson',	381,	1800.00,	'Yes',	'2025-03-26 04:43:57',	'2025-05-04 17:26:19',	NULL),
(3,	5,	'MPESA',	1682937,	'800000',	NULL,	'Felicia Mays',	'Adipisicing odio ips',	'Edan Reed',	423,	1500.00,	'Yes',	'2025-03-26 04:45:25',	'2025-05-04 17:26:14',	NULL),
(4,	1,	'MPESA',	53222,	'9703944',	NULL,	'Grant Tate',	'Perspiciatis veniam',	'Nell Mckee',	588,	2000.00,	'Yes',	'2025-03-26 05:04:53',	'2025-05-04 17:26:10',	NULL),
(5,	9,	'MPESA',	6373837,	'8387373',	NULL,	'Coop Bank',	'Nairobi',	'Moi University',	100010001,	2300.00,	'No',	'2025-04-02 07:31:15',	'2025-05-14 12:02:12',	NULL);

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'App\\Models\\User',
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `model_has_permissions` (`permission_id`, `model_type`, `model_id`) VALUES
(1,	'App\\Models\\User',	19),
(2,	'App\\Models\\User',	19),
(3,	'App\\Models\\User',	19),
(4,	'App\\Models\\User',	19),
(5,	'App\\Models\\User',	19),
(6,	'App\\Models\\User',	19),
(7,	'App\\Models\\User',	19),
(8,	'App\\Models\\User',	19),
(9,	'App\\Models\\User',	19),
(10,	'App\\Models\\User',	19),
(11,	'App\\Models\\User',	19),
(12,	'App\\Models\\User',	19),
(13,	'App\\Models\\User',	19),
(14,	'App\\Models\\User',	19),
(15,	'App\\Models\\User',	19),
(16,	'App\\Models\\User',	19),
(17,	'App\\Models\\User',	19),
(18,	'App\\Models\\User',	19),
(19,	'App\\Models\\User',	19),
(20,	'App\\Models\\User',	19),
(21,	'App\\Models\\User',	19),
(22,	'App\\Models\\User',	19),
(23,	'App\\Models\\User',	19),
(24,	'App\\Models\\User',	19),
(25,	'App\\Models\\User',	19),
(26,	'App\\Models\\User',	19),
(27,	'App\\Models\\User',	19),
(28,	'App\\Models\\User',	19),
(29,	'App\\Models\\User',	19),
(30,	'App\\Models\\User',	19),
(31,	'App\\Models\\User',	19),
(32,	'App\\Models\\User',	19),
(33,	'App\\Models\\User',	19),
(34,	'App\\Models\\User',	19),
(35,	'App\\Models\\User',	19),
(36,	'App\\Models\\User',	19),
(37,	'App\\Models\\User',	19),
(40,	'App\\Models\\User',	19),
(41,	'App\\Models\\User',	19),
(43,	'App\\Models\\User',	19),
(44,	'App\\Models\\User',	19),
(12,	'App\\Models\\User',	20),
(13,	'App\\Models\\User',	20),
(14,	'App\\Models\\User',	20),
(15,	'App\\Models\\User',	20),
(16,	'App\\Models\\User',	20),
(27,	'App\\Models\\User',	20),
(28,	'App\\Models\\User',	20),
(29,	'App\\Models\\User',	20),
(30,	'App\\Models\\User',	20),
(31,	'App\\Models\\User',	20),
(32,	'App\\Models\\User',	20),
(33,	'App\\Models\\User',	20),
(34,	'App\\Models\\User',	20),
(35,	'App\\Models\\User',	20),
(36,	'App\\Models\\User',	20),
(40,	'App\\Models\\User',	20),
(41,	'App\\Models\\User',	20),
(12,	'App\\Models\\User',	22),
(13,	'App\\Models\\User',	22),
(14,	'App\\Models\\User',	22),
(15,	'App\\Models\\User',	22),
(16,	'App\\Models\\User',	22),
(27,	'App\\Models\\User',	22),
(28,	'App\\Models\\User',	22),
(29,	'App\\Models\\User',	22),
(30,	'App\\Models\\User',	22),
(31,	'App\\Models\\User',	22),
(32,	'App\\Models\\User',	22),
(33,	'App\\Models\\User',	22),
(34,	'App\\Models\\User',	22),
(35,	'App\\Models\\User',	22),
(36,	'App\\Models\\User',	22),
(40,	'App\\Models\\User',	22),
(41,	'App\\Models\\User',	22),
(12,	'App\\Models\\User',	23),
(13,	'App\\Models\\User',	23),
(14,	'App\\Models\\User',	23),
(15,	'App\\Models\\User',	23),
(16,	'App\\Models\\User',	23),
(27,	'App\\Models\\User',	23),
(28,	'App\\Models\\User',	23),
(29,	'App\\Models\\User',	23),
(30,	'App\\Models\\User',	23),
(31,	'App\\Models\\User',	23),
(32,	'App\\Models\\User',	23),
(33,	'App\\Models\\User',	23),
(34,	'App\\Models\\User',	23),
(35,	'App\\Models\\User',	23),
(36,	'App\\Models\\User',	23),
(40,	'App\\Models\\User',	23),
(41,	'App\\Models\\User',	23),
(12,	'App\\Models\\User',	24),
(13,	'App\\Models\\User',	24),
(14,	'App\\Models\\User',	24),
(15,	'App\\Models\\User',	24),
(16,	'App\\Models\\User',	24),
(27,	'App\\Models\\User',	24),
(28,	'App\\Models\\User',	24),
(29,	'App\\Models\\User',	24),
(30,	'App\\Models\\User',	24),
(31,	'App\\Models\\User',	24),
(32,	'App\\Models\\User',	24),
(33,	'App\\Models\\User',	24),
(34,	'App\\Models\\User',	24),
(35,	'App\\Models\\User',	24),
(36,	'App\\Models\\User',	24),
(40,	'App\\Models\\User',	24),
(41,	'App\\Models\\User',	24),
(12,	'App\\Models\\User',	26),
(13,	'App\\Models\\User',	26),
(14,	'App\\Models\\User',	26),
(15,	'App\\Models\\User',	26),
(16,	'App\\Models\\User',	26),
(27,	'App\\Models\\User',	26),
(28,	'App\\Models\\User',	26),
(29,	'App\\Models\\User',	26),
(30,	'App\\Models\\User',	26),
(31,	'App\\Models\\User',	26),
(32,	'App\\Models\\User',	26),
(33,	'App\\Models\\User',	26),
(34,	'App\\Models\\User',	26),
(35,	'App\\Models\\User',	26),
(36,	'App\\Models\\User',	26),
(40,	'App\\Models\\User',	26),
(41,	'App\\Models\\User',	26),
(7,	'App\\Models\\User',	51),
(8,	'App\\Models\\User',	51),
(9,	'App\\Models\\User',	51),
(10,	'App\\Models\\User',	51),
(11,	'App\\Models\\User',	51),
(1,	'App\\Models\\User',	52),
(2,	'App\\Models\\User',	52),
(3,	'App\\Models\\User',	52),
(4,	'App\\Models\\User',	52),
(5,	'App\\Models\\User',	52),
(6,	'App\\Models\\User',	52),
(7,	'App\\Models\\User',	52),
(8,	'App\\Models\\User',	52),
(9,	'App\\Models\\User',	52),
(10,	'App\\Models\\User',	52),
(11,	'App\\Models\\User',	52),
(12,	'App\\Models\\User',	52),
(13,	'App\\Models\\User',	52),
(14,	'App\\Models\\User',	52),
(15,	'App\\Models\\User',	52),
(16,	'App\\Models\\User',	52),
(17,	'App\\Models\\User',	52),
(18,	'App\\Models\\User',	52),
(19,	'App\\Models\\User',	52),
(20,	'App\\Models\\User',	52),
(21,	'App\\Models\\User',	52),
(22,	'App\\Models\\User',	52),
(23,	'App\\Models\\User',	52),
(24,	'App\\Models\\User',	52),
(25,	'App\\Models\\User',	52),
(26,	'App\\Models\\User',	52),
(27,	'App\\Models\\User',	52),
(28,	'App\\Models\\User',	52),
(29,	'App\\Models\\User',	52),
(30,	'App\\Models\\User',	52),
(31,	'App\\Models\\User',	52),
(32,	'App\\Models\\User',	52),
(33,	'App\\Models\\User',	52),
(34,	'App\\Models\\User',	52),
(35,	'App\\Models\\User',	52),
(36,	'App\\Models\\User',	52),
(37,	'App\\Models\\User',	52),
(27,	'App\\Models\\User',	53),
(28,	'App\\Models\\User',	53),
(29,	'App\\Models\\User',	53),
(30,	'App\\Models\\User',	53),
(31,	'App\\Models\\User',	53),
(33,	'App\\Models\\User',	53),
(34,	'App\\Models\\User',	53),
(35,	'App\\Models\\User',	53),
(36,	'App\\Models\\User',	53),
(27,	'App\\Models\\User',	54),
(28,	'App\\Models\\User',	54),
(29,	'App\\Models\\User',	54),
(30,	'App\\Models\\User',	54),
(31,	'App\\Models\\User',	54),
(33,	'App\\Models\\User',	54),
(34,	'App\\Models\\User',	54),
(35,	'App\\Models\\User',	54),
(36,	'App\\Models\\User',	54),
(1,	'App\\Models\\User',	55),
(12,	'App\\Models\\User',	55),
(13,	'App\\Models\\User',	55),
(14,	'App\\Models\\User',	55),
(15,	'App\\Models\\User',	55),
(16,	'App\\Models\\User',	55),
(27,	'App\\Models\\User',	55),
(28,	'App\\Models\\User',	55),
(29,	'App\\Models\\User',	55),
(30,	'App\\Models\\User',	55),
(31,	'App\\Models\\User',	55),
(33,	'App\\Models\\User',	55),
(34,	'App\\Models\\User',	55),
(35,	'App\\Models\\User',	55),
(36,	'App\\Models\\User',	55),
(26,	'App\\Models\\User',	56),
(36,	'App\\Models\\User',	56),
(27,	'App\\Models\\User',	57),
(28,	'App\\Models\\User',	57),
(29,	'App\\Models\\User',	57),
(30,	'App\\Models\\User',	57),
(31,	'App\\Models\\User',	57),
(33,	'App\\Models\\User',	57),
(34,	'App\\Models\\User',	57),
(35,	'App\\Models\\User',	57),
(36,	'App\\Models\\User',	57),
(41,	'App\\Models\\User',	57),
(12,	'App\\Models\\User',	58),
(13,	'App\\Models\\User',	58),
(14,	'App\\Models\\User',	58),
(15,	'App\\Models\\User',	58),
(16,	'App\\Models\\User',	58),
(26,	'App\\Models\\User',	58),
(27,	'App\\Models\\User',	58),
(28,	'App\\Models\\User',	58),
(29,	'App\\Models\\User',	58),
(30,	'App\\Models\\User',	58),
(31,	'App\\Models\\User',	58),
(32,	'App\\Models\\User',	58),
(33,	'App\\Models\\User',	58),
(34,	'App\\Models\\User',	58),
(35,	'App\\Models\\User',	58),
(36,	'App\\Models\\User',	58),
(40,	'App\\Models\\User',	58),
(41,	'App\\Models\\User',	58),
(26,	'App\\Models\\User',	64),
(32,	'App\\Models\\User',	64),
(33,	'App\\Models\\User',	64),
(34,	'App\\Models\\User',	64),
(35,	'App\\Models\\User',	64),
(36,	'App\\Models\\User',	64),
(41,	'App\\Models\\User',	64),
(12,	'App\\Models\\User',	70),
(13,	'App\\Models\\User',	70),
(14,	'App\\Models\\User',	70),
(15,	'App\\Models\\User',	70),
(16,	'App\\Models\\User',	70),
(26,	'App\\Models\\User',	70),
(27,	'App\\Models\\User',	70),
(28,	'App\\Models\\User',	70),
(29,	'App\\Models\\User',	70),
(30,	'App\\Models\\User',	70),
(31,	'App\\Models\\User',	70),
(32,	'App\\Models\\User',	70),
(33,	'App\\Models\\User',	70),
(34,	'App\\Models\\User',	70),
(35,	'App\\Models\\User',	70),
(36,	'App\\Models\\User',	70),
(40,	'App\\Models\\User',	70),
(41,	'App\\Models\\User',	70),
(26,	'App\\Models\\User',	71),
(32,	'App\\Models\\User',	71),
(33,	'App\\Models\\User',	71),
(34,	'App\\Models\\User',	71),
(35,	'App\\Models\\User',	71),
(36,	'App\\Models\\User',	71),
(41,	'App\\Models\\User',	71);

DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'App\\Models\\User',
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1,	'App\\Models\\User',	1),
(2,	'App\\Models\\User',	12),
(5,	'App\\Models\\User',	16),
(6,	'App\\Models\\User',	17),
(4,	'App\\Models\\User',	19),
(3,	'App\\Models\\User',	20),
(9,	'App\\Models\\User',	21),
(7,	'App\\Models\\User',	22),
(10,	'App\\Models\\User',	23),
(3,	'App\\Models\\User',	24),
(14,	'App\\Models\\User',	25),
(15,	'App\\Models\\User',	26),
(4,	'App\\Models\\User',	39),
(1,	'App\\Models\\User',	43),
(4,	'App\\Models\\User',	43),
(1,	'App\\Models\\User',	44),
(1,	'App\\Models\\User',	45),
(1,	'App\\Models\\User',	46),
(1,	'App\\Models\\User',	47),
(4,	'App\\Models\\User',	47),
(1,	'App\\Models\\User',	48),
(4,	'App\\Models\\User',	48),
(1,	'App\\Models\\User',	49),
(4,	'App\\Models\\User',	49),
(1,	'App\\Models\\User',	50),
(4,	'App\\Models\\User',	50);

DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `client_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `client_id` bigint unsigned NOT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE `oauth_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('alpho07@gmail.com',	'$2y$12$DAfQD3REdILGkCmWAfJ6e.M5zCQ8.RNPlEURUpszw7X4K.97PB3SC',	'2025-05-09 04:51:05');

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `payment_proofs`;
CREATE TABLE `payment_proofs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist_id` bigint unsigned DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `payment_proofs_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE `permission_role` (
  `role_id` int unsigned NOT NULL,
  `permission_id` int unsigned NOT NULL,
  KEY `role_id_fk_538787` (`role_id`),
  KEY `permission_id_fk_538787` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permission_role` (`role_id`, `permission_id`) VALUES
(1,	12),
(1,	13),
(1,	14),
(1,	15),
(1,	16),
(1,	27),
(1,	28),
(1,	29),
(1,	30),
(1,	31),
(1,	32),
(1,	33),
(1,	34),
(1,	35),
(1,	36),
(4,	1),
(4,	2),
(4,	3),
(4,	4),
(4,	5),
(4,	6),
(4,	7),
(4,	8),
(4,	9),
(4,	10),
(4,	11),
(4,	12),
(4,	13),
(4,	14),
(4,	15),
(4,	16),
(4,	17),
(4,	18),
(4,	19),
(4,	20),
(4,	22),
(4,	23),
(4,	24),
(4,	25),
(4,	27),
(4,	28),
(4,	29),
(4,	30),
(4,	32),
(4,	33),
(4,	34),
(4,	35),
(4,	36),
(4,	21),
(4,	26),
(4,	31),
(4,	37),
(5,	15),
(5,	22),
(5,	23),
(5,	13),
(5,	14),
(6,	1),
(6,	2),
(6,	3),
(6,	4),
(7,	1),
(7,	12),
(7,	13),
(7,	14),
(7,	15),
(7,	16),
(8,	27),
(8,	28),
(8,	29),
(8,	30),
(8,	31),
(10,	1),
(10,	12),
(10,	13),
(10,	14),
(10,	15),
(10,	16),
(11,	41),
(9,	36),
(2,	26),
(1,	40),
(1,	41),
(11,	32),
(11,	33),
(11,	34),
(11,	35),
(11,	36),
(4,	40),
(4,	41),
(4,	43),
(4,	44);

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'user_management_access',	'web',	NULL,	NULL,	NULL),
(2,	'permission_create',	'web',	NULL,	NULL,	NULL),
(3,	'permission_edit',	'web',	NULL,	NULL,	NULL),
(4,	'permission_show',	'web',	NULL,	NULL,	NULL),
(5,	'permission_delete',	'web',	NULL,	NULL,	NULL),
(6,	'permission_access',	'web',	NULL,	NULL,	NULL),
(7,	'role_create',	'web',	NULL,	NULL,	NULL),
(8,	'role_edit',	'web',	NULL,	NULL,	NULL),
(9,	'role_show',	'web',	NULL,	NULL,	NULL),
(10,	'role_delete',	'web',	NULL,	NULL,	NULL),
(11,	'role_access',	'web',	NULL,	NULL,	NULL),
(12,	'user_create',	'web',	NULL,	NULL,	NULL),
(13,	'user_edit',	'web',	NULL,	NULL,	NULL),
(14,	'user_show',	'web',	NULL,	NULL,	NULL),
(15,	'user_delete',	'web',	NULL,	NULL,	NULL),
(16,	'user_access',	'web',	NULL,	NULL,	NULL),
(17,	'discipline_create',	'web',	NULL,	NULL,	NULL),
(18,	'discipline_edit',	'web',	NULL,	NULL,	NULL),
(19,	'discipline_show',	'web',	NULL,	NULL,	NULL),
(20,	'discipline_delete',	'web',	NULL,	NULL,	NULL),
(21,	'discipline_access',	'web',	NULL,	NULL,	NULL),
(22,	'institution_create',	'web',	NULL,	NULL,	NULL),
(23,	'institution_edit',	'web',	NULL,	NULL,	NULL),
(24,	'institution_show',	'web',	NULL,	NULL,	NULL),
(25,	'institution_delete',	'web',	NULL,	NULL,	NULL),
(26,	'institution_access',	'web',	NULL,	NULL,	NULL),
(27,	'course_create',	'web',	NULL,	NULL,	NULL),
(28,	'course_edit',	'web',	NULL,	NULL,	NULL),
(29,	'course_show',	'web',	NULL,	NULL,	NULL),
(30,	'course_delete',	'web',	NULL,	NULL,	NULL),
(31,	'course_access',	'web',	NULL,	NULL,	NULL),
(32,	'enrollment_create',	'web',	NULL,	NULL,	NULL),
(33,	'enrollment_edit',	'web',	NULL,	NULL,	NULL),
(34,	'enrollment_show',	'web',	NULL,	NULL,	NULL),
(35,	'enrollment_delete',	'web',	NULL,	NULL,	NULL),
(36,	'enrollment_access',	'web',	NULL,	NULL,	NULL),
(37,	'full_menu',	'web',	'2024-01-01 16:00:39',	'2025-01-13 14:36:42',	NULL),
(38,	'list_USERS_1',	'web',	'2025-01-16 03:46:45',	'2025-01-16 03:47:14',	'2025-01-16 03:47:14'),
(39,	'super_user2',	'web',	'2025-01-16 03:47:30',	'2025-01-16 03:47:56',	'2025-01-16 03:47:56'),
(40,	'finance_manager',	'web',	'2025-01-29 03:56:29',	'2025-01-29 03:56:29',	NULL),
(41,	'application_manager',	'web',	'2025-01-29 03:56:45',	'2025-01-29 03:56:45',	NULL),
(43,	'institution_access_',	'web',	'2025-01-29 10:05:07',	'2025-01-29 10:05:07',	NULL),
(44,	'all_file_filter',	'web',	'2025-03-13 13:12:06',	'2025-03-13 13:12:06',	NULL);

DROP TABLE IF EXISTS `professional_references`;
CREATE TABLE `professional_references` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `reference_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_organization` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_phone_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_job_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `professional_references_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `professional_references` (`id`, `checklist`, `application_id`, `scholarship_id`, `reference_title`, `reference_full_name`, `reference_organization`, `reference_phone_no`, `reference_email`, `reference_job_title`, `created_at`, `updated_at`, `institution_id`) VALUES
(3,	1,	49,	18,	'Sit magna beatae qui',	'Fiona Cote',	'Byrd Cox Co',	'+1 (689) 828-6102',	'hocalej@mailinator.com',	'Rerum iure qui dolor',	'2025-05-14 11:49:39',	'2025-05-14 11:49:39',	NULL),
(4,	1,	49,	18,	'Et adipisci omnis il',	'Zane Hampton',	'Crawford and Beach Associates',	'+1 (143) 762-3148',	'dogid@mailinator.com',	'Amet excepteur impe',	'2025-05-14 11:49:39',	'2025-05-14 11:49:39',	NULL),
(5,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44',	NULL),
(6,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44',	NULL),
(23,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22',	NULL),
(24,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22',	NULL),
(141,	4,	19,	28,	'Enim voluptatem ea p',	'Jenette Melendez',	'Ortega Richmond Co',	'+1 (108) 528-8199',	'dogakiwigy@mailinator.com',	'Neque cillum dolorem',	'2025-05-20 15:47:54',	'2025-05-20 15:47:54',	NULL),
(142,	4,	19,	28,	'Quo ratione anim exc',	'Vivian Vasquez',	'Becker Hansen Plc',	'+1 (323) 487-8534',	'quvirul@mailinator.com',	'Ea aliquid maiores n',	'2025-05-20 15:47:54',	'2025-05-20 15:47:54',	NULL),
(205,	5,	19,	30,	'Expedita consequatur',	'Jane Parsons',	'Blanchard and Trujillo Plc',	'+1 (886) 793-4281',	'syzikineca@mailinator.com',	'Velit quae non prae',	'2025-05-21 03:57:53',	'2025-05-21 03:57:53',	NULL),
(206,	5,	19,	30,	'Dolor impedit dolor',	'Vanna May',	'Hensley Odom Associates',	'+1 (732) 149-1318',	'xatazu@mailinator.com',	'Ut ad rem est dolor',	'2025-05-21 03:57:53',	'2025-05-21 03:57:53',	NULL);

DROP TABLE IF EXISTS `qualification_attained`;
CREATE TABLE `qualification_attained` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `training_institution` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_institution_start_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_institution_completion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_institution_attained` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `qualification_attained_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `qualification_attained` (`id`, `checklist`, `application_id`, `scholarship_id`, `training_institution`, `training_institution_start_date`, `training_institution_completion`, `training_institution_attained`, `created_at`, `updated_at`, `institution_id`) VALUES
(3,	1,	49,	18,	'Tempor non dolor qui',	'14-Mar-2014',	'Non vel illo corrupt',	'Molestias incidunt',	'2025-05-14 11:49:39',	'2025-05-14 11:49:39',	NULL),
(4,	1,	49,	18,	'Et soluta aut quod b',	'02-Aug-2017',	'Id corporis tempora',	'Earum ut in aperiam',	'2025-05-14 11:49:39',	'2025-05-14 11:49:39',	NULL),
(5,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44',	NULL),
(6,	2,	19,	3,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 13:17:44',	'2025-05-14 13:17:44',	NULL),
(23,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22',	NULL),
(24,	3,	50,	7,	NULL,	NULL,	NULL,	NULL,	'2025-05-14 14:42:22',	'2025-05-14 14:42:22',	NULL),
(141,	4,	19,	28,	'Mollitia et recusand',	'20-Dec-2002',	'Id magnam repudianda',	'Consectetur autem si',	'2025-05-20 15:47:54',	'2025-05-20 15:47:54',	NULL),
(142,	4,	19,	28,	'Laudantium debitis',	'03-Nov-1974',	'Aperiam sed sint as',	'Sint veniam eiusmod',	'2025-05-20 15:47:54',	'2025-05-20 15:47:54',	NULL),
(205,	5,	19,	30,	'Cupidatat eos ea nih',	'16-Jan-2006',	'Facere et ullam repu',	'Sint et quia cumque',	'2025-05-21 03:57:53',	'2025-05-21 03:57:53',	NULL),
(206,	5,	19,	30,	'Esse quae ratione ve',	'22-Jun-2016',	'Dolores excepturi an',	'Culpa facilis pariat',	'2025-05-21 03:57:53',	'2025-05-21 03:57:53',	NULL);

DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions3` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles2` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `role_user`;
CREATE TABLE `role_user` (
  `user_id` int unsigned NOT NULL,
  `role_id` int unsigned NOT NULL,
  KEY `user_id_fk_538796` (`user_id`),
  KEY `role_id_fk_538796` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1,	1),
(2,	2),
(35,	2),
(36,	2),
(39,	4),
(41,	4),
(42,	1),
(42,	4),
(43,	1),
(43,	4),
(44,	1),
(44,	4),
(45,	1),
(45,	4),
(46,	1),
(46,	4),
(47,	1),
(47,	4),
(48,	1),
(48,	4),
(49,	1),
(49,	4),
(50,	1),
(50,	4),
(51,	4),
(52,	4),
(53,	2),
(54,	2),
(54,	8),
(57,	2),
(57,	11),
(55,	2),
(55,	7),
(56,	2),
(56,	9),
(58,	1),
(58,	2),
(61,	3),
(62,	3),
(63,	3),
(65,	3),
(64,	2),
(64,	11),
(66,	3),
(67,	3),
(68,	3),
(69,	3),
(70,	1),
(70,	2),
(71,	2),
(71,	11),
(72,	3),
(19,	2),
(19,	4),
(20,	1),
(21,	3),
(22,	1),
(23,	1),
(24,	1),
(25,	3),
(26,	1),
(27,	3),
(28,	3),
(29,	3),
(30,	3),
(31,	3),
(32,	3),
(33,	3),
(34,	3),
(35,	3),
(36,	3),
(37,	3),
(38,	3),
(39,	3),
(40,	3),
(41,	3),
(42,	3),
(43,	3),
(44,	3),
(45,	3),
(46,	3),
(47,	3),
(48,	3),
(49,	3),
(50,	3);

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'web',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Admin',	'web',	NULL,	NULL,	NULL),
(2,	'Institution',	'web',	NULL,	NULL,	NULL),
(3,	'Student',	'web',	NULL,	NULL,	NULL),
(4,	'Super Admin',	'web',	'2024-01-01 16:01:29',	'2024-01-01 16:01:29',	NULL),
(8,	'Course Manager',	'web',	'2025-01-29 03:52:11',	'2025-01-29 03:52:11',	NULL),
(9,	'Finance Manager',	'web',	'2025-01-29 03:52:55',	'2025-01-29 03:52:55',	NULL),
(10,	'User Manager',	'web',	'2025-01-29 05:31:02',	'2025-01-29 05:31:02',	NULL),
(11,	'Application Manager',	'web',	'2025-01-29 05:31:32',	'2025-01-29 05:31:32',	NULL);

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('8MoWR6phmjyiP3JKQ0FGUeNdVGZY076I6RajoVRw',	NULL,	'103.43.18.59',	'iTunes/9.0.2 (Windows; N)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidXMzM29iRnFHWlhyREhtQkE4MGFySVUxR2tCTXl4d0IzZEk3QW5XZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTU3LjIzMC42LjIyMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1747803600),
('9gucFl5YUCT3T57YIxIeKlwsR7wsGYN6S6T36I7H',	NULL,	'197.232.156.209',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiR3c0ZjBvVEZHQmxkV3R1OXpHc1kzeURvR3FrWXF5RXZsNWJuQlhoWSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo1NDoiaHR0cHM6Ly9zY2hvbGFyc2hpcHMua2VueWFwYWVkaWF0cmljLm9yZy9hcHBseS81LzMwP3E9Ijt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTQ6Imh0dHBzOi8vc2Nob2xhcnNoaXBzLmtlbnlhcGFlZGlhdHJpYy5vcmcvYXBwbHkvNS8zMD9xPSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1747799712),
('F5QNXpyasw3jqIewlnyQpraJ3zSJFh3sB2d5USyJ',	NULL,	'103.203.59.1',	'HTTP Banner Detection (https://security.ipip.net)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0lBbVQ2aktNeVozenBXNW9UMkFsSklrQXFDQzNPaGxsUG85eGk4RSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTU3LjIzMC42LjIyMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1747803437),
('FE2FgdNgkfWGxLBgbiVVZqXf7i7dRC8wZBiq6SDQ',	NULL,	'124.221.245.78',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOGlRTUxOOENTRFJrOFdvUzRIZ1JpcDMwZExxa1JCVVBQUGJtOTNDMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjg6Imh0dHBzOi8vZ2V0dGluZ3JlYWxhZ2Fpbi5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1747797028),
('iwOxCjhh2L8SM2HKpyYlPHbsn5I6PpDeZ6rXAHFT',	19,	'197.232.156.209',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',	'YToxMDp7czo2OiJfdG9rZW4iO3M6NDA6Ikd2Q1hVUHZZSEJWQ1VJNEJPbnRxVjVrRWZtakhaRVFWSkRtRnJsVFAiO3M6MTQ6Imluc3RpdHV0aW9uX2lkIjtpOjU7czo5OiJjb3Vyc2VfaWQiO2k6Mjk7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHBzOi8vc2Nob2xhcnNoaXBzLmtlbnlhcGFlZGlhdHJpYy5vcmciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM6InVybCI7YTowOnt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTk7czoxMDoidXNlcl9yb2xlcyI7YToyOntpOjA7czoxMToiSW5zdGl0dXRpb24iO2k6MTtzOjExOiJTdXBlciBBZG1pbiI7fXM6MTY6Imluc3RpdHV0aW9uX25hbWUiO047czo0OiJhdXRoIjthOjE6e3M6MjE6InBhc3N3b3JkX2NvbmZpcm1lZF9hdCI7aToxNzQ3Nzk4Njc1O319',	1747803660),
('ixHNjVCg41WxZJSPxAk1l4UfqV9VI31K38VXg8Ea',	NULL,	'148.113.210.254',	'Mozilla/5.0 (compatible; ModatScanner/1.0; +https://modat.io/)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRjIxaVh5b3N2RXJKUjlKM1IyVWhRR2NBRmNJVXZKWGw5aGpDSWJWeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTU3LjIzMC42LjIyMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1747798185),
('lmF0SRSt91ByRNJEsrpWXIx1H7ZvMFw5p4PHvTNR',	NULL,	'3.143.33.63',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoicld0YXVJVjRrQzdZNTZtY1k1b0NGQmhpRFAxMXdJeTJYVHhZMzRKbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTU3LjIzMC42LjIyMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1747801541),
('oO3G8BmAIrHrXQpcO2vKZWjMYuBPxF1MfaVwe6hR',	NULL,	'103.43.18.59',	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.61 Safari/537.36 ArchiveBox/0.6.2',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoia3lQWHAxbFBmYnh2VnJtSnlRTUMyamlQNEJWcGNOVnI1QXVQSmNUcCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTU3LjIzMC42LjIyMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1747798968),
('rCMm1jCluMol6WY72FFTvpu7Y26beyXHOaAqBFvW',	NULL,	'103.43.18.59',	'Opera/9.80 (Windows NT 6.1; WOW64) Presto/2.12.388 Version/12.16',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ2owd3BvMkt6azI5YjlRV2dUbEd5Nk1VRnpxaU4zS21GbkhzRExOYSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTU3LjIzMC42LjIyMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1747801135),
('Rro7F5Bh67QqnIEXgvK8PXtpDXYu0BnHWPNySpIO',	NULL,	'197.232.156.209',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) Gecko/20100101 Firefox/138.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMm04SE9YREFnSXRqbURBZnZseVdITDdrTnA0bXlVU3hCOXdEemdWbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDY6Imh0dHBzOi8vc2Nob2xhcnNoaXBzLmtlbnlhcGFlZGlhdHJpYy5vcmcvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1747799713),
('U7qC52fmvcB10AMFDiyjnHj0IboEC0wb6CoCwtLM',	NULL,	'148.113.206.49',	'Mozilla/5.0 (compatible; ModatScanner/1.0; +https://modat.io/)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUV0OEt2NVozMDBGTlNTZncyTmlnOUJBVElXRU5hTld4blg0WTBHVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHBzOi8vMTU3LjIzMC42LjIyMyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1747800110);

DROP TABLE IF EXISTS `tenants`;
CREATE TABLE `tenants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `database` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenants_domain_unique` (`domain`),
  UNIQUE KEY `tenants_database_unique` (`database`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `uploads_managers`;
CREATE TABLE `uploads_managers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `required` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `file_size` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '2048',
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `uploads_managers` (`id`, `file_name`, `slug`, `required`, `file_size`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Personal statement/reflective thinking summary about your passion for the course and desired impact post-training.',	'application_letter',	'Yes',	'2048',	'2025-02-27 16:31:54',	'2025-02-27 16:31:54',	NULL),
(2,	'Updated curriculum vitae',	'cv',	'Yes',	'2048',	'2025-02-27 16:33:15',	'2025-02-27 16:33:15',	NULL),
(3,	'Copies of relevant academic certificates, licenses, and transcripts(Scan and combine)',	'certificates',	'Yes',	'2048',	'2025-02-27 16:33:30',	'2025-02-27 16:33:30',	NULL),
(4,	'Copy of national identity card/passport',	'national_id',	'Yes',	'2048',	'2025-02-27 16:34:14',	'2025-02-27 16:34:14',	NULL),
(14,	'Proof of Application Fee Payment',	'proof_of_payment',	'false',	'2048',	'2025-03-19 15:42:07',	'2025-03-19 15:42:07',	NULL),
(15,	'Signed Pre-Auth Form',	'signed_pre_auth_form',	'false',	'2048',	'2025-03-19 15:42:17',	'2025-03-19 15:42:17',	NULL),
(16,	'Blank or Raw Bonding Form',	'blank_or_raw_bonding_form',	'false',	'2048',	'2025-03-19 15:42:17',	'2025-03-19 15:42:17',	NULL),
(17,	'Fully filled Bonding & Release Form',	'fully_filled_bonding_and_form',	'false',	'2048',	'2025-05-05 10:18:38',	'2025-05-05 10:18:38',	NULL);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_number` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `county` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires_at` datetime DEFAULT NULL,
  `is_verified` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'true',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `institution_fk_538818` (`institution_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `first_name`, `middle_name`, `last_name`, `id_number`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`, `institution_id`, `phone`, `gender`, `dob`, `county`, `country`, `otp`, `otp_expires_at`, `is_verified`) VALUES
(1,	'Admin',	NULL,	NULL,	NULL,	'admin@admin.com',	NULL,	'$2y$12$YL8uFDWFMiuDMl8cR/8dG.gCWEU.iJjruCKPFmuFf9ltZ5dNS76G2',	NULL,	NULL,	'2025-05-06 05:03:52',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(19,	'Super',	'A',	'Admin',	'11223344',	'super@admin.com',	NULL,	'$2y$12$3Cc3gfLv.MHl7xHtnugdjuIDw5to2gBj2aEH0cBQN06UTXG.jjfO6',	'm1Tk39x04PzXSNwD82mDItTuczSJ9A8acWSkFBpA17sGUTtnha7LwjgmbZor',	'2024-01-01 16:03:01',	'2025-03-25 14:22:02',	NULL,	NULL,	'07158822271',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(20,	'Ivor',	'Gavin Hess',	'Olsen',	'89837362',	'gapp@gertrudes.com',	NULL,	'$2y$12$3Cc3gfLv.MHl7xHtnugdjuIDw5to2gBj2aEH0cBQN06UTXG.jjfO6',	NULL,	'2025-03-25 14:28:39',	'2025-03-25 14:28:39',	NULL,	8,	'07157625263',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(22,	'Gabriel',	'Janna Allison',	'Joseph',	'878',	'admin@knh.or.ke',	NULL,	'$2y$12$ecUW70RSmX6hdvS4VkaMi.K/8fH7NW8jV881gjWVUBBilGzQiq.Y2',	NULL,	'2025-03-26 04:37:41',	'2025-03-26 04:37:41',	NULL,	1,	'42',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(23,	'Lucy',	'Dana Macdonald',	'Bullock',	'980',	'admin@uon.ac.ke',	NULL,	'$2y$12$SdkZen/2Mvus3f9Spj5NUOvazb/sG5u20L7aNGLZ3vcCax5sbYWBa',	NULL,	'2025-03-26 04:38:31',	'2025-03-26 04:38:31',	NULL,	5,	'61',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(24,	'Hayfa',	'Vera Cote',	'Padilla',	'957',	'admin@aghkhan.ac.ke',	NULL,	'$2y$12$5hKGG/Yw2n2sE2TfuK440uAiQ91/ga44Ov4XkKfctnUtBzEeCAdcO',	NULL,	'2025-03-26 04:39:20',	'2025-03-26 04:39:20',	NULL,	4,	'30',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(25,	'Audra',	'Rama Dawson',	'Mcintosh',	'246',	'student1@gmail.com',	NULL,	'$2y$12$J/JZ1pdgrkUb6rJYCUdWnO4NIumr0utRXu6PAO2ciYHiBJ.Q1vdgS',	NULL,	'2025-03-26 05:13:28',	'2025-05-14 06:08:16',	'2025-05-14 06:08:16',	NULL,	'+1 (151) 349-1055',	'Female',	'2004-01-22',	NULL,	NULL,	NULL,	NULL,	'true'),
(26,	'Moi University',	'-',	'Admin',	'111222333',	'admin@moi.ac.ke',	NULL,	'$2y$12$yxaNSzzxJysxHZobPqL60.AnN/E0JTCu0QPavdIkBkLBDuZe5Jtiy',	NULL,	'2025-04-02 07:28:31',	'2025-04-02 07:28:31',	NULL,	9,	'0700000000',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(49,	'Maya',	'Connor Herrera',	'Maxwell',	'26',	'alpho07@gmail.com',	NULL,	'$2y$12$S0PJ4gdZQgfV.YjEvV8eb.Fv8J9FvEaSIQVzClzsEFpY.1k.bJDCG',	NULL,	'2025-05-14 11:46:31',	'2025-05-14 11:47:09',	NULL,	NULL,	'+1 (505) 827-6467',	'Male',	'2006-01-18',	NULL,	NULL,	NULL,	NULL,	'true'),
(50,	'MAHTHIR',	'MOHAMED',	'SHEIKH',	'34146761',	'mahthirgalgalo11@gmail.com',	NULL,	'$2y$12$d9Hw4YMnHTltJPD6mlG/p.q2zwh9umTu3U8C9ZFThcQCqva34rDRm',	NULL,	'2025-05-14 14:31:16',	'2025-05-14 14:31:54',	NULL,	NULL,	'0719727023',	'Male',	'1997-01-01',	NULL,	NULL,	NULL,	NULL,	'true');

DROP VIEW IF EXISTS `vw_master_course_app`;
CREATE TABLE `vw_master_course_app` (`id` int, `payment_verified` varchar(20), `sponsorship_type` varchar(20), `county` varchar(50), `course` varchar(255), `category` varchar(255), `period` varchar(267), `status` varchar(20), `phone` varchar(20), `gender` varchar(10), `dob` date, `application_id` int unsigned, `name` varchar(152), `created_at` timestamp, `age` bigint, `national_id` varchar(100), `nck_lic` varchar(100), `nck_cert` varchar(100), `kcse_cse` varchar(100), `passport` varchar(100), `sponsorship_id` varchar(100), `application_letter` varchar(100), `dip_deg` varchar(100), `comments` longtext, `institution_id` int unsigned);


DROP TABLE IF EXISTS `master_course_app`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `master_course_app` AS select `ca`.`id` AS `id`,`ca`.`payment_verified` AS `payment_verified`,`cm`.`name` AS `course`,`cc`.`name` AS `category`,concat(`cmos`.`name`,'-',`ca`.`year`) AS `period`,`ca`.`status` AS `status`,`u`.`phone` AS `phone`,`u`.`gender` AS `gender`,`u`.`dob` AS `dob`,`u`.`id` AS `application_id`,concat_ws(' ',`u`.`first_name`,`u`.`middle_name`,`u`.`last_name`) AS `name`,`ca`.`created_at` AS `created_at`,floor(((to_days(curdate()) - to_days(`u`.`dob`)) / 365.25)) AS `age`,`up`.`national_id` AS `national_id`,`up`.`nck_lic` AS `nck_lic`,`up`.`nck_cert` AS `nck_cert`,`up`.`kcse_cse` AS `kcse_cse`,`up`.`passport` AS `passport`,`ca`.`sponsorship_id` AS `sponsorship_id`,`ca`.`institution_id` AS `institution_id` from (((((`course_application` `ca` join `course_manager` `cm` on((`ca`.`course_id` = `cm`.`id`))) join `course_category` `cc` on((`cc`.`id` = `cm`.`category_id`))) left join `course_months` `cmos` on((`cmos`.`id` = `cm`.`month_id`))) left join `users` `u` on((`u`.`id` = `ca`.`student_id`))) left join `course_uploads` `up` on((`up`.`student_id` = `u`.`id`)));

DROP TABLE IF EXISTS `vw_master_course_app`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_master_course_app` AS select `ca`.`id` AS `id`,`ca`.`payment_verified` AS `payment_verified`,`ca`.`sponsorship_type` AS `sponsorship_type`,`u`.`county` AS `county`,`cm`.`name` AS `course`,`cc`.`name` AS `category`,concat(`cmos`.`name`,'-',`ca`.`year`) AS `period`,`ca`.`status` AS `status`,`u`.`phone` AS `phone`,`u`.`gender` AS `gender`,`u`.`dob` AS `dob`,`u`.`id` AS `application_id`,concat_ws(' ',`u`.`first_name`,`u`.`middle_name`,`u`.`last_name`) AS `name`,`ca`.`created_at` AS `created_at`,floor(((to_days(curdate()) - to_days(`u`.`dob`)) / 365.25)) AS `age`,`up`.`national_id` AS `national_id`,`up`.`nck_lic` AS `nck_lic`,`up`.`nck_cert` AS `nck_cert`,`up`.`kcse_cse` AS `kcse_cse`,`up`.`passport` AS `passport`,`ca`.`sponsorship_id` AS `sponsorship_id`,`up`.`application_letter` AS `application_letter`,`up`.`dip_deg` AS `dip_deg`,`ca`.`comments` AS `comments`,`ca`.`institution_id` AS `institution_id` from (((((`course_application` `ca` join `course_manager` `cm` on((`ca`.`course_id` = `cm`.`id`))) join `course_category` `cc` on((`cc`.`id` = `cm`.`category_id`))) left join `course_months` `cmos` on((`cmos`.`id` = `cm`.`month_id`))) left join `users` `u` on((`u`.`id` = `ca`.`student_id`))) left join `course_uploads` `up` on((`up`.`student_id` = `u`.`id`))) where (`ca`.`sponsorship_type` = 'Self Sponsored');

-- 2025-05-21 05:02:16
