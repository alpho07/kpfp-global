-- Adminer 4.8.1 MySQL 8.0.41-0ubuntu0.24.10.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `academic_history`;
CREATE TABLE `academic_history` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `academic_university` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_start_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_completion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `academic_diplomas` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `academic_history_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `academic_history` (`id`, `checklist`, `application_id`, `scholarship_id`, `academic_university`, `academic_start_date`, `academic_completion`, `academic_diplomas`, `institution_id`, `created_at`, `updated_at`) VALUES
(1,	1,	19,	5,	'Ullamco voluptatem a',	'11-Nov-1986',	'Est blanditiis ex re',	'Proident proident',	NULL,	'2025-05-02 11:50:40',	'2025-05-02 11:50:40'),
(2,	1,	19,	5,	'Corrupti id labore',	'03-Oct-1986',	'At consequatur Sit',	'Aute perferendis nis',	NULL,	'2025-05-02 11:50:40',	'2025-05-02 11:50:40'),
(3,	1,	19,	5,	'Dolor blanditiis id',	'15-Jun-1999',	'Omnis velit aut rep',	'Vel incidunt non el',	NULL,	'2025-05-02 11:50:40',	'2025-05-02 11:50:40'),
(4,	1,	19,	5,	'Officia quam invento',	'06-Mar-2020',	'Id aperiam consequun',	'Rem veniam nobis at',	NULL,	'2025-05-02 11:50:40',	'2025-05-02 11:50:40'),
(5,	2,	19,	27,	'Dolorum reiciendis d',	'15-Dec-2019',	'Quam incidunt eu es',	'Quaerat quis dolores',	NULL,	'2025-05-03 14:34:43',	'2025-05-03 14:34:43'),
(6,	2,	19,	27,	'Proident reiciendis',	'11-Jun-1995',	'Quas aliquam enim in',	'Excepturi proident',	NULL,	'2025-05-03 14:34:43',	'2025-05-03 14:34:43'),
(7,	2,	19,	27,	'In anim est explica',	'25-Oct-1980',	'Et laboriosam ullam',	'Aliquip aut tempor q',	NULL,	'2025-05-03 14:34:43',	'2025-05-03 14:34:43'),
(8,	2,	19,	27,	'Et a anim perspiciat',	'14-Sep-2024',	'Natus in eaque tempo',	'Minim minus sit sed',	NULL,	'2025-05-03 14:34:43',	'2025-05-03 14:34:43'),
(9,	3,	19,	14,	'Laboris ex corrupti',	'30-Mar-1988',	'Ex quia voluptatem',	'Odio quia placeat e',	NULL,	'2025-05-03 15:32:30',	'2025-05-03 15:32:30'),
(10,	3,	19,	14,	'Suscipit repudiandae',	'15-Sep-2002',	'Consequat Soluta no',	'Molestiae dolore dol',	NULL,	'2025-05-03 15:32:30',	'2025-05-03 15:32:30'),
(11,	3,	19,	14,	'Vel et libero ipsa',	'29-Oct-1980',	'Reiciendis aute assu',	'Totam accusamus fugi',	NULL,	'2025-05-03 15:32:30',	'2025-05-03 15:32:30'),
(12,	3,	19,	14,	'Sapiente nisi et sit',	'06-Feb-2011',	'Deleniti impedit ar',	'Labore quia et praes',	NULL,	'2025-05-03 15:32:30',	'2025-05-03 15:32:30'),
(13,	4,	29,	8,	'Adipisicing officia',	'05-Mar-1970',	'Quos aute et iste et',	'Quidem autem rerum n',	NULL,	'2025-05-04 16:33:29',	'2025-05-04 16:33:29'),
(14,	4,	29,	8,	'Assumenda dolorem co',	'19-Feb-1979',	'Fugit omnis dolore',	'Et voluptate illo do',	NULL,	'2025-05-04 16:33:29',	'2025-05-04 16:33:29'),
(15,	4,	29,	8,	'Ut ullam quas modi v',	'21-Jul-1975',	'Placeat sed quae do',	'Sint consectetur mo',	NULL,	'2025-05-04 16:33:29',	'2025-05-04 16:33:29'),
(16,	4,	29,	8,	'Delectus inventore',	'28-Sep-1976',	'Laborum at esse et q',	'Repellendus In cons',	NULL,	'2025-05-04 16:33:29',	'2025-05-04 16:33:29'),
(17,	5,	29,	16,	'Molestiae libero vel',	'02-Mar-1996',	'Do in et rerum ut ut',	'A dolorum minus qui',	NULL,	'2025-05-05 23:07:36',	'2025-05-05 23:07:36'),
(18,	5,	29,	16,	'Adipisci doloribus e',	'20-Dec-1971',	'Ut ullam laboriosam',	'Accusamus totam adip',	NULL,	'2025-05-05 23:07:36',	'2025-05-05 23:07:36'),
(19,	5,	29,	16,	'Veniam quis rem dol',	'28-Feb-1975',	'Accusamus et reprehe',	'Veniam ut iste esse',	NULL,	'2025-05-05 23:07:36',	'2025-05-05 23:07:36'),
(20,	5,	29,	16,	'Enim autem autem rer',	'21-Apr-2002',	'Nihil ullamco debiti',	'Ullam non neque dolo',	NULL,	'2025-05-05 23:07:36',	'2025-05-05 23:07:36');

DROP TABLE IF EXISTS `applicants_uploads`;
CREATE TABLE `applicants_uploads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `document_id` int NOT NULL,
  `course_id` int NOT NULL,
  `institution_id` int NOT NULL,
  `file_path` longtext NOT NULL,
  `version` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `applicants_uploads` (`id`, `student_id`, `document_id`, `course_id`, `institution_id`, `file_path`, `version`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	19,	1,	5,	4,	'files/personal_documents/4/5/19_Super_/19_Super__application_letter_1_v1.pdf',	1,	'2025-05-02 11:49:53',	'2025-05-02 11:49:53',	NULL),
(2,	19,	2,	5,	4,	'files/personal_documents/4/5/19_Super_/19_Super__cv_2_v1.pdf',	1,	'2025-05-02 11:50:02',	'2025-05-02 11:50:02',	NULL),
(3,	19,	3,	5,	4,	'files/personal_documents/4/5/19_Super_/19_Super__certificates_3_v1.pdf',	1,	'2025-05-02 11:50:11',	'2025-05-02 11:50:11',	NULL),
(4,	19,	4,	5,	4,	'files/personal_documents/4/5/19_Super_/19_Super__national_id_4_v1.pdf',	1,	'2025-05-02 11:50:18',	'2025-05-02 11:50:18',	NULL),
(5,	19,	1,	27,	5,	'files/personal_documents/5/27/19_Super_/19_Super__application_letter_1_v1.pdf',	1,	'2025-05-03 14:33:49',	'2025-05-03 14:33:49',	NULL),
(6,	19,	2,	27,	5,	'files/personal_documents/5/27/19_Super_/19_Super__cv_2_v1.pdf',	1,	'2025-05-03 14:33:59',	'2025-05-03 14:33:59',	NULL),
(7,	19,	3,	27,	5,	'files/personal_documents/5/27/19_Super_/19_Super__certificates_3_v1.pdf',	1,	'2025-05-03 14:34:08',	'2025-05-03 14:34:08',	NULL),
(8,	19,	4,	27,	5,	'files/personal_documents/5/27/19_Super_/19_Super__national_id_4_v1.pdf',	1,	'2025-05-03 14:34:21',	'2025-05-03 14:34:21',	NULL),
(9,	19,	1,	14,	11,	'files/personal_documents/11/14/19_Super_/19_Super__application_letter_1_v1.pdf',	1,	'2025-05-03 15:31:36',	'2025-05-03 15:31:36',	NULL),
(10,	19,	2,	14,	11,	'files/personal_documents/11/14/19_Super_/19_Super__cv_2_v1.pdf',	1,	'2025-05-03 15:31:45',	'2025-05-03 15:31:45',	NULL),
(11,	19,	3,	14,	11,	'files/personal_documents/11/14/19_Super_/19_Super__certificates_3_v1.pdf',	1,	'2025-05-03 15:31:54',	'2025-05-03 15:31:54',	NULL),
(12,	19,	4,	14,	11,	'files/personal_documents/11/14/19_Super_/19_Super__national_id_4_v1.pdf',	1,	'2025-05-03 15:32:04',	'2025-05-03 15:32:04',	NULL),
(13,	29,	1,	8,	8,	'files/personal_documents/8/8/29_Wade_/29_Wade__application_letter_1_v1.pdf',	1,	'2025-05-04 16:32:36',	'2025-05-04 16:32:36',	NULL),
(14,	29,	2,	8,	8,	'files/personal_documents/8/8/29_Wade_/29_Wade__cv_2_v1.pdf',	1,	'2025-05-04 16:32:44',	'2025-05-04 16:32:44',	NULL),
(15,	29,	3,	8,	8,	'files/personal_documents/8/8/29_Wade_/29_Wade__certificates_3_v1.pdf',	1,	'2025-05-04 16:32:54',	'2025-05-04 16:32:54',	NULL),
(16,	29,	4,	8,	8,	'files/personal_documents/8/8/29_Wade_/29_Wade__national_id_4_v1.pdf',	1,	'2025-05-04 16:33:03',	'2025-05-04 16:33:03',	NULL),
(17,	29,	14,	8,	8,	'files/personal_documents/8/8/29_Wade /29_Wade _proof_of_payment_14_v1.pdf',	1,	'2025-05-04 18:03:09',	'2025-05-04 18:03:09',	NULL),
(18,	19,	16,	5,	4,	'files/personal_documents/4/5/19_Super /19_Super _blank_or_raw_bonding_form_16_v1.zip',	1,	'2025-05-05 09:48:59',	'2025-05-05 09:48:59',	NULL),
(19,	19,	16,	5,	4,	'files/personal_documents/4/5/19_Super /19_Super _blank_or_raw_bonding_form_16_v2.zip',	2,	'2025-05-05 09:50:38',	'2025-05-05 09:50:38',	NULL),
(20,	19,	16,	5,	4,	'files/personal_documents/4/5/19_Super /19_Super _blank_or_raw_bonding_form_16_v3.zip',	3,	'2025-05-05 09:52:47',	'2025-05-05 09:52:47',	NULL),
(21,	19,	16,	5,	4,	'files/personal_documents/4/5/19_Super /19_Super _blank_or_raw_bonding_form_16_v4.zip',	4,	'2025-05-05 09:53:40',	'2025-05-05 09:53:40',	NULL),
(22,	19,	16,	5,	4,	'files/personal_documents/4/5/19_Super /19_Super _blank_or_raw_bonding_form_16_v5.zip',	5,	'2025-05-05 09:54:18',	'2025-05-05 09:54:18',	NULL),
(23,	19,	16,	5,	4,	'files/personal_documents/4/5/19_Super /19_Super _blank_or_raw_bonding_form_16_v6.zip',	6,	'2025-05-05 09:54:58',	'2025-05-05 09:54:58',	NULL),
(24,	19,	16,	14,	11,	'files/personal_documents/11/14/19_Super /19_Super _blank_or_raw_bonding_form_16_v1.pdf',	1,	'2025-05-05 09:57:50',	'2025-05-05 09:57:50',	NULL),
(25,	19,	16,	14,	11,	'files/personal_documents/11/14/19_Super /19_Super _blank_or_raw_bonding_form_16_v2.pdf',	2,	'2025-05-05 09:58:17',	'2025-05-05 09:58:17',	NULL),
(26,	19,	16,	14,	11,	'files/personal_documents/11/14/19_Super /19_Super _blank_or_raw_bonding_form_16_v3.pdf',	3,	'2025-05-05 09:58:50',	'2025-05-05 09:58:50',	NULL),
(27,	29,	16,	8,	8,	'files/personal_documents/8/8/29_Wade /29_Wade _blank_or_raw_bonding_form_16_v1.zip',	1,	'2025-05-05 10:16:39',	'2025-05-05 10:16:39',	NULL),
(28,	29,	17,	8,	8,	'files/personal_documents/8/8/29_Wade /29_Wade _fully_filled_bonding_and_form_17_v1.zip',	1,	'2025-05-05 11:07:31',	'2025-05-05 11:07:31',	NULL),
(29,	29,	17,	8,	8,	'files/personal_documents/8/8/29_Wade /29_Wade _fully_filled_bonding_and_form_17_v2.pdf',	2,	'2025-05-05 11:23:14',	'2025-05-05 11:23:14',	NULL),
(30,	29,	17,	8,	8,	'files/personal_documents/8/8/29_Wade /29_Wade _fully_filled_bonding_and_form_17_v3.pdf',	3,	'2025-05-05 11:47:51',	'2025-05-05 11:47:51',	NULL),
(31,	29,	17,	8,	8,	'files/personal_documents/8/8/29_Wade /29_Wade _fully_filled_bonding_and_form_17_v4.pdf',	4,	'2025-05-05 11:49:25',	'2025-05-05 11:49:25',	NULL),
(32,	29,	1,	16,	1,	'files/personal_documents/1/16/29_Wade_/29_Wade__application_letter_1_v1.pdf',	1,	'2025-05-05 23:06:16',	'2025-05-05 23:06:16',	NULL),
(33,	29,	2,	16,	1,	'files/personal_documents/1/16/29_Wade_/29_Wade__cv_2_v1.pdf',	1,	'2025-05-05 23:06:30',	'2025-05-05 23:06:30',	NULL),
(34,	29,	3,	16,	1,	'files/personal_documents/1/16/29_Wade_/29_Wade__certificates_3_v1.pdf',	1,	'2025-05-05 23:06:44',	'2025-05-05 23:06:44',	NULL),
(35,	29,	4,	16,	1,	'files/personal_documents/1/16/29_Wade_/29_Wade__national_id_4_v1.pdf',	1,	'2025-05-05 23:07:00',	'2025-05-05 23:07:00',	NULL),
(36,	29,	16,	16,	1,	'files/personal_documents/1/16/29_Wade /29_Wade _blank_or_raw_bonding_form_16_v1.zip',	1,	'2025-05-06 05:21:35',	'2025-05-06 05:21:35',	NULL),
(37,	29,	17,	16,	1,	'files/personal_documents/1/16/29_Wade /29_Wade _fully_filled_bonding_and_form_17_v1.pdf',	1,	'2025-05-06 05:34:16',	'2025-05-06 05:34:16',	NULL);

DROP TABLE IF EXISTS `applications`;
CREATE TABLE `applications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `application_date` date NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `preffered_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `county` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `town_city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `affiliated_hospital` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `years_worked` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `preauth_inst_no_of_work_yrs` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `license_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `national_id_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `monthly_salary` double(8,2) NOT NULL,
  `phone_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `age_years` int NOT NULL,
  `date_to_begin` date NOT NULL,
  `speciality` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `training_institution_with` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `funding_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `funding_source_yes_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `supervisor_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `supervisor_full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `supervisor_designation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `supervisor_phone_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `supervisor_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `supervisor_department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emergency_first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emergency_surname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emergency_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emergency_first_contact_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emergency_secondcontact_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emergency_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `emergency_relationship` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_previous_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorized` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verification_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorized_form` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Not Uploaded',
  `short_listing_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `short_listed_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bonding_form` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Not Sent',
  `stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0%',
  `comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `verified_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_verified` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'No',
  `proof_of_payment` int DEFAULT NULL,
  `release_and_bonding_form` int DEFAULT '0',
  `institution_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `applications` (`id`, `checklist`, `application_id`, `scholarship_id`, `application_date`, `first_name`, `surname`, `preffered_name`, `country`, `county`, `town_city`, `affiliated_hospital`, `years_worked`, `preauth_inst_no_of_work_yrs`, `license_no`, `registration_no`, `national_id_pass`, `job_group`, `monthly_salary`, `phone_no`, `email_`, `gender`, `date_of_birth`, `age_years`, `date_to_begin`, `speciality`, `training_institution_with`, `funding_source`, `funding_source_yes_desc`, `supervisor_title`, `supervisor_full_name`, `supervisor_designation`, `supervisor_phone_no`, `supervisor_email`, `supervisor_department`, `emergency_first_name`, `emergency_surname`, `emergency_title`, `emergency_first_contact_no`, `emergency_secondcontact_no`, `emergency_email`, `emergency_relationship`, `reference_previous_1`, `reference_previous_2`, `reference_previous_3`, `authorized`, `verification_status`, `authorized_form`, `short_listing_status`, `short_listed_by`, `bonding_form`, `stage`, `comments`, `status`, `verified_by`, `payment_verified`, `proof_of_payment`, `release_and_bonding_form`, `institution_id`, `created_at`, `updated_at`) VALUES
(1,	1,	19,	5,	'2025-05-02',	'Carlos',	'Campos',	'Whilemina Gallegos',	'Kenya',	'kajiado',	'Laudantium consequa',	'Esse tenetur et rep',	'1993',	'Eaque non occaecat q',	'Quaerat ipsum incidi',	'Iure ut ut in ut sit',	'Amet earum et corpo',	'Necessitatibus sunt',	8.00,	'+1 (205) 717-7162',	'pucivopaz@mailinator.com',	'female',	'2012-01-12',	13,	'2025-05-13',	'Numquam est qui dolo',	'Explicabo Culpa cu',	'Yes',	'Provident quod simi',	'Sit commodi pariatu',	'Robin Mckay',	'Illo nisi minim ea n',	'+1 (518) 464-4215',	'nasorizuq@mailinator.com',	'Repellendus Deserun',	'Mikayla',	'Winters',	'Praesentium exercita',	'Enim molestiae nihil',	'Est omnis dolor dol',	'faqyqulef@mailinator.com',	'Duis est rem sapient',	'yes',	'no',	'yes',	NULL,	NULL,	'Not Uploaded',	'None',	NULL,	'23',	'100%',	'xxvxv vxvxv',	'Selected',	NULL,	'Yes',	NULL,	0,	NULL,	'2025-05-02 11:50:40',	'2025-05-05 09:54:58'),
(2,	2,	19,	27,	'2025-05-03',	'Renee',	'Hewitt',	'MacKenzie Burns',	'Kenya',	'samburu',	'Pariatur Iste rerum',	'Nostrud dolor corpor',	'1971',	'Qui dolore deserunt',	'Non id culpa quia d',	'Adipisci provident',	'Magni magni est par',	'Id earum consequatur',	4.00,	'+1 (241) 336-9588',	'jony@mailinator.com',	'female',	'2016-01-14',	9,	'2025-05-14',	'Fugiat voluptatum q',	'Eius minus architect',	'No',	'Blanditiis iusto odi',	'Sed consectetur sit',	'Kellie Durham',	'Aut dolor fuga Cons',	'+1 (962) 998-1524',	'rery@mailinator.com',	'Est illum sit dolo',	'Jerome',	'Olsen',	'Rerum voluptas aute',	'Qui consequat Quasi',	'Qui voluptatem elit',	'bazyhivoz@mailinator.com',	'Aliquid tenetur id r',	'yes',	'yes',	'yes',	NULL,	NULL,	'Not Uploaded',	'None',	NULL,	'Not Sent',	'25%',	NULL,	'Approved',	NULL,	'No',	NULL,	0,	NULL,	'2025-05-03 14:34:43',	'2025-05-05 08:17:34'),
(3,	3,	19,	14,	'2025-05-03',	'Peter',	'Wiggins',	'Hilda Meyer',	'Kenya',	'narok',	'Sequi quisquam excep',	'Anim ut vitae culpa',	'2001',	'Assumenda magnam omn',	'Laborum eos qui sint',	'Voluptatem ipsa eo',	'Facilis architecto c',	'Sint quam et dolore',	8.00,	'+1 (474) 117-4133',	'hitusixep@mailinator.com',	'female',	'2016-01-19',	9,	'2025-05-20',	'Cupidatat esse vitae',	'Tempora esse sint qu',	'Yes',	'Officia rem saepe ma',	'Occaecat facilis ius',	'Wynter Boone',	'Veniam autem et rer',	'+1 (374) 688-7034',	'sofiwuruj@mailinator.com',	'Dolores omnis culpa',	'Ashton',	'Mcgowan',	'Cumque quo ut labore',	'Commodi voluptatibus',	'Fugiat optio bland',	'wugo@mailinator.com',	'Quia cum omnis exerc',	'yes',	'yes',	'no',	NULL,	NULL,	'Not Uploaded',	'None',	NULL,	'26',	'100%',	NULL,	'Selected',	NULL,	'No',	NULL,	0,	NULL,	'2025-05-03 15:32:30',	'2025-05-05 09:58:50'),
(4,	4,	29,	8,	'2025-05-04',	'Odessa',	'Duffy',	'Justin Bullock',	'Kenya',	'kakamega',	'Eiusmod laboriosam',	'Quasi quam est dolo',	'2010',	'Quia non aperiam rem',	'Non voluptatibus nem',	'Distinctio Animi v',	'Dolore ullam officia',	'Alias totam omnis ex',	3.00,	'+1 (297) 139-7858',	'vokit@mailinator.com',	'female',	'2006-01-25',	19,	'2025-05-14',	'Sequi nobis voluptat',	'Soluta voluptatem c',	'No',	'Libero dignissimos o',	'Qui exercitation quo',	'Nolan Langley',	'Voluptatem ea ut co',	'+1 (322) 463-1602',	'vawe@mailinator.com',	'Esse laudantium al',	'Calista',	'Ellis',	'Pariatur Quae perfe',	'Similique ut exercit',	'Excepturi commodi in',	'rapyjonu@mailinator.com',	'Magni expedita quaer',	'yes',	'no',	'yes',	NULL,	NULL,	'Not Uploaded',	'None',	NULL,	'27',	'100%',	'The course was unexpectedly closed',	'Selected',	NULL,	'No',	17,	31,	NULL,	'2025-05-04 16:33:29',	'2025-05-05 11:49:25'),
(5,	5,	29,	16,	'2025-05-05',	'Breanna',	'Snider',	'Hilel Dodson',	'Kenya',	'kirinyaga',	'Soluta quasi ut sed',	'Vel maiores dolores',	'1994',	'Recusandae Facere a',	'Aut facilis consequa',	'Molestiae Nam molest',	'Id eligendi alias si',	'Consequatur voluptat',	9.00,	'+1 (299) 396-5553',	'bysabyt@mailinator.com',	'male',	'2009-01-21',	16,	'2025-05-09',	'Beatae id non placea',	'Repellendus Amet d',	'No',	'Ut ex aliquid dolore',	'Non consequatur off',	'Porter Acevedo',	'Accusantium accusant',	'+1 (737) 209-1225',	'cygo@mailinator.com',	'Corrupti perspiciat',	'Martina',	'Knox',	'Ex aut perferendis e',	'Maiores qui anim do',	'Quam illum do moles',	'vilesa@mailinator.com',	'Omnis ex commodi des',	'yes',	'no',	'no',	NULL,	NULL,	'Not Uploaded',	'None',	NULL,	'36',	'100%',	'Rejected mbaya sana',	'Selected',	NULL,	'No',	NULL,	37,	NULL,	'2025-05-05 23:07:36',	'2025-05-06 05:34:16');

DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('123456|92.255.57.103',	'i:1;',	1745371441),
('123456|92.255.57.103:timer',	'i:1745371441;',	1745371441),
('admin@gettingrealagain.com|80.64.30.32',	'i:1;',	1745374634),
('admin@gettingrealagain.com|80.64.30.32:timer',	'i:1745374634;',	1745374634),
('admin@gettingrealagain.com|92.255.57.103',	'i:1;',	1745371525),
('admin@gettingrealagain.com|92.255.57.103:timer',	'i:1745371525;',	1745371525),
('admin|80.64.30.32',	'i:2;',	1745375138),
('admin|80.64.30.32:timer',	'i:1745375137;',	1745375137),
('admin|92.255.57.103',	'i:1;',	1745371649),
('admin|92.255.57.103:timer',	'i:1745371649;',	1745371649),
('demo|80.64.30.32',	'i:1;',	1745374918),
('demo|80.64.30.32:timer',	'i:1745374918;',	1745374918),
('editor|80.64.30.32',	'i:1;',	1745374665),
('editor|80.64.30.32:timer',	'i:1745374665;',	1745374665),
('gettingrealagain|80.64.30.32',	'i:1;',	1745375041),
('gettingrealagain|80.64.30.32:timer',	'i:1745375041;',	1745375041),
('gettingrealagain|92.255.57.103',	'i:1;',	1745371147),
('gettingrealagain|92.255.57.103:timer',	'i:1745371147;',	1745371147),
('jq123456|92.255.57.103',	'i:1;',	1745371433),
('jq123456|92.255.57.103:timer',	'i:1745371433;',	1745371433),
('jqadmin@gettingrealagain.com|80.64.30.32',	'i:1;',	1745374627),
('jqadmin@gettingrealagain.com|80.64.30.32:timer',	'i:1745374627;',	1745374627),
('jqadmin@gettingrealagain.com|92.255.57.103',	'i:1;',	1745371517),
('jqadmin@gettingrealagain.com|92.255.57.103:timer',	'i:1745371517;',	1745371517),
('jqadmin|80.64.30.32',	'i:2;',	1745375130),
('jqadmin|80.64.30.32:timer',	'i:1745375130;',	1745375130),
('jqadmin|92.255.57.103',	'i:1;',	1745371642),
('jqadmin|92.255.57.103:timer',	'i:1745371642;',	1745371642),
('jqdemo|80.64.30.32',	'i:1;',	1745374911),
('jqdemo|80.64.30.32:timer',	'i:1745374911;',	1745374911),
('jqeditor|80.64.30.32',	'i:1;',	1745374658),
('jqeditor|80.64.30.32:timer',	'i:1745374658;',	1745374658),
('jqgettingrealagain|80.64.30.32',	'i:1;',	1745375034),
('jqgettingrealagain|80.64.30.32:timer',	'i:1745375034;',	1745375034),
('jqgettingrealagain|92.255.57.103',	'i:1;',	1745371140),
('jqgettingrealagain|92.255.57.103:timer',	'i:1745371140;',	1745371140),
('jqmanager|80.64.30.32',	'i:1;',	1745374880),
('jqmanager|80.64.30.32:timer',	'i:1745374880;',	1745374880),
('jqsupport|80.64.30.32',	'i:1;',	1745374972),
('jqsupport|80.64.30.32:timer',	'i:1745374972;',	1745374972),
('jqtest|80.64.30.32',	'i:1;',	1745374848),
('jqtest|80.64.30.32:timer',	'i:1745374848;',	1745374848),
('jqtesting|80.64.30.32',	'i:1;',	1745374942),
('jqtesting|80.64.30.32:timer',	'i:1745374942;',	1745374942),
('manager|80.64.30.32',	'i:1;',	1745374887),
('manager|80.64.30.32:timer',	'i:1745374887;',	1745374887),
('nniirrcn@formtest.guru|104.23.187.205',	'i:1;',	1744764140),
('nniirrcn@formtest.guru|104.23.187.205:timer',	'i:1744764140;',	1744764140),
('nniirrcn@formtest.guru|104.23.187.236',	'i:1;',	1744764141),
('nniirrcn@formtest.guru|104.23.187.236:timer',	'i:1744764141;',	1744764141),
('nniirrcn@formtest.guru|104.23.190.134',	'i:1;',	1744764139),
('nniirrcn@formtest.guru|104.23.190.134:timer',	'i:1744764139;',	1744764139),
('nniirrcn@formtest.guru|162.158.154.165',	'i:1;',	1744764139),
('nniirrcn@formtest.guru|162.158.154.165:timer',	'i:1744764139;',	1744764139),
('nniirrcn@formtest.guru|162.158.154.174',	'i:1;',	1744764140),
('nniirrcn@formtest.guru|162.158.154.174:timer',	'i:1744764140;',	1744764140),
('nniirrcn@formtest.guru|172.70.230.67',	'i:1;',	1744764141),
('nniirrcn@formtest.guru|172.70.230.67:timer',	'i:1744764141;',	1744764141),
('spatie.permission.cache',	'a:3:{s:5:\"alias\";a:3:{s:1:\"a\";s:2:\"id\";s:1:\"b\";s:4:\"name\";s:1:\"c\";s:10:\"guard_name\";}s:11:\"permissions\";a:43:{i:0;a:3:{s:1:\"a\";i:1;s:1:\"b\";s:22:\"user_management_access\";s:1:\"c\";s:3:\"web\";}i:1;a:3:{s:1:\"a\";i:2;s:1:\"b\";s:17:\"permission_create\";s:1:\"c\";s:3:\"web\";}i:2;a:3:{s:1:\"a\";i:3;s:1:\"b\";s:15:\"permission_edit\";s:1:\"c\";s:3:\"web\";}i:3;a:3:{s:1:\"a\";i:4;s:1:\"b\";s:15:\"permission_show\";s:1:\"c\";s:3:\"web\";}i:4;a:3:{s:1:\"a\";i:5;s:1:\"b\";s:17:\"permission_delete\";s:1:\"c\";s:3:\"web\";}i:5;a:3:{s:1:\"a\";i:6;s:1:\"b\";s:17:\"permission_access\";s:1:\"c\";s:3:\"web\";}i:6;a:3:{s:1:\"a\";i:7;s:1:\"b\";s:11:\"role_create\";s:1:\"c\";s:3:\"web\";}i:7;a:3:{s:1:\"a\";i:8;s:1:\"b\";s:9:\"role_edit\";s:1:\"c\";s:3:\"web\";}i:8;a:3:{s:1:\"a\";i:9;s:1:\"b\";s:9:\"role_show\";s:1:\"c\";s:3:\"web\";}i:9;a:3:{s:1:\"a\";i:10;s:1:\"b\";s:11:\"role_delete\";s:1:\"c\";s:3:\"web\";}i:10;a:3:{s:1:\"a\";i:11;s:1:\"b\";s:11:\"role_access\";s:1:\"c\";s:3:\"web\";}i:11;a:3:{s:1:\"a\";i:12;s:1:\"b\";s:11:\"user_create\";s:1:\"c\";s:3:\"web\";}i:12;a:3:{s:1:\"a\";i:13;s:1:\"b\";s:9:\"user_edit\";s:1:\"c\";s:3:\"web\";}i:13;a:3:{s:1:\"a\";i:14;s:1:\"b\";s:9:\"user_show\";s:1:\"c\";s:3:\"web\";}i:14;a:3:{s:1:\"a\";i:15;s:1:\"b\";s:11:\"user_delete\";s:1:\"c\";s:3:\"web\";}i:15;a:3:{s:1:\"a\";i:16;s:1:\"b\";s:11:\"user_access\";s:1:\"c\";s:3:\"web\";}i:16;a:3:{s:1:\"a\";i:17;s:1:\"b\";s:17:\"discipline_create\";s:1:\"c\";s:3:\"web\";}i:17;a:3:{s:1:\"a\";i:18;s:1:\"b\";s:15:\"discipline_edit\";s:1:\"c\";s:3:\"web\";}i:18;a:3:{s:1:\"a\";i:19;s:1:\"b\";s:15:\"discipline_show\";s:1:\"c\";s:3:\"web\";}i:19;a:3:{s:1:\"a\";i:20;s:1:\"b\";s:17:\"discipline_delete\";s:1:\"c\";s:3:\"web\";}i:20;a:3:{s:1:\"a\";i:21;s:1:\"b\";s:17:\"discipline_access\";s:1:\"c\";s:3:\"web\";}i:21;a:3:{s:1:\"a\";i:22;s:1:\"b\";s:18:\"institution_create\";s:1:\"c\";s:3:\"web\";}i:22;a:3:{s:1:\"a\";i:23;s:1:\"b\";s:16:\"institution_edit\";s:1:\"c\";s:3:\"web\";}i:23;a:3:{s:1:\"a\";i:24;s:1:\"b\";s:16:\"institution_show\";s:1:\"c\";s:3:\"web\";}i:24;a:3:{s:1:\"a\";i:25;s:1:\"b\";s:18:\"institution_delete\";s:1:\"c\";s:3:\"web\";}i:25;a:3:{s:1:\"a\";i:26;s:1:\"b\";s:18:\"institution_access\";s:1:\"c\";s:3:\"web\";}i:26;a:3:{s:1:\"a\";i:27;s:1:\"b\";s:13:\"course_create\";s:1:\"c\";s:3:\"web\";}i:27;a:3:{s:1:\"a\";i:28;s:1:\"b\";s:11:\"course_edit\";s:1:\"c\";s:3:\"web\";}i:28;a:3:{s:1:\"a\";i:29;s:1:\"b\";s:11:\"course_show\";s:1:\"c\";s:3:\"web\";}i:29;a:3:{s:1:\"a\";i:30;s:1:\"b\";s:13:\"course_delete\";s:1:\"c\";s:3:\"web\";}i:30;a:3:{s:1:\"a\";i:31;s:1:\"b\";s:13:\"course_access\";s:1:\"c\";s:3:\"web\";}i:31;a:3:{s:1:\"a\";i:32;s:1:\"b\";s:17:\"enrollment_create\";s:1:\"c\";s:3:\"web\";}i:32;a:3:{s:1:\"a\";i:33;s:1:\"b\";s:15:\"enrollment_edit\";s:1:\"c\";s:3:\"web\";}i:33;a:3:{s:1:\"a\";i:34;s:1:\"b\";s:15:\"enrollment_show\";s:1:\"c\";s:3:\"web\";}i:34;a:3:{s:1:\"a\";i:35;s:1:\"b\";s:17:\"enrollment_delete\";s:1:\"c\";s:3:\"web\";}i:35;a:3:{s:1:\"a\";i:36;s:1:\"b\";s:17:\"enrollment_access\";s:1:\"c\";s:3:\"web\";}i:36;a:3:{s:1:\"a\";i:37;s:1:\"b\";s:9:\"full_menu\";s:1:\"c\";s:3:\"web\";}i:37;a:3:{s:1:\"a\";i:38;s:1:\"b\";s:12:\"list_USERS_1\";s:1:\"c\";s:3:\"web\";}i:38;a:3:{s:1:\"a\";i:39;s:1:\"b\";s:11:\"super_user2\";s:1:\"c\";s:3:\"web\";}i:39;a:3:{s:1:\"a\";i:40;s:1:\"b\";s:15:\"finance_manager\";s:1:\"c\";s:3:\"web\";}i:40;a:3:{s:1:\"a\";i:41;s:1:\"b\";s:19:\"application_manager\";s:1:\"c\";s:3:\"web\";}i:41;a:3:{s:1:\"a\";i:43;s:1:\"b\";s:19:\"institution_access_\";s:1:\"c\";s:3:\"web\";}i:42;a:3:{s:1:\"a\";i:44;s:1:\"b\";s:15:\"all_file_filter\";s:1:\"c\";s:3:\"web\";}}s:5:\"roles\";a:0:{}}',	1746572737),
('support|80.64.30.32',	'i:1;',	1745374979),
('support|80.64.30.32:timer',	'i:1745374979;',	1745374979),
('test|80.64.30.32',	'i:1;',	1745374855),
('test|80.64.30.32:timer',	'i:1745374855;',	1745374855),
('testing|80.64.30.32',	'i:1;',	1745374949),
('testing|80.64.30.32:timer',	'i:1745374949;',	1745374949),
('zoho_access_token',	's:70:\"1000.e444f5613b3b8e37423a961d646c4d29.8059eeb95a1be895f701d7f1c1229312\";',	1746511917);

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `checklists`;
CREATE TABLE `checklists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `application_id` bigint NOT NULL,
  `scholarship_id` bigint NOT NULL,
  `aof_govt` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `aof_ea` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `commitment` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `not_beneficiary` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `completed_application` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'no',
  `personal_statement` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cv` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `certs` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `national_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `course_id` int DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `checklists_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `checklists` (`id`, `application_id`, `scholarship_id`, `aof_govt`, `aof_ea`, `commitment`, `not_beneficiary`, `completed_application`, `personal_statement`, `cv`, `certs`, `national_id`, `created_at`, `updated_at`, `deleted_at`, `course_id`, `institution_id`) VALUES
(1,	19,	5,	'on',	'on',	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-02 11:49:44',	'2025-05-02 11:49:44',	NULL,	NULL,	4),
(2,	19,	27,	'on',	'on',	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-03 14:33:06',	'2025-05-03 14:33:06',	NULL,	NULL,	5),
(3,	19,	14,	'on',	'on',	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-03 15:31:27',	'2025-05-03 15:31:27',	NULL,	NULL,	11),
(4,	29,	8,	'on',	'on',	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-04 16:32:28',	'2025-05-04 16:32:28',	NULL,	NULL,	8),
(5,	29,	16,	'on',	'on',	'on',	'on',	NULL,	NULL,	NULL,	NULL,	NULL,	'2025-05-05 23:06:04',	'2025-05-05 23:06:04',	NULL,	NULL,	1);

DROP TABLE IF EXISTS `course_application`;
CREATE TABLE `course_application` (
  `id` int NOT NULL AUTO_INCREMENT,
  `course_id` int NOT NULL,
  `student_id` int NOT NULL,
  `year` int NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `sponsorship_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `payment_verified` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'pending',
  `sponsorship_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_application_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `course_category`;
CREATE TABLE `course_category` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_category_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_category` (`id`, `name`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	'Higher National Diploma',	'2025-05-02 06:49:58',	'2025-05-02 06:49:58',	NULL),
(2,	'POST-MMED',	'2025-05-02 06:54:37',	'2025-05-02 06:54:37',	NULL),
(3,	'Certificate',	'2025-05-02 07:31:34',	'2025-05-02 07:31:34',	NULL);

DROP TABLE IF EXISTS `course_discipline`;
CREATE TABLE `course_discipline` (
  `course_id` int unsigned DEFAULT NULL,
  `discipline_id` int unsigned DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  KEY `course_id_fk_538846` (`course_id`),
  KEY `discipline_id_fk_538846` (`discipline_id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_discipline_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`),
  CONSTRAINT `course_id_fk_538846` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `discipline_id_fk_538846` FOREIGN KEY (`discipline_id`) REFERENCES `disciplines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_discipline` (`course_id`, `discipline_id`, `institution_id`) VALUES
(7,	1,	NULL),
(8,	1,	NULL),
(9,	1,	NULL),
(10,	1,	NULL),
(11,	1,	NULL),
(12,	1,	NULL),
(13,	1,	NULL),
(14,	1,	NULL),
(15,	1,	NULL),
(16,	1,	NULL),
(17,	1,	NULL),
(18,	1,	NULL),
(19,	1,	NULL),
(20,	1,	NULL),
(21,	1,	NULL),
(22,	1,	NULL),
(23,	1,	NULL),
(24,	1,	NULL),
(25,	1,	NULL),
(26,	1,	NULL),
(27,	1,	NULL),
(28,	1,	NULL),
(29,	1,	NULL),
(30,	1,	NULL),
(31,	1,	NULL),
(32,	1,	NULL),
(33,	1,	NULL),
(34,	1,	NULL),
(35,	1,	NULL),
(1,	1,	NULL),
(2,	1,	NULL),
(3,	1,	NULL),
(4,	1,	NULL),
(5,	1,	NULL),
(6,	1,	NULL);

DROP TABLE IF EXISTS `course_manager`;
CREATE TABLE `course_manager` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sponsor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `month_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_manager_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_manager` (`id`, `name`, `sponsor`, `category_id`, `month_id`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	'Paediatric Critical Care Nursing (PCCN)',	NULL,	1,	2,	'2025-05-02 07:33:19',	'2025-05-02 07:33:19',	NULL),
(2,	'Paediatric Nursing (PNT)',	NULL,	1,	2,	'2025-05-02 07:42:02',	'2025-05-02 07:42:02',	NULL),
(3,	'Midwifery',	NULL,	1,	1,	'2025-05-02 07:42:15',	'2025-05-02 07:42:15',	NULL),
(4,	'Neonatal Nursing',	NULL,	1,	2,	'2025-05-02 07:42:28',	'2025-05-02 07:42:28',	NULL),
(5,	'Paediatric Oncology Nursing',	NULL,	1,	2,	'2025-05-02 07:42:43',	'2025-05-02 07:42:43',	NULL),
(6,	'Ophthalmology and cataract surgery',	NULL,	1,	2,	'2025-05-02 07:42:58',	'2025-05-02 07:42:58',	NULL),
(7,	'Audiology and hearing technology',	NULL,	1,	2,	'2025-05-02 07:43:12',	'2025-05-02 07:43:12',	NULL),
(8,	'Orthopaedic technology specialisation in  prosthetics/orthotics',	NULL,	1,	2,	'2025-05-02 07:43:24',	'2025-05-02 07:43:24',	NULL),
(9,	'Ophthalmology advanced refraction and low vision',	NULL,	1,	2,	'2025-05-02 07:43:36',	'2025-05-02 07:43:36',	NULL),
(10,	'Speech and language therapy',	NULL,	1,	2,	'2025-05-02 07:43:55',	'2025-05-02 07:43:55',	NULL),
(11,	'Low vision and assistive technology',	NULL,	1,	2,	'2025-05-02 07:44:19',	'2025-05-02 07:44:19',	NULL),
(12,	'Neonatology',	NULL,	2,	2,	'2025-05-02 07:44:50',	'2025-05-02 07:44:50',	NULL),
(13,	'Paediatric Neurology',	NULL,	2,	2,	'2025-05-02 07:45:04',	'2025-05-02 07:45:04',	NULL),
(14,	'Paediatric Emergency & Critical Care Medicine',	NULL,	2,	2,	'2025-05-02 07:45:22',	'2025-05-02 07:45:22',	NULL),
(15,	'Paediatric Endocrinology',	NULL,	2,	2,	'2025-05-02 07:45:37',	'2025-05-02 07:45:37',	NULL),
(16,	'Paediatric Haemato-oncology',	NULL,	2,	2,	'2025-05-02 07:45:48',	'2025-05-02 07:45:48',	NULL),
(17,	'Paediatric Clinical Infectious Diseases',	NULL,	2,	2,	'2025-05-02 07:46:11',	'2025-05-02 07:46:11',	NULL),
(18,	'Paediatric Gastroenterology',	NULL,	2,	2,	'2025-05-02 07:46:27',	'2025-05-02 07:51:00',	NULL),
(19,	'Paediatric Cardiology',	NULL,	2,	2,	'2025-05-02 07:46:51',	'2025-05-02 07:46:51',	NULL),
(20,	'Paediatric Pulmonology',	NULL,	2,	2,	'2025-05-02 07:47:09',	'2025-05-02 07:47:09',	NULL),
(21,	'Paediatric Nephrology',	NULL,	2,	2,	'2025-05-02 08:50:02',	'2025-05-02 08:50:02',	NULL);

DROP TABLE IF EXISTS `course_months`;
CREATE TABLE `course_months` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `course_months` (`id`, `name`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	'2.5 Years',	'2025-05-02 07:30:52',	'2025-05-02 07:30:52',	NULL),
(2,	'2 Years',	'2025-05-02 07:31:02',	'2025-05-02 07:31:02',	NULL);

DROP TABLE IF EXISTS `course_uploads`;
CREATE TABLE `course_uploads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `national_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nck_lic` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `nck_cert` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `kcse_cse` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `passport` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `application_letter` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `dip_deg` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  `institution_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `manager_id` int DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `price` decimal(15,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_fk_538844` (`institution_id`),
  CONSTRAINT `institution_fk_538844` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `courses` (`id`, `manager_id`, `description`, `price`, `created_at`, `updated_at`, `deleted_at`, `institution_id`) VALUES
(1,	3,	'<p>Course Description</p>',	NULL,	'2025-05-02 08:32:41',	'2025-05-02 08:32:41',	NULL,	4),
(2,	12,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:35:07',	'2025-05-02 08:35:07',	NULL,	4),
(3,	13,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:35:31',	'2025-05-02 08:35:31',	NULL,	4),
(4,	18,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:35:50',	'2025-05-02 08:35:50',	NULL,	4),
(5,	19,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:36:20',	'2025-05-02 08:36:20',	NULL,	4),
(6,	20,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:36:42',	'2025-05-02 08:36:42',	NULL,	4),
(7,	1,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:37:08',	'2025-05-02 08:37:08',	NULL,	8),
(8,	2,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:37:22',	'2025-05-02 08:37:22',	NULL,	8),
(9,	5,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:37:39',	'2025-05-02 08:37:39',	NULL,	8),
(10,	6,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:38:01',	'2025-05-02 08:38:01',	NULL,	11),
(11,	7,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:38:17',	'2025-05-02 08:38:17',	NULL,	11),
(12,	8,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:38:32',	'2025-05-02 08:38:32',	NULL,	11),
(13,	9,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:38:49',	'2025-05-02 08:38:49',	NULL,	11),
(14,	10,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:39:06',	'2025-05-02 08:39:06',	NULL,	11),
(15,	11,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:39:18',	'2025-05-02 08:39:18',	NULL,	11),
(16,	4,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:39:44',	'2025-05-02 08:39:44',	NULL,	1),
(18,	5,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:41:59',	'2025-05-02 08:41:59',	NULL,	9),
(19,	12,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:42:48',	'2025-05-02 08:42:48',	NULL,	9),
(20,	13,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:45:26',	'2025-05-02 08:45:26',	NULL,	9),
(21,	14,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:45:41',	'2025-05-02 08:45:41',	NULL,	9),
(22,	16,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:45:58',	'2025-05-02 08:45:58',	NULL,	9),
(23,	12,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:46:22',	'2025-05-02 09:31:26',	NULL,	5),
(24,	14,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:46:40',	'2025-05-02 09:30:50',	NULL,	5),
(25,	15,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:47:46',	'2025-05-02 08:47:46',	NULL,	5),
(26,	16,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:47:59',	'2025-05-02 08:47:59',	NULL,	5),
(27,	17,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:48:15',	'2025-05-02 08:48:15',	NULL,	5),
(28,	18,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:48:32',	'2025-05-02 08:48:32',	NULL,	5),
(29,	21,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:50:20',	'2025-05-02 08:50:20',	NULL,	5),
(30,	20,	'<p>&nbsp;</p>',	NULL,	'2025-05-02 08:50:38',	'2025-05-02 08:50:38',	NULL,	5);

DROP TABLE IF EXISTS `disciplines`;
CREATE TABLE `disciplines` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `disciplines_name_unique` (`name`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `disciplines_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `disciplines` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`, `institution_id`) VALUES
(1,	'Scholarships',	NULL,	NULL,	NULL,	8);

DROP TABLE IF EXISTS `disclaimer`;
CREATE TABLE `disclaimer` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `disclaimer_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disclaimer_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `disclaimer_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `disclaimer` (`id`, `checklist`, `application_id`, `scholarship_id`, `disclaimer_1`, `disclaimer_2`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	1,	19,	5,	'Agree',	'Agree',	'2025-05-02 12:00:12',	'2025-05-02 12:00:12',	NULL),
(2,	2,	19,	27,	'Agree',	'Agree',	'2025-05-03 14:34:49',	'2025-05-03 14:34:49',	NULL),
(3,	3,	19,	14,	'Agree',	'Agree',	'2025-05-03 15:32:36',	'2025-05-03 15:32:36',	NULL),
(4,	4,	29,	8,	'Agree',	'Agree',	'2025-05-04 16:34:43',	'2025-05-04 16:34:43',	NULL),
(5,	5,	29,	16,	'Agree',	'Agree',	'2025-05-05 23:08:01',	'2025-05-05 23:08:01',	NULL);

DROP TABLE IF EXISTS `employment`;
CREATE TABLE `employment` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `previous_organization` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_organization_from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_organization_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_job_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_supervisor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_responsibilities` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_previous_phone_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `employment_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `employment` (`id`, `checklist`, `application_id`, `scholarship_id`, `previous_organization`, `previous_organization_from`, `reference_previous_organization_to`, `reference_previous_job_title`, `reference_previous_supervisor`, `reference_previous_responsibilities`, `reference_previous_phone_no`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	1,	19,	5,	'Riggs and Day Inc',	'Stokes and Tillman Trading',	'Erickson Kirk Traders',	'Consequuntur alias i',	'zimof@mailinator.com',	'Laboris nulla aspern',	'64',	'2025-05-02 11:50:40',	'2025-05-02 11:50:40',	NULL),
(2,	1,	19,	5,	'William Albert LLC',	'Phelps and Brady Traders',	'Allen and Gonzales Traders',	'Eu sunt est repudia',	'xikuxa@mailinator.com',	'Id eum voluptas rer',	'+1 (947) 747-9017',	'2025-05-02 11:50:40',	'2025-05-02 11:50:40',	NULL),
(3,	1,	19,	5,	'Hurst Castro LLC',	'Rowland and Durham Trading',	'Mitchell and Vasquez Inc',	'Cillum non animi es',	'xasiq@mailinator.com',	'Reprehenderit conse',	'78',	'2025-05-02 11:50:40',	'2025-05-02 11:50:40',	NULL),
(4,	2,	19,	27,	'Morales and Wong Plc',	'Fisher and Barber Inc',	'Sanford and Bullock Plc',	'Molestias sunt neque',	'gixedodapy@mailinator.com',	'Neque molestiae offi',	'98',	'2025-05-03 14:34:43',	'2025-05-03 14:34:43',	NULL),
(5,	2,	19,	27,	'Gilliam Petersen Associates',	'Preston and Jefferson Associates',	'Rowland and Banks LLC',	'Similique dolorum ve',	'tesobifydo@mailinator.com',	'Fugit dicta officia',	'+1 (298) 783-4483',	'2025-05-03 14:34:43',	'2025-05-03 14:34:43',	NULL),
(6,	2,	19,	27,	'Shepard Rogers Inc',	'Rivas Frank Traders',	'King Robinson LLC',	'Aliquip magni ad aut',	'barubej@mailinator.com',	'Dolores pariatur Ve',	'24',	'2025-05-03 14:34:43',	'2025-05-03 14:34:43',	NULL),
(7,	3,	19,	14,	'Browning Gibson Co',	'Whitehead Wilkinson LLC',	'Conner and Mcdonald Plc',	'Et eaque consequatur',	'zokexoliq@mailinator.com',	'Nihil consequatur v',	'49',	'2025-05-03 15:32:30',	'2025-05-03 15:32:30',	NULL),
(8,	3,	19,	14,	'Miranda Burris Traders',	'Williams and Gallegos Plc',	'Downs Duke Plc',	'Libero duis voluptat',	'tiqukocic@mailinator.com',	'Quo occaecat qui quo',	'+1 (855) 402-7986',	'2025-05-03 15:32:30',	'2025-05-03 15:32:30',	NULL),
(9,	3,	19,	14,	'Edwards Avila Trading',	'Sheppard and Henson Associates',	'Ochoa and Bond Plc',	'Voluptas laudantium',	'gulani@mailinator.com',	'Sunt et Nam error d',	'31',	'2025-05-03 15:32:30',	'2025-05-03 15:32:30',	NULL),
(10,	4,	29,	8,	'Mann and Head LLC',	'Russell Walsh Plc',	'Wall Hutchinson Inc',	'Esse est et sequi l',	'selamazut@mailinator.com',	'Nisi id ipsum venia',	'79',	'2025-05-04 16:33:29',	'2025-05-04 16:33:29',	NULL),
(11,	4,	29,	8,	'Moran and Carrillo LLC',	'Carlson and Rose LLC',	'Solomon Crosby LLC',	'Esse dicta vero sed',	'feticive@mailinator.com',	'Irure corporis id mi',	'+1 (906) 329-8161',	'2025-05-04 16:33:29',	'2025-05-04 16:33:29',	NULL),
(12,	4,	29,	8,	'Franklin Hess Co',	'Butler and Bradford LLC',	'Cummings and Price LLC',	'Magnam deserunt nemo',	'mawisisy@mailinator.com',	'Ipsa dolore ipsum i',	'37',	'2025-05-04 16:33:29',	'2025-05-04 16:33:29',	NULL),
(13,	5,	29,	16,	'Giles and Leblanc Inc',	'Sawyer and Dillard Trading',	'Rocha Henry LLC',	'Eum minima impedit',	'gyhi@mailinator.com',	'Aut qui quo veniam',	'95',	'2025-05-05 23:07:36',	'2025-05-05 23:07:36',	NULL),
(14,	5,	29,	16,	'Ward and Finch Plc',	'Tillman and Pruitt LLC',	'Acosta and Mcneil Traders',	'Nihil error id volup',	'xuzibaro@mailinator.com',	'Laborum Quos eos a',	'+1 (932) 597-4215',	'2025-05-05 23:07:36',	'2025-05-05 23:07:36',	NULL),
(15,	5,	29,	16,	'Ewing Payne Inc',	'Ochoa Hodge Inc',	'Willis Dickson Plc',	'Tempor saepe sit el',	'qatam@mailinator.com',	'Illo qui et ratione',	'63',	'2025-05-05 23:07:36',	'2025-05-05 23:07:36',	NULL);

DROP TABLE IF EXISTS `enrollments`;
CREATE TABLE `enrollments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'awaiting',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `user_id` int unsigned NOT NULL,
  `course_id` int unsigned NOT NULL,
  `institution_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_fk_538851` (`user_id`),
  KEY `course_fk_538852` (`course_id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `course_fk_538852` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`),
  CONSTRAINT `user_fk_538851` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `institutions`;
CREATE TABLE `institutions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `institutions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `institutions` (`id`, `name`, `email`, `phone`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Kenyatta National School of Nursing',	'knhadmin@knh.or.ke',	'+254 020 2726300, +254 709854000, +254 730643000',	'2023-12-09 03:50:17',	'2025-05-06 06:17:25',	NULL),
(3,	'KPFP Scholarships Admin',	'KPFP',	NULL,	'2025-02-06 03:46:45',	'2025-02-06 03:46:45',	NULL),
(4,	'The Aga Khan University',	'mc.ea@aku.edu',	'+254 20 366 2232',	'2025-02-06 03:46:45',	'2025-05-06 06:15:30',	NULL),
(5,	'The University Of Nairobi (UON)',	'info@uonbi.ac.ke',	'(+254) 020-4910000',	'2025-02-06 03:46:45',	'2025-05-06 06:14:22',	NULL),
(8,	'Gertrude\'s Children\'s Hospital',	'trainingschool@gerties.org',	'+254 759 297589',	'2025-01-29 16:10:55',	'2025-05-06 06:12:16',	NULL),
(9,	'MOI University',	'info@mu.ac.ke',	'+254 790 940 508, +254 736 138 770',	'2025-04-02 07:26:42',	'2025-05-06 06:09:53',	NULL),
(11,	'Kenya Medical Training College (KMTC)',	'admissions@kmtc.ac.ke',	'-',	'2025-05-02 04:28:42',	'2025-05-06 06:07:22',	NULL);

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `jobs` (`id`, `queue`, `payload`, `attempts`, `reserved_at`, `available_at`, `created_at`) VALUES
(1,	'default',	'{\"uuid\":\"f3c82792-355a-4324-9ac1-afb76c49320a\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159228,	1746159228),
(2,	'default',	'{\"uuid\":\"4b0e0153-b862-407e-bcde-226515e8bef8\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:2;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159521,	1746159521),
(3,	'default',	'{\"uuid\":\"65872d3c-bd19-44bb-90f5-19d608b21f54\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:3;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159631,	1746159631),
(4,	'default',	'{\"uuid\":\"3d0cf4cc-3866-4a18-b232-6094176fea68\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:4;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159734,	1746159734),
(5,	'default',	'{\"uuid\":\"6544e8b8-2cb7-4fa3-be30-d07d4adcaa7b\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:5;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159908,	1746159908),
(6,	'default',	'{\"uuid\":\"08c42c1c-8227-45ea-944d-87261ce0ba2b\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:6;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746159981,	1746159981),
(7,	'default',	'{\"uuid\":\"0463d444-f1d6-48c8-83c6-f8c38ccb2ce7\",\"displayName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\",\"command\":\"O:58:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Jobs\\\\PerformConversionsJob\\\":6:{s:14:\\\"\\u0000*\\u0000conversions\\\";O:52:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\ConversionCollection\\\":2:{s:8:\\\"\\u0000*\\u0000items\\\";a:1:{i:0;O:42:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Conversion\\\":11:{s:12:\\\"\\u0000*\\u0000fileNamer\\\";O:54:\\\"Spatie\\\\MediaLibrary\\\\Support\\\\FileNamer\\\\DefaultFileNamer\\\":0:{}s:28:\\\"\\u0000*\\u0000extractVideoFrameAtSecond\\\";d:0;s:16:\\\"\\u0000*\\u0000manipulations\\\";O:45:\\\"Spatie\\\\MediaLibrary\\\\Conversions\\\\Manipulations\\\":1:{s:16:\\\"\\u0000*\\u0000manipulations\\\";a:4:{s:8:\\\"optimize\\\";a:1:{i:0;O:36:\\\"Spatie\\\\ImageOptimizer\\\\OptimizerChain\\\":3:{s:13:\\\"\\u0000*\\u0000optimizers\\\";a:7:{i:0;O:42:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Jpegoptim\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m85\\\";i:1;s:7:\\\"--force\\\";i:2;s:11:\\\"--strip-all\\\";i:3;s:17:\\\"--all-progressive\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:9:\\\"jpegoptim\\\";}i:1;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Pngquant\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:7:\\\"--force\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"pngquant\\\";}i:2;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Optipng\\\":5:{s:7:\\\"options\\\";a:3:{i:0;s:3:\\\"-i0\\\";i:1;s:3:\\\"-o2\\\";i:2;s:6:\\\"-quiet\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"optipng\\\";}i:3;O:37:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Svgo\\\":5:{s:7:\\\"options\\\";a:1:{i:0;s:20:\\\"--disable=cleanupIDs\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:4:\\\"svgo\\\";}i:4;O:41:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Gifsicle\\\":5:{s:7:\\\"options\\\";a:2:{i:0;s:2:\\\"-b\\\";i:1;s:3:\\\"-O3\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:8:\\\"gifsicle\\\";}i:5;O:38:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Cwebp\\\":5:{s:7:\\\"options\\\";a:4:{i:0;s:4:\\\"-m 6\\\";i:1;s:8:\\\"-pass 10\\\";i:2;s:3:\\\"-mt\\\";i:3;s:5:\\\"-q 90\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:5:\\\"cwebp\\\";}i:6;O:40:\\\"Spatie\\\\ImageOptimizer\\\\Optimizers\\\\Avifenc\\\":6:{s:7:\\\"options\\\";a:8:{i:0;s:14:\\\"-a cq-level=23\\\";i:1;s:6:\\\"-j all\\\";i:2;s:7:\\\"--min 0\\\";i:3;s:8:\\\"--max 63\\\";i:4;s:12:\\\"--minalpha 0\\\";i:5;s:13:\\\"--maxalpha 63\\\";i:6;s:14:\\\"-a end-usage=q\\\";i:7;s:12:\\\"-a tune=ssim\\\";}s:9:\\\"imagePath\\\";s:0:\\\"\\\";s:10:\\\"binaryPath\\\";s:0:\\\"\\\";s:7:\\\"tmpPath\\\";N;s:10:\\\"binaryName\\\";s:7:\\\"avifenc\\\";s:16:\\\"decodeBinaryName\\\";s:7:\\\"avifdec\\\";}}s:9:\\\"\\u0000*\\u0000logger\\\";O:33:\\\"Spatie\\\\ImageOptimizer\\\\DummyLogger\\\":0:{}s:10:\\\"\\u0000*\\u0000timeout\\\";i:60;}}s:6:\\\"format\\\";a:1:{i:0;s:3:\\\"jpg\\\";}s:5:\\\"width\\\";a:1:{i:0;i:50;}s:6:\\\"height\\\";a:1:{i:0;i:50;}}}s:23:\\\"\\u0000*\\u0000performOnCollections\\\";a:0:{}s:17:\\\"\\u0000*\\u0000performOnQueue\\\";b:1;s:26:\\\"\\u0000*\\u0000keepOriginalImageFormat\\\";b:0;s:27:\\\"\\u0000*\\u0000generateResponsiveImages\\\";b:0;s:18:\\\"\\u0000*\\u0000widthCalculator\\\";N;s:24:\\\"\\u0000*\\u0000loadingAttributeValue\\\";N;s:16:\\\"\\u0000*\\u0000pdfPageNumber\\\";i:1;s:7:\\\"\\u0000*\\u0000name\\\";s:5:\\\"thumb\\\";}}s:28:\\\"\\u0000*\\u0000escapeWhenCastingToString\\\";b:0;}s:8:\\\"\\u0000*\\u0000media\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:49:\\\"Spatie\\\\MediaLibrary\\\\MediaCollections\\\\Models\\\\Media\\\";s:2:\\\"id\\\";i:7;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:14:\\\"\\u0000*\\u0000onlyMissing\\\";b:0;s:10:\\\"connection\\\";s:8:\\\"database\\\";s:5:\\\"queue\\\";s:0:\\\"\\\";s:11:\\\"afterCommit\\\";b:1;}\"}}',	0,	NULL,	1746160122,	1746160122);

DROP VIEW IF EXISTS `master_course_app`;
CREATE TABLE `master_course_app` (`id` int, `payment_verified` varchar(20), `course` varchar(255), `category` varchar(255), `period` varchar(267), `status` varchar(20), `phone` varchar(20), `gender` varchar(10), `dob` date, `application_id` int unsigned, `name` varchar(152), `created_at` timestamp, `age` bigint, `national_id` varchar(100), `nck_lic` varchar(100), `nck_cert` varchar(100), `kcse_cse` varchar(100), `passport` varchar(100), `sponsorship_id` varchar(100), `institution_id` int unsigned);


DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `uuid` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_column` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `media_chk_1` CHECK (json_valid(`manipulations`)),
  CONSTRAINT `media_chk_2` CHECK (json_valid(`custom_properties`)),
  CONSTRAINT `media_chk_3` CHECK (json_valid(`responsive_images`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`, `institution_id`) VALUES
(2,	'App\\Models\\Institution',	9,	'5dc1040a-5f33-4012-94b4-d0fc96e7a2b0',	'logo',	'6814479f50a77_Moi_University_logo',	'6814479f50a77_Moi_University_logo.jpg',	'image/jpeg',	'public',	'public',	66098,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:18:41',	'2025-05-02 04:18:41',	NULL),
(3,	'App\\Models\\Institution',	8,	'd4279371-ca59-4775-856c-b837c0bae1e1',	'logo',	'681447f89f49f_gertrudes logo',	'681447f89f49f_gertrudes-logo.png',	'image/png',	'public',	'public',	8522,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:20:31',	'2025-05-02 04:20:31',	NULL),
(4,	'App\\Models\\Institution',	5,	'4b2ae472-7e97-45f4-8f7b-b3b7dfb57e26',	'logo',	'681448755e639_UoN Logo_0',	'681448755e639_UoN-Logo_0.jpg',	'image/jpeg',	'public',	'public',	212528,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:22:14',	'2025-05-02 04:22:14',	NULL),
(5,	'App\\Models\\Institution',	4,	'ad8bb258-aa4c-4257-86f5-cfeadd0bca0f',	'logo',	'6814492277413_agh khan university',	'6814492277413_agh-khan-university.jpg',	'image/jpeg',	'public',	'public',	14217,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:25:08',	'2025-05-02 04:25:08',	NULL),
(6,	'App\\Models\\Institution',	1,	'11376e46-6169-420c-a4dd-fb18ca71f1ea',	'logo',	'6814496c101b5_kenyatta transparent_logo',	'6814496c101b5_kenyatta-transparent_logo.png',	'image/png',	'public',	'public',	211324,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:26:21',	'2025-05-02 04:26:21',	NULL),
(7,	'App\\Models\\Institution',	11,	'6f183d20-144b-4124-9c2a-156eb3705cb7',	'logo',	'681449f7bf6c4_KMTC cropped-download',	'681449f7bf6c4_KMTC-cropped-download.jpg',	'image/jpeg',	'public',	'public',	11814,	'[]',	'[]',	'[]',	'[]',	1,	'2025-05-02 04:28:42',	'2025-05-02 04:28:42',	NULL);

DROP TABLE IF EXISTS `messaging`;
CREATE TABLE `messaging` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` bigint DEFAULT NULL,
  `receiver_id` bigint DEFAULT NULL,
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `messaging_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2,	'2016_06_01_000001_create_oauth_auth_codes_table',	1),
(3,	'2016_06_01_000002_create_oauth_access_tokens_table',	1),
(4,	'2016_06_01_000003_create_oauth_refresh_tokens_table',	1),
(5,	'2016_06_01_000004_create_oauth_clients_table',	1),
(6,	'2016_06_01_000005_create_oauth_personal_access_clients_table',	1),
(7,	'2019_10_30_000001_create_media_table',	1),
(11,	'2019_10_30_000005_create_disciplines_table',	1),
(12,	'2019_10_30_000006_create_institutions_table',	1),
(13,	'2019_10_30_000007_create_courses_table',	1),
(14,	'2019_10_30_000008_create_enrollments_table',	1),
(15,	'2019_10_30_000009_create_permission_role_pivot_table',	1),
(16,	'2019_10_30_000010_create_role_user_pivot_table',	1),
(17,	'2019_10_30_000011_create_course_discipline_pivot_table',	1),
(18,	'2019_10_30_000012_add_relationship_fields_to_users_table',	1),
(19,	'2019_10_30_000013_add_relationship_fields_to_courses_table',	1),
(20,	'2019_10_30_000014_add_relationship_fields_to_enrollments_table',	1),
(41,	'2023_12_10_183057_create_table_checklist',	2),
(43,	'2023_12_13_175407_create_table_academic_history',	2),
(44,	'2023_12_13_175808_create_table_qualification_attained',	2),
(45,	'2023_12_13_180030_create_table_professional_references',	2),
(46,	'2023_12_13_180339_create_table_employment',	2),
(47,	'2023_12_13_180845_create_table_disclaimer',	3),
(50,	'2023_12_18_101952_create_table_messaging',	4),
(51,	'2023_12_20_170127_create_payment_proofs_table',	5),
(52,	'2023_12_13_143416_create_applications_table',	6),
(53,	'2024_05_20_122311_create_categories_table',	7),
(54,	'2024_05_21_122311_create_course_months_table',	8),
(55,	'2024_05_21_122312_create_course_manager_table',	9),
(58,	'0001_01_01_000002_create_jobs_table',	11),
(60,	'0001_01_01_000001_create_cache_table',	12),
(62,	'2019_10_30_000002_create_permissions_table',	13),
(63,	'2019_10_30_000003_create_roles_table',	13),
(65,	'2014_10_12_100000_create_password_resets_table',	14),
(70,	'2025_01_01_000000_create_users_table',	15),
(72,	'2025_01_27_061326_create_landlord_tenants_table',	16);

DROP TABLE IF EXISTS `mode_of_payments`;
CREATE TABLE `mode_of_payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `institution_id` int unsigned DEFAULT NULL,
  `mobile_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `mobile_paybill` int DEFAULT NULL,
  `mobile_paybill_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `mobile_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `bank_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `bank_branch` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `account_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `account_number` int DEFAULT NULL,
  `amount` float(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `mode_of_payments_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `mode_of_payments` (`id`, `institution_id`, `mobile_name`, `mobile_paybill`, `mobile_paybill_no`, `mobile_number`, `bank_name`, `bank_branch`, `account_name`, `account_number`, `amount`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	8,	'MPESA',	1,	'001001',	NULL,	'Barclays Bank',	'Nairobi',	'Gerties Nursing School',	100010001,	2000.00,	'Yes',	'2025-03-26 04:41:23',	'2025-05-04 17:49:01',	NULL),
(2,	4,	'MPESA',	6489898,	'15556',	NULL,	'Lewis Sweet',	'Omnis reiciendis qui',	'Philip Larson',	381,	1800.00,	'Yes',	'2025-03-26 04:43:57',	'2025-05-04 17:26:19',	NULL),
(3,	5,	'MPESA',	1682937,	'800000',	NULL,	'Felicia Mays',	'Adipisicing odio ips',	'Edan Reed',	423,	1500.00,	'Yes',	'2025-03-26 04:45:25',	'2025-05-04 17:26:14',	NULL),
(4,	1,	'MPESA',	53222,	'9703944',	NULL,	'Grant Tate',	'Perspiciatis veniam',	'Nell Mckee',	588,	2000.00,	'Yes',	'2025-03-26 05:04:53',	'2025-05-04 17:26:10',	NULL),
(5,	9,	'MPESA',	6373837,	'8387373',	NULL,	'Coop Bank',	'Nairobi',	'Moi University',	100010001,	2300.00,	'Yes',	'2025-04-02 07:31:15',	'2025-05-04 17:24:19',	NULL);

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'App\\Models\\User',
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `model_has_permissions` (`permission_id`, `model_type`, `model_id`) VALUES
(1,	'App\\Models\\User',	19),
(2,	'App\\Models\\User',	19),
(3,	'App\\Models\\User',	19),
(4,	'App\\Models\\User',	19),
(5,	'App\\Models\\User',	19),
(6,	'App\\Models\\User',	19),
(7,	'App\\Models\\User',	19),
(8,	'App\\Models\\User',	19),
(9,	'App\\Models\\User',	19),
(10,	'App\\Models\\User',	19),
(11,	'App\\Models\\User',	19),
(12,	'App\\Models\\User',	19),
(13,	'App\\Models\\User',	19),
(14,	'App\\Models\\User',	19),
(15,	'App\\Models\\User',	19),
(16,	'App\\Models\\User',	19),
(17,	'App\\Models\\User',	19),
(18,	'App\\Models\\User',	19),
(19,	'App\\Models\\User',	19),
(20,	'App\\Models\\User',	19),
(21,	'App\\Models\\User',	19),
(22,	'App\\Models\\User',	19),
(23,	'App\\Models\\User',	19),
(24,	'App\\Models\\User',	19),
(25,	'App\\Models\\User',	19),
(26,	'App\\Models\\User',	19),
(27,	'App\\Models\\User',	19),
(28,	'App\\Models\\User',	19),
(29,	'App\\Models\\User',	19),
(30,	'App\\Models\\User',	19),
(31,	'App\\Models\\User',	19),
(32,	'App\\Models\\User',	19),
(33,	'App\\Models\\User',	19),
(34,	'App\\Models\\User',	19),
(35,	'App\\Models\\User',	19),
(36,	'App\\Models\\User',	19),
(37,	'App\\Models\\User',	19),
(40,	'App\\Models\\User',	19),
(41,	'App\\Models\\User',	19),
(43,	'App\\Models\\User',	19),
(44,	'App\\Models\\User',	19),
(12,	'App\\Models\\User',	20),
(13,	'App\\Models\\User',	20),
(14,	'App\\Models\\User',	20),
(15,	'App\\Models\\User',	20),
(16,	'App\\Models\\User',	20),
(27,	'App\\Models\\User',	20),
(28,	'App\\Models\\User',	20),
(29,	'App\\Models\\User',	20),
(30,	'App\\Models\\User',	20),
(31,	'App\\Models\\User',	20),
(32,	'App\\Models\\User',	20),
(33,	'App\\Models\\User',	20),
(34,	'App\\Models\\User',	20),
(35,	'App\\Models\\User',	20),
(36,	'App\\Models\\User',	20),
(40,	'App\\Models\\User',	20),
(41,	'App\\Models\\User',	20),
(12,	'App\\Models\\User',	22),
(13,	'App\\Models\\User',	22),
(14,	'App\\Models\\User',	22),
(15,	'App\\Models\\User',	22),
(16,	'App\\Models\\User',	22),
(27,	'App\\Models\\User',	22),
(28,	'App\\Models\\User',	22),
(29,	'App\\Models\\User',	22),
(30,	'App\\Models\\User',	22),
(31,	'App\\Models\\User',	22),
(32,	'App\\Models\\User',	22),
(33,	'App\\Models\\User',	22),
(34,	'App\\Models\\User',	22),
(35,	'App\\Models\\User',	22),
(36,	'App\\Models\\User',	22),
(40,	'App\\Models\\User',	22),
(41,	'App\\Models\\User',	22),
(12,	'App\\Models\\User',	23),
(13,	'App\\Models\\User',	23),
(14,	'App\\Models\\User',	23),
(15,	'App\\Models\\User',	23),
(16,	'App\\Models\\User',	23),
(27,	'App\\Models\\User',	23),
(28,	'App\\Models\\User',	23),
(29,	'App\\Models\\User',	23),
(30,	'App\\Models\\User',	23),
(31,	'App\\Models\\User',	23),
(32,	'App\\Models\\User',	23),
(33,	'App\\Models\\User',	23),
(34,	'App\\Models\\User',	23),
(35,	'App\\Models\\User',	23),
(36,	'App\\Models\\User',	23),
(40,	'App\\Models\\User',	23),
(41,	'App\\Models\\User',	23),
(12,	'App\\Models\\User',	24),
(13,	'App\\Models\\User',	24),
(14,	'App\\Models\\User',	24),
(15,	'App\\Models\\User',	24),
(16,	'App\\Models\\User',	24),
(27,	'App\\Models\\User',	24),
(28,	'App\\Models\\User',	24),
(29,	'App\\Models\\User',	24),
(30,	'App\\Models\\User',	24),
(31,	'App\\Models\\User',	24),
(32,	'App\\Models\\User',	24),
(33,	'App\\Models\\User',	24),
(34,	'App\\Models\\User',	24),
(35,	'App\\Models\\User',	24),
(36,	'App\\Models\\User',	24),
(40,	'App\\Models\\User',	24),
(41,	'App\\Models\\User',	24),
(12,	'App\\Models\\User',	26),
(13,	'App\\Models\\User',	26),
(14,	'App\\Models\\User',	26),
(15,	'App\\Models\\User',	26),
(16,	'App\\Models\\User',	26),
(27,	'App\\Models\\User',	26),
(28,	'App\\Models\\User',	26),
(29,	'App\\Models\\User',	26),
(30,	'App\\Models\\User',	26),
(31,	'App\\Models\\User',	26),
(32,	'App\\Models\\User',	26),
(33,	'App\\Models\\User',	26),
(34,	'App\\Models\\User',	26),
(35,	'App\\Models\\User',	26),
(36,	'App\\Models\\User',	26),
(40,	'App\\Models\\User',	26),
(41,	'App\\Models\\User',	26),
(7,	'App\\Models\\User',	51),
(8,	'App\\Models\\User',	51),
(9,	'App\\Models\\User',	51),
(10,	'App\\Models\\User',	51),
(11,	'App\\Models\\User',	51),
(1,	'App\\Models\\User',	52),
(2,	'App\\Models\\User',	52),
(3,	'App\\Models\\User',	52),
(4,	'App\\Models\\User',	52),
(5,	'App\\Models\\User',	52),
(6,	'App\\Models\\User',	52),
(7,	'App\\Models\\User',	52),
(8,	'App\\Models\\User',	52),
(9,	'App\\Models\\User',	52),
(10,	'App\\Models\\User',	52),
(11,	'App\\Models\\User',	52),
(12,	'App\\Models\\User',	52),
(13,	'App\\Models\\User',	52),
(14,	'App\\Models\\User',	52),
(15,	'App\\Models\\User',	52),
(16,	'App\\Models\\User',	52),
(17,	'App\\Models\\User',	52),
(18,	'App\\Models\\User',	52),
(19,	'App\\Models\\User',	52),
(20,	'App\\Models\\User',	52),
(21,	'App\\Models\\User',	52),
(22,	'App\\Models\\User',	52),
(23,	'App\\Models\\User',	52),
(24,	'App\\Models\\User',	52),
(25,	'App\\Models\\User',	52),
(26,	'App\\Models\\User',	52),
(27,	'App\\Models\\User',	52),
(28,	'App\\Models\\User',	52),
(29,	'App\\Models\\User',	52),
(30,	'App\\Models\\User',	52),
(31,	'App\\Models\\User',	52),
(32,	'App\\Models\\User',	52),
(33,	'App\\Models\\User',	52),
(34,	'App\\Models\\User',	52),
(35,	'App\\Models\\User',	52),
(36,	'App\\Models\\User',	52),
(37,	'App\\Models\\User',	52),
(27,	'App\\Models\\User',	53),
(28,	'App\\Models\\User',	53),
(29,	'App\\Models\\User',	53),
(30,	'App\\Models\\User',	53),
(31,	'App\\Models\\User',	53),
(33,	'App\\Models\\User',	53),
(34,	'App\\Models\\User',	53),
(35,	'App\\Models\\User',	53),
(36,	'App\\Models\\User',	53),
(27,	'App\\Models\\User',	54),
(28,	'App\\Models\\User',	54),
(29,	'App\\Models\\User',	54),
(30,	'App\\Models\\User',	54),
(31,	'App\\Models\\User',	54),
(33,	'App\\Models\\User',	54),
(34,	'App\\Models\\User',	54),
(35,	'App\\Models\\User',	54),
(36,	'App\\Models\\User',	54),
(1,	'App\\Models\\User',	55),
(12,	'App\\Models\\User',	55),
(13,	'App\\Models\\User',	55),
(14,	'App\\Models\\User',	55),
(15,	'App\\Models\\User',	55),
(16,	'App\\Models\\User',	55),
(27,	'App\\Models\\User',	55),
(28,	'App\\Models\\User',	55),
(29,	'App\\Models\\User',	55),
(30,	'App\\Models\\User',	55),
(31,	'App\\Models\\User',	55),
(33,	'App\\Models\\User',	55),
(34,	'App\\Models\\User',	55),
(35,	'App\\Models\\User',	55),
(36,	'App\\Models\\User',	55),
(26,	'App\\Models\\User',	56),
(36,	'App\\Models\\User',	56),
(27,	'App\\Models\\User',	57),
(28,	'App\\Models\\User',	57),
(29,	'App\\Models\\User',	57),
(30,	'App\\Models\\User',	57),
(31,	'App\\Models\\User',	57),
(33,	'App\\Models\\User',	57),
(34,	'App\\Models\\User',	57),
(35,	'App\\Models\\User',	57),
(36,	'App\\Models\\User',	57),
(41,	'App\\Models\\User',	57),
(12,	'App\\Models\\User',	58),
(13,	'App\\Models\\User',	58),
(14,	'App\\Models\\User',	58),
(15,	'App\\Models\\User',	58),
(16,	'App\\Models\\User',	58),
(26,	'App\\Models\\User',	58),
(27,	'App\\Models\\User',	58),
(28,	'App\\Models\\User',	58),
(29,	'App\\Models\\User',	58),
(30,	'App\\Models\\User',	58),
(31,	'App\\Models\\User',	58),
(32,	'App\\Models\\User',	58),
(33,	'App\\Models\\User',	58),
(34,	'App\\Models\\User',	58),
(35,	'App\\Models\\User',	58),
(36,	'App\\Models\\User',	58),
(40,	'App\\Models\\User',	58),
(41,	'App\\Models\\User',	58),
(26,	'App\\Models\\User',	64),
(32,	'App\\Models\\User',	64),
(33,	'App\\Models\\User',	64),
(34,	'App\\Models\\User',	64),
(35,	'App\\Models\\User',	64),
(36,	'App\\Models\\User',	64),
(41,	'App\\Models\\User',	64),
(12,	'App\\Models\\User',	70),
(13,	'App\\Models\\User',	70),
(14,	'App\\Models\\User',	70),
(15,	'App\\Models\\User',	70),
(16,	'App\\Models\\User',	70),
(26,	'App\\Models\\User',	70),
(27,	'App\\Models\\User',	70),
(28,	'App\\Models\\User',	70),
(29,	'App\\Models\\User',	70),
(30,	'App\\Models\\User',	70),
(31,	'App\\Models\\User',	70),
(32,	'App\\Models\\User',	70),
(33,	'App\\Models\\User',	70),
(34,	'App\\Models\\User',	70),
(35,	'App\\Models\\User',	70),
(36,	'App\\Models\\User',	70),
(40,	'App\\Models\\User',	70),
(41,	'App\\Models\\User',	70),
(26,	'App\\Models\\User',	71),
(32,	'App\\Models\\User',	71),
(33,	'App\\Models\\User',	71),
(34,	'App\\Models\\User',	71),
(35,	'App\\Models\\User',	71),
(36,	'App\\Models\\User',	71),
(41,	'App\\Models\\User',	71);

DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'App\\Models\\User',
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1,	'App\\Models\\User',	1),
(2,	'App\\Models\\User',	12),
(5,	'App\\Models\\User',	16),
(6,	'App\\Models\\User',	17),
(4,	'App\\Models\\User',	19),
(3,	'App\\Models\\User',	20),
(9,	'App\\Models\\User',	21),
(7,	'App\\Models\\User',	22),
(10,	'App\\Models\\User',	23),
(3,	'App\\Models\\User',	24),
(14,	'App\\Models\\User',	25),
(15,	'App\\Models\\User',	26),
(4,	'App\\Models\\User',	39),
(1,	'App\\Models\\User',	43),
(4,	'App\\Models\\User',	43),
(1,	'App\\Models\\User',	44),
(1,	'App\\Models\\User',	45),
(1,	'App\\Models\\User',	46),
(1,	'App\\Models\\User',	47),
(4,	'App\\Models\\User',	47),
(1,	'App\\Models\\User',	48),
(4,	'App\\Models\\User',	48),
(1,	'App\\Models\\User',	49),
(4,	'App\\Models\\User',	49),
(1,	'App\\Models\\User',	50),
(4,	'App\\Models\\User',	50);

DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `client_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `client_id` bigint unsigned NOT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE `oauth_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `payment_proofs`;
CREATE TABLE `payment_proofs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist_id` bigint unsigned DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proof` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `payment_proofs_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE `permission_role` (
  `role_id` int unsigned NOT NULL,
  `permission_id` int unsigned NOT NULL,
  KEY `role_id_fk_538787` (`role_id`),
  KEY `permission_id_fk_538787` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permission_role` (`role_id`, `permission_id`) VALUES
(1,	12),
(1,	13),
(1,	14),
(1,	15),
(1,	16),
(1,	27),
(1,	28),
(1,	29),
(1,	30),
(1,	31),
(1,	32),
(1,	33),
(1,	34),
(1,	35),
(1,	36),
(4,	1),
(4,	2),
(4,	3),
(4,	4),
(4,	5),
(4,	6),
(4,	7),
(4,	8),
(4,	9),
(4,	10),
(4,	11),
(4,	12),
(4,	13),
(4,	14),
(4,	15),
(4,	16),
(4,	17),
(4,	18),
(4,	19),
(4,	20),
(4,	22),
(4,	23),
(4,	24),
(4,	25),
(4,	27),
(4,	28),
(4,	29),
(4,	30),
(4,	32),
(4,	33),
(4,	34),
(4,	35),
(4,	36),
(4,	21),
(4,	26),
(4,	31),
(4,	37),
(5,	15),
(5,	22),
(5,	23),
(5,	13),
(5,	14),
(6,	1),
(6,	2),
(6,	3),
(6,	4),
(7,	1),
(7,	12),
(7,	13),
(7,	14),
(7,	15),
(7,	16),
(8,	27),
(8,	28),
(8,	29),
(8,	30),
(8,	31),
(10,	1),
(10,	12),
(10,	13),
(10,	14),
(10,	15),
(10,	16),
(11,	41),
(9,	36),
(2,	26),
(1,	40),
(1,	41),
(11,	32),
(11,	33),
(11,	34),
(11,	35),
(11,	36),
(4,	40),
(4,	41),
(4,	43),
(4,	44);

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'web',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'user_management_access',	'web',	NULL,	NULL,	NULL),
(2,	'permission_create',	'web',	NULL,	NULL,	NULL),
(3,	'permission_edit',	'web',	NULL,	NULL,	NULL),
(4,	'permission_show',	'web',	NULL,	NULL,	NULL),
(5,	'permission_delete',	'web',	NULL,	NULL,	NULL),
(6,	'permission_access',	'web',	NULL,	NULL,	NULL),
(7,	'role_create',	'web',	NULL,	NULL,	NULL),
(8,	'role_edit',	'web',	NULL,	NULL,	NULL),
(9,	'role_show',	'web',	NULL,	NULL,	NULL),
(10,	'role_delete',	'web',	NULL,	NULL,	NULL),
(11,	'role_access',	'web',	NULL,	NULL,	NULL),
(12,	'user_create',	'web',	NULL,	NULL,	NULL),
(13,	'user_edit',	'web',	NULL,	NULL,	NULL),
(14,	'user_show',	'web',	NULL,	NULL,	NULL),
(15,	'user_delete',	'web',	NULL,	NULL,	NULL),
(16,	'user_access',	'web',	NULL,	NULL,	NULL),
(17,	'discipline_create',	'web',	NULL,	NULL,	NULL),
(18,	'discipline_edit',	'web',	NULL,	NULL,	NULL),
(19,	'discipline_show',	'web',	NULL,	NULL,	NULL),
(20,	'discipline_delete',	'web',	NULL,	NULL,	NULL),
(21,	'discipline_access',	'web',	NULL,	NULL,	NULL),
(22,	'institution_create',	'web',	NULL,	NULL,	NULL),
(23,	'institution_edit',	'web',	NULL,	NULL,	NULL),
(24,	'institution_show',	'web',	NULL,	NULL,	NULL),
(25,	'institution_delete',	'web',	NULL,	NULL,	NULL),
(26,	'institution_access',	'web',	NULL,	NULL,	NULL),
(27,	'course_create',	'web',	NULL,	NULL,	NULL),
(28,	'course_edit',	'web',	NULL,	NULL,	NULL),
(29,	'course_show',	'web',	NULL,	NULL,	NULL),
(30,	'course_delete',	'web',	NULL,	NULL,	NULL),
(31,	'course_access',	'web',	NULL,	NULL,	NULL),
(32,	'enrollment_create',	'web',	NULL,	NULL,	NULL),
(33,	'enrollment_edit',	'web',	NULL,	NULL,	NULL),
(34,	'enrollment_show',	'web',	NULL,	NULL,	NULL),
(35,	'enrollment_delete',	'web',	NULL,	NULL,	NULL),
(36,	'enrollment_access',	'web',	NULL,	NULL,	NULL),
(37,	'full_menu',	'web',	'2024-01-01 16:00:39',	'2025-01-13 14:36:42',	NULL),
(38,	'list_USERS_1',	'web',	'2025-01-16 03:46:45',	'2025-01-16 03:47:14',	'2025-01-16 03:47:14'),
(39,	'super_user2',	'web',	'2025-01-16 03:47:30',	'2025-01-16 03:47:56',	'2025-01-16 03:47:56'),
(40,	'finance_manager',	'web',	'2025-01-29 03:56:29',	'2025-01-29 03:56:29',	NULL),
(41,	'application_manager',	'web',	'2025-01-29 03:56:45',	'2025-01-29 03:56:45',	NULL),
(43,	'institution_access_',	'web',	'2025-01-29 10:05:07',	'2025-01-29 10:05:07',	NULL),
(44,	'all_file_filter',	'web',	'2025-03-13 13:12:06',	'2025-03-13 13:12:06',	NULL);

DROP TABLE IF EXISTS `professional_references`;
CREATE TABLE `professional_references` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `reference_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_organization` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_phone_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_job_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `professional_references_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `professional_references` (`id`, `checklist`, `application_id`, `scholarship_id`, `reference_title`, `reference_full_name`, `reference_organization`, `reference_phone_no`, `reference_email`, `reference_job_title`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	1,	19,	5,	'Voluptate non eos iu',	'Zephania French',	'Yang and Brennan Co',	'+1 (183) 774-3196',	'vilicy@mailinator.com',	'Quia blanditiis dolo',	'2025-05-02 11:50:40',	'2025-05-02 11:50:40',	NULL),
(2,	1,	19,	5,	'Consequatur consequ',	'Cameran Cotton',	'Downs and Randolph Traders',	'+1 (971) 853-6039',	'xyweg@mailinator.com',	'Soluta vel qui id in',	'2025-05-02 11:50:40',	'2025-05-02 11:50:40',	NULL),
(3,	2,	19,	27,	'Est commodo occaecat',	'Sierra Bowen',	'Hess Hoover Co',	'+1 (433) 402-3852',	'wepas@mailinator.com',	'Laborum Possimus a',	'2025-05-03 14:34:43',	'2025-05-03 14:34:43',	NULL),
(4,	2,	19,	27,	'Aliquam Nam quos iur',	'Amena Yates',	'Matthews and Combs LLC',	'+1 (623) 268-7541',	'nukulumov@mailinator.com',	'Consectetur laborum',	'2025-05-03 14:34:43',	'2025-05-03 14:34:43',	NULL),
(5,	3,	19,	14,	'Quas est sed eligend',	'Kendall Robles',	'Hogan Moses Co',	'+1 (548) 132-1709',	'poruzi@mailinator.com',	'Irure est quam aut',	'2025-05-03 15:32:30',	'2025-05-03 15:32:30',	NULL),
(6,	3,	19,	14,	'Facilis dolore iure',	'Hakeem Griffin',	'Holland Mendoza Co',	'+1 (796) 598-3809',	'xozycibeb@mailinator.com',	'Est dolorum consequa',	'2025-05-03 15:32:30',	'2025-05-03 15:32:30',	NULL),
(7,	4,	29,	8,	'Qui exercitationem a',	'Karleigh Odonnell',	'Suarez and Hoover LLC',	'+1 (369) 643-4623',	'qisyhowaha@mailinator.com',	'Quidem praesentium a',	'2025-05-04 16:33:29',	'2025-05-04 16:33:29',	NULL),
(8,	4,	29,	8,	'Incididunt eum adipi',	'Rebekah Hutchinson',	'Weiss Sellers Trading',	'+1 (378) 647-2321',	'revi@mailinator.com',	'Quidem et esse qui a',	'2025-05-04 16:33:29',	'2025-05-04 16:33:29',	NULL),
(9,	5,	29,	16,	'Veritatis officiis a',	'Colby Delacruz',	'Velasquez Kerr Traders',	'+1 (577) 362-9202',	'tixezaq@mailinator.com',	'Sit et quisquam mole',	'2025-05-05 23:07:36',	'2025-05-05 23:07:36',	NULL),
(10,	5,	29,	16,	'Qui repellendus Del',	'Mason Burris',	'Wood Foreman Associates',	'+1 (592) 794-5992',	'voqu@mailinator.com',	'Culpa aut dolor quo',	'2025-05-05 23:07:36',	'2025-05-05 23:07:36',	NULL);

DROP TABLE IF EXISTS `qualification_attained`;
CREATE TABLE `qualification_attained` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `checklist` bigint DEFAULT NULL,
  `application_id` bigint DEFAULT NULL,
  `scholarship_id` bigint DEFAULT NULL,
  `training_institution` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_institution_start_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_institution_completion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `training_institution_attained` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `institution_id` (`institution_id`),
  CONSTRAINT `qualification_attained_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `qualification_attained` (`id`, `checklist`, `application_id`, `scholarship_id`, `training_institution`, `training_institution_start_date`, `training_institution_completion`, `training_institution_attained`, `created_at`, `updated_at`, `institution_id`) VALUES
(1,	1,	19,	5,	'Et anim fuga Et ver',	'23-Dec-2009',	'Omnis ea est dolore',	'Ea officiis et cupid',	'2025-05-02 11:50:40',	'2025-05-02 11:50:40',	NULL),
(2,	1,	19,	5,	'Similique nesciunt',	'06-Dec-2010',	'Autem nisi sint sint',	'Commodi deserunt mol',	'2025-05-02 11:50:40',	'2025-05-02 11:50:40',	NULL),
(3,	2,	19,	27,	'Laboris aliquam nesc',	'06-Mar-1985',	'Dolore magnam distin',	'Praesentium cumque e',	'2025-05-03 14:34:43',	'2025-05-03 14:34:43',	NULL),
(4,	2,	19,	27,	'Optio veniam recus',	'25-May-1993',	'In sit similique op',	'Ipsam cum sit et do',	'2025-05-03 14:34:43',	'2025-05-03 14:34:43',	NULL),
(5,	3,	19,	14,	'Et reprehenderit ani',	'14-Feb-1991',	'Ex dicta deserunt od',	'Dolore qui magnam au',	'2025-05-03 15:32:30',	'2025-05-03 15:32:30',	NULL),
(6,	3,	19,	14,	'Esse officia ut minu',	'03-May-2024',	'Atque inventore volu',	'Sed reiciendis sunt',	'2025-05-03 15:32:30',	'2025-05-03 15:32:30',	NULL),
(7,	4,	29,	8,	'Asperiores eligendi',	'12-Aug-1992',	'Ut est et eum quo d',	'Esse quibusdam quide',	'2025-05-04 16:33:29',	'2025-05-04 16:33:29',	NULL),
(8,	4,	29,	8,	'Aliquam id ut et cor',	'23-Oct-1987',	'Quis sunt itaque si',	'Fuga Omnis sapiente',	'2025-05-04 16:33:29',	'2025-05-04 16:33:29',	NULL),
(9,	5,	29,	16,	'Cupidatat pariatur',	'14-Nov-2013',	'In exercitation magn',	'Enim culpa nihil cu',	'2025-05-05 23:07:36',	'2025-05-05 23:07:36',	NULL),
(10,	5,	29,	16,	'Recusandae Non volu',	'02-Sep-1983',	'Totam ad eligendi qu',	'In natus minim neces',	'2025-05-05 23:07:36',	'2025-05-05 23:07:36',	NULL);

DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions3` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles2` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `role_user`;
CREATE TABLE `role_user` (
  `user_id` int unsigned NOT NULL,
  `role_id` int unsigned NOT NULL,
  KEY `user_id_fk_538796` (`user_id`),
  KEY `role_id_fk_538796` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1,	1),
(2,	2),
(35,	2),
(36,	2),
(39,	4),
(41,	4),
(42,	1),
(42,	4),
(43,	1),
(43,	4),
(44,	1),
(44,	4),
(45,	1),
(45,	4),
(46,	1),
(46,	4),
(47,	1),
(47,	4),
(48,	1),
(48,	4),
(49,	1),
(49,	4),
(50,	1),
(50,	4),
(51,	4),
(52,	4),
(53,	2),
(54,	2),
(54,	8),
(57,	2),
(57,	11),
(55,	2),
(55,	7),
(56,	2),
(56,	9),
(58,	1),
(58,	2),
(61,	3),
(62,	3),
(63,	3),
(65,	3),
(64,	2),
(64,	11),
(66,	3),
(67,	3),
(68,	3),
(69,	3),
(70,	1),
(70,	2),
(71,	2),
(71,	11),
(72,	3),
(19,	2),
(19,	4),
(20,	1),
(21,	3),
(22,	1),
(23,	1),
(24,	1),
(25,	3),
(26,	1),
(27,	3),
(28,	3),
(29,	3);

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'web',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Admin',	'web',	NULL,	NULL,	NULL),
(2,	'Institution',	'web',	NULL,	NULL,	NULL),
(3,	'Student',	'web',	NULL,	NULL,	NULL),
(4,	'Super Admin',	'web',	'2024-01-01 16:01:29',	'2024-01-01 16:01:29',	NULL),
(8,	'Course Manager',	'web',	'2025-01-29 03:52:11',	'2025-01-29 03:52:11',	NULL),
(9,	'Finance Manager',	'web',	'2025-01-29 03:52:55',	'2025-01-29 03:52:55',	NULL),
(10,	'User Manager',	'web',	'2025-01-29 05:31:02',	'2025-01-29 05:31:02',	NULL),
(11,	'Application Manager',	'web',	'2025-01-29 05:31:32',	'2025-01-29 05:31:32',	NULL);

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('0t9WdgR0uZOMliyKXGbMhBFIibPPV5oSK1B1ErDK',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSzdnZTlDRVNxY1gyNWxwMHBreFIybDVuVDgwU093STR3YTQ0dEk0SiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746510292),
('0YTizwb1EOkrW7lEpojaxdCBsLDlXUtFNnIZTop3',	NULL,	'104.23.190.175',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTUE5Y1AzS2ZnTEJlRjNoSWh5SHNaQ2xCbUZmbFlkU01sSFMySWdTNyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9kYWlseW1lbm5ld3Mub25saW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746506874),
('13QvzBzZipTKfdsknCbdEZ4KKogbA1hilfAcvuxP',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZEllOURtclJYU0NFTXBYdm5EWjBZNW1UZEZ6RUNiWVVQUVM2TFNnSiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9mZWVkPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746511650),
('1EfIOeh0qOFxjQjr3rXSATOp6WfTfmaCc1nLgfDF',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzV2eDdKZG5iclN0NUcyUlM0VTBlRHJYazVlcDhFSjRmblJtbmhlaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz92aWV3PS4uJTJGLi4lMkYuLiUyRi4uJTJGZXRjJTJGcGFzc3dkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509513),
('2dnnp0Kmdcqx5g6rMd3Ima1ePuxCVtN9UrEM2pNC',	NULL,	'162.158.158.231',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUkJsd3Z2UnZEa0JyR1FNczhIcmtuc2ZPeUhMZHB6cWNvdDBycGNoUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9kYWlseW1lbm5ld3Mub25saW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746505025),
('2FSFjd9Wb6EDqTvn8Th2CQEtnuTuPczphfS7gYiP',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZThaeVVtTlpCN29rZHVIbDlXdjZ2QWtoR1c5Y05KSDBBbmdBV2Y4YSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9maWxlPS4uJTJGLi4lMkYuLiUyRi4uJTJGZXRjJTJGcGFzc3dkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509587),
('2sWEkEVVUAnNtDzJEGXddjLUX6F24teNrAeex2FJ',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNW1RVW90eXozbWRFYWc4OFFrM21kRWRUbVB2ZHNuZDVQenpWTm5PTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocC9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746510293),
('42aRw5C5dHkAFKpt0eI8fvGzDSEZxi4SjklfbsOS',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ0luSXRqaXZiYWNxYnF5dlhQWnAyVTE4TjFJNG1QV2JveUZxOVNFQyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTIxOiJodHRwOi8vMTU3LjIzMC42LjIyMy9vYXV0aC9hdXRob3JpemU/Y2xpZW50X2lkPXB1YmxpYy1jbGllbnQmcmVkaXJlY3RfdXJpPWh0dHAlM0ElMkYlMkZtYWxpY2lvdXMuc2l0ZSZyZXNwb25zZV90eXBlPXRva2VuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746511871),
('46NuLKOJLPFWAmHhoBCitO2PWuq6nOlvNZgfuCBr',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOGgzMGk0R2xBQ0hLOERJaHYyaEFGVVhvVTVQQTlWRDRxR0d6MmQ1RSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9kZXN0PWh0dHAlM0ElMkYlMkZsb2NhbGhvc3QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746511650),
('4fUvdmn6dwLtYj45TxClfovB2RK2kCEp0Rbojupy',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWEpKaTVIZWhuUXRNQW9DVWZ0NkQzV1VodEluTm5IZ0w0cVhmeDJCaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9yZWRpcmVjdD1odHRwJTNBJTJGJTJGMTY5LjI1NC4xNjkuMjU0JTJGIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746512046),
('4vwKqYGRojhtzQsJD1JFd45DfXz9tNo0n1PyFTwi',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNzROWGkxVElmelg2NGRXQU1abzRlclBFWDRPWVFRMEFnUEJER3VtciI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNDoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4vcm9sZXMvMyI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM0OiJodHRwOi8vMTU3LjIzMC42LjIyMy9hZG1pbi9yb2xlcy8zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746512147),
('55VPukXxQKDyqXt2w1VdXViNoxnWkAfGke0cOZ6V',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZkRZWFFLWU5QWjFsYW54QkZqb1FpVDQzRTQyUmhZSjZtQXk2bWpQZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjM6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz90ZW1wbGF0ZT0uLiUyRi4uJTJGLi4lMkYuLiUyRmV0YyUyRnBhc3N3ZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746509617),
('643Tstto6WQWlW3WiO6pd43lZwWwQjgFVbzByVf3',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQzJUUGtITlhmZnBVV0pSS05IeU5lWDh0VEpyM011Q3pITUFYemd4RSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9saW5rPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746511651),
('6Tv9hAGOPtkm5ABuStI3ZFyk2IE5fTNLGYv6kFEx',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieXc4VGd3Mk9UMkw3cVBpZ2k2eHBmeUFIazhvWWI4TEtFQTZRUmlqNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTQ6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9uZXh0PWh0dHAlM0ElMkYlMkYxMjcuMC4wLjElM0E4MCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746511651),
('8bmGB4hIFqSVjIw1U6bc1PcBgoIvkpDBZuCd7eXf',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiV3lyTnd5NzJ5a1hWTVo4dmlCTmxrdGlyZEFScW4xMFRTUEFzUDN0QSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746509544),
('96nmWJtns0swMcoVcNmatCqHS0885ULDe54bynY2',	NULL,	'43.157.82.252',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieFhLVU9mWWUwRWFHMTl5SGh0cGpOZlhXbXZjY0VkMWd3aDJHbkNBVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746503890),
('9pIsTkUzBdIgRYA77vIMgmiptNU2dFaSqP7dthTN',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiam9qTFpFR3ZNRGdMRzhURnBrN2JyVjFQY3lmUEI1dDFBWkJsVFFiZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Njk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9maWxlPS4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRmV0YyUyRnBhc3N3ZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746509511),
('9YkgmEZLmHIQtH3cPMDbViMYzAoe0l27jl1Gsmq3',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVnRnVExIeUdxTHJOMXhCWVlzSHA4UEpnSXE2OUFQaHp4R0NUell2cCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746511776),
('A9Iu5NAYNWNnIY83TyaMCGowkWRFkFhxQoJuXtp4',	NULL,	'178.211.139.123',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36 Edg/90.0.818.46',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoidndvTWQwd1lFT3h2R204RDRjbzM5ZmRqT0hTZEhrZzN0T09HSUFTSSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746511604),
('at99EQP3GjumrxFx4DDqiIsEp1TZlCRmPSs8rRv6',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoibndVQlY3dHJXT1dFYXkyNlpyclp6cExCbzd0bldLVlBWQ01rc09INSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9zb3VyY2U9aHR0cCUzQSUyRiUyRiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512046),
('ayMlT2cB9mfDFOfj2dkvZEebMvsTKuMUqIKBCdfv',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUG1TR3dlZkY2YmxoVVlBTURSU0xsd2RkNnBjTTdIV2tqcE56dGNkMyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Njk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9maWxlPS4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRmV0YyUyRnBhc3N3ZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746509587),
('b2jEBRKfDMV6VuQNhMytiI7jqEH9p6IPqJDWjm95',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUNoQ01WTE45ZkhaREhGUGNtRnFoNU1iaTFMaldNVFdSNWxtQ1hLeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTE6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9kYXRhPWh0dHAlM0ElMkYlMkZpbnRlcm5hbCUyRiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512016),
('b6rFbimPBUYwb3WGXY42nstNkPCrGHJQN8ijwGhH',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiY3hlaDcwbFZScHFQMFBvVWRoMWRkRkxMaTBGQ1l4a2VuOVdQblhKdSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746510128),
('B8j0SnQKgzBhbOb0ANb6FjxS0G0JbJucItFcNdqv',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidlU4N0Q1MDhUZUZ5ZDhkOUFsZFA5RzVQRU5Ra2FvWkg4RnpqT3RJZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9pbWc9aHR0cCUzQSUyRiUyRiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746511650),
('BAMkIyQwRXmAFu7jqCyEIchlTUHtWfkF5WDT5FLY',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMkNMMmNzU1doOVlzZG9SVzNkZEtqejdwM1kyU3ZTc1Y0b1FlYzF5aCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocC9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746510129),
('BCM4CnU7rPlzV4UsAYp3C7svjXBljcnb8gnpOTrh',	NULL,	'195.191.219.131',	'Mozilla/5.0 (compatible; MJ12bot/v2.0.0; http://mj12bot.com/)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRXZuWTRjbEZnQUpHdWhmTEd5cDZhbHc5aml1TzFrdTVkRFpwUGNKWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746503308),
('BEFqKncImKng4ns07laBTeLB7E5LDgl1ym4i5e8c',	NULL,	'80.82.77.202',	'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.13) Gecko/20100916 Iceape/2.0.8',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoielRMNmJ2SmkwZW03Q2NTblhYUFlyY2tlR1pobVIyT25lQXdic2tlaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTY6Imh0dHA6Ly8xMjcuMC4xLjEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746509408),
('bf7QvaNk6dRHvGuMgJ5oBIs5f5kw3gZPfw5R4Mem',	29,	'197.232.156.209',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0',	'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiUm54azBya3Bsc1BiU1AwUm1Na3dCdWdDWEtjSEFMbld0c29WQTkzRCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL215LXNjaG9sYXJzaGlwcy1hcHBsaWNhdGlvbnMiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToyOTtzOjQ6ImF1dGgiO2E6MTp7czoyMToicGFzc3dvcmRfY29uZmlybWVkX2F0IjtpOjE3NDY1MDk2Mzc7fX0=',	1746510842),
('bT90EzGgu2Z4mwChVzICPO5fqgIHcV3swN85BdcI',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVXo3SzFXelByNGxaTWpCcTVqckdFMmREMUUzS2kyNnh5ejN3d3RDNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocC9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746511953),
('bTdM4z3JXaH15osN1KTqWC5bXbfQbcaRLSKfui4u',	NULL,	'49.51.252.146',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVUdOeWNxV1FEeGx5T2Nqc2hKdU5zR2pqVllRZElMdFlRbzlSZkJOMCI7czoxNDoiaW5zdGl0dXRpb25faWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozNzoiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2NvdXJzZXMvNCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746501276),
('c9ypT49x8dkZaidvrxXAxLKZKkAf99BdimmDM3jS',	19,	'197.232.156.209',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:137.0) Gecko/20100101 Firefox/137.0',	'YTo5OntzOjY6Il90b2tlbiI7czo0MDoiS3VOZ0NDaWd2WWM4ZGNSbUFqWWZWcnhTSXRNanRDd0FYeWJ6WUFmYyI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM5OiJodHRwOi8vMTU3LjIzMC42LjIyMy9hZG1pbi9pbnN0aXR1dGlvbnMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxOTtzOjEwOiJ1c2VyX3JvbGVzIjthOjI6e2k6MDtzOjExOiJJbnN0aXR1dGlvbiI7aToxO3M6MTE6IlN1cGVyIEFkbWluIjt9czoxNDoiaW5zdGl0dXRpb25faWQiO047czoxNjoiaW5zdGl0dXRpb25fbmFtZSI7TjtzOjQ6ImF1dGgiO2E6MTp7czoyMToicGFzc3dvcmRfY29uZmlybWVkX2F0IjtpOjE3NDY1MTEwNTQ7fX0=',	1746512245),
('CBcxtnqVBMnpuwaStkxRmJKi7pdUDsYpQAwFW79o',	NULL,	'139.155.139.22',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR0l5SEZ2UzFmWWRLaENRYTZYa0JaZW10NWNoNnpKVlJDek9mbTNENiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512331),
('ck9TRgAtgxFFFucN123Oi4wOWBmghfWuiME0NRz3',	NULL,	'49.51.204.74',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoibmJpYTFoRWVoR2UxaHZwY1hYQlJOSUdmUUphV3BXMG01ZkxrTEFKbSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746505559),
('CLSz56HYP7xfGDnXlGZR2hbtojT2h3dOKuM7KKjy',	NULL,	'43.135.138.128',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRjJzNFVza0R0QXdHMTNqQVN0ZGNLN05YUlVFWnAydkxEQlBBQW1kciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746504546),
('cZvLDjzc6RZMXFeH4xua6MND0AjIGeI6R4QZu4aQ',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoicE5ERkNCbTY2b0FPZGRncDJINjhmbmE3cHdhM3hmM1hCNjUyd2hoVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTIxOiJodHRwOi8vMTU3LjIzMC42LjIyMy9vYXV0aC9hdXRob3JpemU/Y2xpZW50X2lkPXB1YmxpYy1jbGllbnQmcmVkaXJlY3RfdXJpPWh0dHAlM0ElMkYlMkZtYWxpY2lvdXMuc2l0ZSZyZXNwb25zZV90eXBlPXRva2VuIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746512150),
('CZxkUYTyoP6nD32bqlVlxD6W566e5Yf0mI1nMErq',	NULL,	'51.222.253.17',	'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiTUR6RGZwam5pSnBPYWIxUG8yRHlZZU9WUFZ4ZjJHbDhzQ3dmZDJYSSI7czoxNDoiaW5zdGl0dXRpb25faWQiO2k6MTE7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS9jb3Vyc2VzLzE0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746511518),
('D5AqkNetr9NZkzIgNUX3OpE038TdopO0AuUHy2IV',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY1N4Nk54SlBLcFB0cXU1bEZBbnRtS0k4ckJIQ05ybDRVZkZRdU53TCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luP2ZvcndhcmRUb2tlbj0iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746511964),
('DHbZJfUCj0mQAlDs1wXEkuva0ABkNuc2oyjxMQOv',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoibHNhTzJqc3JGVWxWR2Q2NDRBN0xsUFdBd05ENG5SSzl5WGFGTXhSeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9wYXRoPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746511651),
('dKmAwJOcRptc0xTA6SsHnJxqyqlWmhR84zI3exDN',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQ0ZZQm42YnBINU9uckhFeUhtWHJXSTVkMVJMTGx2Y2ZkeHdaQ2Z2WCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjU6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9wYXRoPS4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRmJvb3QuaW5pIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509617),
('dqfS2Hdkqt33F03KSVWSACVL7G9VwPlI6LHlyRan',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieWIzVTNrOGh3cWd2V1hLQ0dQU1lPaWhyRUdHaENXc1JFVjJMT0ZvZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509620),
('dSdTYphRw10ALe5IZmZxt6oWaIInnuYp2M4JPTDj',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMENxRUp0aUhMcnJkNDVvdXVycG9oQ0ZWQVNRcGlNZ3lPcWNkUG9jOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746512112),
('dwaQMiIPAdnnvUn1e6r7E4HSMOeJBCNJD2JwXvgc',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoidk9CQk93S1h6UGtIZjQ5U000RGpKSWZUYUR5TFV4Y0RzWlZxYkpLSCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvaW5kZXgucGhwL2FkbWluIjt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocC9hZG1pbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746510129),
('EA0To2UDzNbSqiiL3h7hqQGnIkJkntHrwbswjT2O',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiWHNzQ2U5bExsZmFkWFNzY1ZpWTI2YXR5bVNPQTR1bHBucUl4ckE3YiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0NjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4/anNvbl9jYWxsYmFjaz1hbGVydCI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjQ2OiJodHRwOi8vMTU3LjIzMC42LjIyMy9hZG1pbj9qc29uX2NhbGxiYWNrPWFsZXJ0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746511775),
('ECTTGYRfSqhS1tOrc5krdZJvw3CyCcBfdvR3iyxF',	NULL,	'43.153.19.83',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoieFBpVTdjckdSMjlld1ZnR3RnN0lkbDZMZ2xyU2RZVWJ2ZHVIQVVENyI7czoxNDoiaW5zdGl0dXRpb25faWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozNzoiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2NvdXJzZXMvNiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746501889),
('eGK0JzIZhEHNoZH5iyoMNLHhlmuRyf2bV3pjY6Di',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRjNpVFlhdldaNkJ3Z29LVURlc21VYlV4c3dpaTdBSWtPT2pTYWxlWCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9maWxlPS4uJTJGLi4lMkYuLiUyRi4uJTJGZXRjJTJGcGFzc3dkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509511),
('EmKp28h1se0HRmp6IdbaFBess6w0pxSDTufidhn6',	NULL,	'178.211.139.123',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36 Edg/90.0.818.46',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoiZVFGM2lKQ1RBcXlsY2RRM3BUcUJaSEQwRHFZS1BkY1RYdmFBcmlHeCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746507659),
('ENCwGQVIlnEAE4ZWFy9ZzYGxDTsOGWr4nKoRbNHR',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoicFhnQ2NTMWJ3RkZjR1h6UmtqQnBiRWU3Uko2aEhxaU56VjlnaDRYayI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509771),
('eRm7yLWy8xFcNe0TrJxaCAe7zaSSSq7p4LLKTfdn',	NULL,	'43.157.82.252',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRDNwUEhOdjBtQ3JpdDRoc000UjZLMG55YUZKeTc0dHBVYWZFaHM2aCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0MToiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2FwcGx5LzAvMTY/cT0iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo0MToiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2FwcGx5LzAvMTY/cT0iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746503887),
('f4vdRGS05OjtOm2N2vF2lGDZReBLVfzxcgBHCHU9',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidjN0TGtiVFZLZzlsYTRuNHg5Rmsxc3kyeDNuQ1IwMXdqaWZFQXNHTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9jc3BfcmVwb3J0X3VyaT1odHRwJTNBJTJGJTJGZXZpbC5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746512111),
('F7CnkjJKHRHRaqwigeMZdvoKuzhF4VMwnNfy8mJD',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRGJ5ckhnUGNQbkN4aERZZWRoZjVwSjl0VGM2TmtJcWhHU1R0NHVIVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9pbmNsdWRlPS4uJTJGLi4lMkYuLiUyRi4uJTJGZXRjJTJGcGFzc3dkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509512),
('FfMmDuy1YFiLSi1WspenkA0dMfdA0dRESslJk7a5',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOVRMaXRLYWRXWFdYd3pOemZKaDJibDFvUXliWm42OUVFV0tHOGFaUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz92aWV3PS4uJTJGLi4lMkYuLiUyRi4uJTJGZXRjJTJGcGFzc3dkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509618),
('FGMEW2NzqOA0O8FNTXMgEsGI05nPm3QmObN5OOAe',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZlNYa3czTjdnQjhBWWl1OWhqUXVycnBpTEdiRTRqVmpPbk80UHlDeSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjE6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9tb2R1bGU9Li4lMkYuLiUyRi4uJTJGLi4lMkZldGMlMkZwYXNzd2QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746509512),
('fJkJjZqBaDOnjDf60GVNxe2eFxw1NzWo00IUTA8Y',	NULL,	'93.174.93.12',	'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.90 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiM3VaWm9DVDVmVVhSTkFKMXllbE1sYThpQVNvTGgyb1JGcHUxRXpJZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTY6Imh0dHA6Ly8xMjcuMC4xLjEiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746505370),
('fPOGJUBIk9AIGMVoBBTJHSEYECC3OKNFpjhvUizn',	NULL,	'116.111.30.235',	'curl/7.88.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS0hPZzd6THJuUFNXWTZRdTRBRmNKYmRQNHR5VmFmcmtPOHFzOEs4diI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746507159),
('g1ZoYpu5C0RwkzrzNrY6x6DA7jnqIVlchd8xkqZa',	NULL,	'49.51.204.74',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoid0NUOUd0dllZU1lEbFJGc1JHVjNybGxsNmY0bWFJa3hoTTg0TDRpTCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozODoiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2FwcGx5LzY/cT0iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozODoiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2FwcGx5LzY/cT0iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746505555),
('g75rASzEgWyjG92y0xQYsHTiYcZbtCDjTlug0NDY',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiR05kZUFuankyVFdLUVVaOEgwT3dFaWJoSVdoRFhVNnk4bUl6N3RRRiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9wYWdlPS4uJTJGLi4lMkYuLiUyRi4uJTJGZXRjJTJGcGFzc3dkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509512),
('gUotDZNL7OgGL57XIbmzFZCJonhKtZVuYjuJKHwM',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVlJiZjBPVVNHYm9DSnZ3aEFmREN6bmZyOUJ3b2p5eWRYcEdMZTI0dSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9mZWVkPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746512045),
('h45A2NiKjrNDpSii2zcurGV0kmoWp2xZl8hMV0cM',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzExdnZldW90S0cxZHZWMWFrelJ0eGJFRW9LSWhTS0FIT0JhNmQ3RyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocD9vcHRpb249Y29tX3VzZXJzJnZpZXc9bG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746510261),
('ha6TpE7ro6W8286nzPaAGRQQr7dP3h2EMqztbTKZ',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNVN0TjFwTVJtMjZJR2lBcGxwa0Qxc0JuejIxRDVYSEpNN0M2bVZoTyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9vcGVuPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746512046),
('HM5Fn98phjSQROveri0FynnQNbdnxsotXVZ1bEOw',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWjNjQ28ySEhQdjRrbW9yYkVjWEl5b3VTRmpNNDBHTnZRcThaak1BVSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocC9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746511617),
('hOGr6Wc9eBKDkrRpoYip87cB9sFuy8vF8ahosZNR',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUFk0czdKc1E2WmhZdEQyZlp4OFJCbU5zVk9WQVVsc09OV3VNRng5NSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9saW5rPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746512045),
('hQ5NXijRBXP5a07yM4rwNGbrlKPAIOHtKbXX11Qi',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMndIRjJNMUYyNUdoY2d3QlROWlJtMnhuUG1IY3ROVllTcVRieGliViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746510292),
('HZiEgQCrMDXavYKdNqwiwUo2cdHuK4VremRp72Zx',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS1B4R1lodmp2c3A3NUZYTVVGWkJxNDdBRnZZWXlMcFhhcmhKZmpKVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjI6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9pbmNsdWRlPS4uJTJGLi4lMkYuLiUyRi4uJTJGZXRjJTJGcGFzc3dkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509588),
('i9PoxY9FnWePjGEhdph3xHP0DFa2qR0AU6bX2d9e',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYVczWEZySE5naU1QaEdZaFE0T0NudEpFS21FejFZYjJBdDZkeFM4NiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509489),
('isrUvHxDTMykLqEvwdDr48UZWftWpJz6GBVuWugX',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiU01JWWJSRTE1NTNiNW5nU0JvQVNCVlVtajU2OVBMeXNBQWJtR3JkNyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9jYWxsYmFjaz1odHRwJTNBJTJGJTJGIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746512016),
('IWoO26hU9ChH0nRFMPTGodiy8LzbtSut5qnfXuyM',	NULL,	'51.222.253.1',	'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaDZRU3JJQUpxaEhrSU83NUVjWXBpSkE1UWk1TmFhd2d5dTNuS3VWdyI7czoxNDoiaW5zdGl0dXRpb25faWQiO2k6NDtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozNzoiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2NvdXJzZXMvNSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746503232),
('jgLOAVHOgp2YBcQXFlT7ir5MMKywXd34REH61JsE',	NULL,	'43.156.204.134',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoieVR4T2F3YTJ5Y01LeHBYeG52bERsQmxRRUpGTWNmNldEcnNpamZhZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS8/cT0iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746504829),
('jgYFtD18b0DrzeEtZisB7UAWQCIACRNP0lO24TCh',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZmlYYnlMTU1mNEFoYTdZeDdEdU8zWm41ZFA5eGppcVJVWXFCS2ZTQiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNDoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4vcm9sZXMvMyI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM0OiJodHRwOi8vMTU3LjIzMC42LjIyMy9hZG1pbi9yb2xlcy8zIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746511809),
('kn1yUXvYzCi4RwrrWKSlLweHGV4JjqajGEzdJmwG',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiV3VmaE0yaVVFeUF2U3lWUU1EUkR5Nk12MmlrejVhOXhsWEd1aENzciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDU6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luP2FjY2Vzc190b2tlbj1hLmIuYyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746511964),
('KXUpAGZzdSLSc3TicdLpsP76f7XdqLfeH0udVNkt',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTks3UWw2NnJnZWdVSjhvSGVwM1VYdHVJM3dONUx4U2hjb2NlaHVQUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDM6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9mb3J3YXJkPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746511650),
('l2DhRf9zVYKPw6bY471PpuUBCOudPJQxgn2aUapv',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQk9pZWl4UGdackU2TUdYVVRDdVR6dmo0SVlLeUJUR081V2Jpd05WVCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6OTE6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz90cGw9JTdCJTdCY29uc3RydWN0b3IuY29uc3RydWN0b3IlMjglMjdhbGVydCUyODElMjklMjclMjklMjglMjklN0QlN0QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746511775),
('LD83uMamhoEOx2OE4IpC0RDsG1zD3qVdGnQj5wMo',	NULL,	'43.173.1.69',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRU9FYVVQanZvQ2lKR0FhOXprb05GYkVvSURYNlNGeHZ1MDFKcWY2USI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozODoiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2FwcGx5Lzk/cT0iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozODoiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2FwcGx5Lzk/cT0iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746502914),
('lKbB1tREbuFWG8VqJQj0uAPGhzABUnRhANfUoFOL',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoicjhxNlFLUVdRNXZsb1NPamdGWUg5bTRFZEduTWF0cGVPdWEwdFVJdyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746509619),
('lKBhvzc1NJyJsIiXWmFWhZrvq9pztBMyVXWaWidv',	NULL,	'185.218.84.178',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36 Edg/90.0.818.46',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoiRUlBVkpVRDQ3WVo0U0RqSnBhdXg4S2hHWmt4WlhYREFSalVkRW51RiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746501708),
('LkxnFwiRsWEmwPnukhEFjdOaql4bYYCZSqxWFqTZ',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoia0MwWHFOek85ck54cVVhd1B6NnAwcUFBcWVxTTVidHF4OUJWT3pVWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocD9vcHRpb249Y29tX3VzZXJzJnZpZXc9bG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746510096),
('LnBxguVHSt59SytJFhnOe8marE1XIjSgwAat4vhv',	NULL,	'185.218.84.178',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36 Edg/90.0.818.46',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoib2dDejBIYlM1UVphRmxnTzJqNkUxUm1QS0JLdHRRYXU3T1NYdGQwZyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746512373),
('mkZYy1CX6usDMnR1gJtmLrLt83kmPLTGdqGr5wtw',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMEVCcnZLQTBvellPRHJ6TDJZc21SNEdyMVlQMVlKSnRTUm1pcmF6YSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz91cmw9aHR0cCUzQSUyRiUyRjEyNy4wLjAuMSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512046),
('MNj3uKqCIwukmmYr0RPJGlRIxyYrtDsv5cRkAV3d',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRUk1WWRqTFUwemNnZUpvcjFjSDN4Mk94cFd0clNkY3h4aXRZWUtHMCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6OTE6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz90cGw9JTdCJTdCY29uc3RydWN0b3IuY29uc3RydWN0b3IlMjglMjdhbGVydCUyODElMjklMjclMjklMjglMjklN0QlN0QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746512112),
('NIvou1pPln7AT82FAblgtkJiiuuV66UHIkfUDrHh',	NULL,	'51.222.253.20',	'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaE94Y2V6dVY3ZWJ0WnNhSEVQdm1ucmlUY0J4azBSNjNzdzRQSzhnaCI7czoxNDoiaW5zdGl0dXRpb25faWQiO2k6MTE7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS9jb3Vyc2VzLzEyIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746506050),
('nw9S18rHqcmOEKs8pXKj7bFjzgxSDmyhdiys7K0T',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoicnRlaWFpenowQXJEQkMxOTVmVTVxRDlLQklJbmdQZ05Da0tYVWllWiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509789),
('OEBvwkZXBqQaySusIOSZwnMQYoqxIffnbgDEiDLg',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoid3FocmhiVVE3VGNLNmg2QmRlelZPWGs1OTBENDZ0bEFIZ0o3YVlYOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9wYWdlPS4uJTJGLi4lMkYuLiUyRi4uJTJGZXRjJTJGcGFzc3dkIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509617),
('oH6oo02kOAle8XdmGqgWMdC2TzBTTCktpimZ7Cgo',	NULL,	'43.173.1.69',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRVdaekU5dmU2RzdWR3RjUlZNVmhFSVM4UDRMTXRBZDF4U0pmdFRkYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746502916),
('ohZlKgcgbedB77KWGjnyNxCjHURaCqt9eO3e1W7V',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUnQ2anJaUXNRN085RFlPRlJIOGc0S1pXR2pLcXdmcmlUWW53UzNKbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9jc3BfcmVwb3J0X3VyaT1odHRwJTNBJTJGJTJGZXZpbC5jb20iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746511775),
('OolpK1oldqaP1oI8NLvz2bwjO0vvsmCLKGYPrzys',	NULL,	'43.135.138.128',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRUVPaktVa1dBUXZmNUR6dm5pdkVsdzhvRFhVTEwwakJmSHhsOUxESiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozOToiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2FwcGx5LzMwP3E9Ijt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS9hcHBseS8zMD9xPSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746504542),
('oOQERiVqU3PreyjEpWqhtejtsihtbxUM0VLAluSo',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTHdwN3NSTXl1MVExRHh2ODZsbkdRbUJrS2VEVWJ3d0FmdW1zcVZLcCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz91cmk9aHR0cCUzQSUyRiUyRmxvY2FsaG9zdCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512046),
('pEAbcsae8gK1MPZzIRylMboFpENNdvoMYFzgjo5y',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVEJvUnFLWHRkRWZVZTMzNGxCQXF3aW5ZNGVDZDNmclpkcG5IZlBDNSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozNjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvaW5kZXgucGhwL2FkbWluIjt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocC9hZG1pbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746510293),
('PfmOFYybkQBSfQ2RcIfpMOTB80Nmykr7e1YbtTBL',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZ1Bhakk4a1FhUk5ndFZ1Tm13c2FxTXBxUzU1TnJjUE95YlpUMktkTiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjU6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9wYXRoPS4uJTJGLi4lMkYuLiUyRi4uJTJGLi4lMkYuLiUyRmJvb3QuaW5pIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509512),
('qDbVjDe8jUt28SFIRn2TFLm3AdZ6xK3swGcwZQGp',	NULL,	'172.70.110.183',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoib215MFdlWUNYeGhwblE4b2RGbE13b0dDeWRKTHVWZjE2RnA1cE8wQiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly9kYWlseW1lbm5ld3Mub25saW5lIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746510780),
('QIZjpy4CCq41870j9et852yZ2N2yXZ91vPu82PWg',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQTg5UlgxNTJhNktRNWc5OVhkMGI0cTgyUmhKNWhlbUxySllDUnJmeSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz91cmk9aHR0cCUzQSUyRiUyRmxvY2FsaG9zdCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746511681),
('R0xKMjIDNVrP7cxTI72Ki43bzwvadp5VsUanWe3R',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRXp3RWxlbzk3WUhUYkRRSnRyamVOdld5RFg2UGVQTnl4dXA2dnlmeSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDQ6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9jYWxsYmFjaz1odHRwJTNBJTJGJTJGIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746511649),
('R6We9ZymIYuzFjLPBEdBHQaP0y4cr8GdRYtjOl3V',	NULL,	'104.23.188.2',	'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiY0ZqbU44RFp1RDFCTElzcjJBOVhsUWRDTkpqNVNaRG1WQzNmeU5TSCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHA6Ly9kYWlseW1lbm5ld3Mub25saW5lL2NvdXJzZXM/aW5zdGl0dXRpb249MSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512082),
('ReNEf6kmzVq0cJ2BVfX6ijD7DNLHyuvEPtEBLbvq',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSnRLcDNIMjhQRkhUUk5WOXdpWmFNUzZmdDR5M2lqMVpQV2ZXVWJCRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746510128),
('rFEJbc0cNNBSvNsz7jOwHsdW8tHnSvgyVhZ7FT8I',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMmQxeGlydkVUU2JWZ0czdllDd1FGQXJiSTJqckpoSnY2WVAwOWFpNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746512147),
('RJlzXChxZJwCEsML7UNU7RzxXVapVhGj3QMi6JXD',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTHhCcHBNYkc2WlNnODc1RG03Y3haZkx4cGpuamJZcjdiVHBBeGw2OSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9hcGk9aHR0cCUzQSUyRiUyRiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512016),
('rKPm3rsIoBhV4KYjAYtrrSYIrlH9axWnlaznS9Ie',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiakRFZG9YbnM2NWpROGpSRTRiV0lxMnRqdEVLQmFKRVU1MUszQnRxVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjE6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9tb2R1bGU9Li4lMkYuLiUyRi4uJTJGLi4lMkZldGMlMkZwYXNzd2QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746509617),
('rub3wCSywGEA8Ax5kZgB8RYLO7Pyb5lIDhtZ0B6C',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVVJRSm1LWHhqendLM2RJYnhqbDNuSGtvc0pHTlA4elFWemkzN21abiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9pbmM9Li4lMkYuLiUyRi4uJTJGLi4lMkZldGMlMkZwYXNzd2QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746509512),
('sznnsMcG9Fj9V7hfm1IOwTKOLbr98sRK1KZXzhvh',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQkVnanNlVTNmdjNqd0h4ZDRkR2tWSkFmd21SRlhJQmFybTFqTjNpciI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9wYXRoPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746512046),
('THWCjlOD1ZEEqd0821EDRDvuoGW6s8iRbIKyqYV7',	NULL,	'51.222.253.18',	'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoidExwcVhGVElnWjdjWGJGMWxMZXhJekRYbFZoMDVEUUNjUU5OTmhkZCI7czoxNDoiaW5zdGl0dXRpb25faWQiO2k6MTE7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzg6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS9jb3Vyc2VzLzEzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509036),
('TUjdH3pnxxhsAt60EDOEZJxbqNF6LpavPLSiiPp5',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVk50Wm4weWRTRXA2WmFXUXBURk9IRzBUR0FBQjhSYVRlZTRUM1JNOCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9pbWc9aHR0cCUzQSUyRiUyRiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512045),
('tVeRCFVhghgBtnPAOrrMNbQFedZFApvM6tGldhfY',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMHZENHVBQkQ2M2J2U3Z4SmQyUkptT1FnMXlRdllaVWFNTHAxQVk0WCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746511809),
('UUsMwZqvynI3dQHEIvkrczRORf2Ipop1nR0datXb',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiS1RxcWpjUnpKeUgyeVU5Y3BXSFhld1pjWXI2Q0MxNE1nZmxSZFl0YSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocD9vcHRpb249Y29tX2NvbnRlbnQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746510261),
('UYnBUfhDnSy7LYQ8aeRVmH69PYpLbnBrVRsHFHjp',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMDAyd3NOaXlWTDhZMXAyRk1IUkFycGZRcGpFOVIxNTVuSTR4ZGlRdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509474),
('v3GlFQ3RPD42jhw7YWcwsUwqRW4ywAoZO62nDmEK',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWGlUemlQWmtVTkVLVEhWMEtHeVhzRXlQb2IzYVNQYk9JWXV0cTMybyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9pbmM9Li4lMkYuLiUyRi4uJTJGLi4lMkZldGMlMkZwYXNzd2QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746509587),
('VKE1xZvDetbPdB8wHH9zw3rkwpjiZdOroyX53lvf',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoicmhGTzV4aVVYMkJHbFZrYmZJMlhLbWF1M1dXbmdFWDUxc2tHQkRDdCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjE6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9sYXlvdXQ9Li4lMkYuLiUyRi4uJTJGLi4lMkZldGMlMkZwYXNzd2QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746509512),
('W9tLyDlw5YmU36us8RvtxpjQdEk1UyMDj6pOWcyd',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiZXNZWk9xdmZvM2NUUXlFM0x6bGYwRk9uSXN6RTU2RTNvMlgzT3NXNyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDI6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9zb3VyY2U9aHR0cCUzQSUyRiUyRiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746511681),
('wGK3JruRsTjubEnjAZdYbRghUWmomPoRcWsatuvv',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTlVnNXhGeTZmUzNQQ09UVTVlTlVZWUZwYzJpbWptc3dYRU1KNEZBYiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTQ6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9uZXh0PWh0dHAlM0ElMkYlMkYxMjcuMC4wLjElM0E4MCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512046),
('wZP4XOyCZQ5WkQOUaXXT2yFv4VIA9gNs7mPG619X',	NULL,	'43.130.3.122',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQkEyVmtLb2ZORWVmMDdDT3ZmeFp0NUZBTHNBcEd1OU95WHd0WlpWZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly9nZXR0aW5ncmVhbGFnYWluLmNvbS9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746503557),
('XARdUoFwh60DfIAnf49FnUeWbB7TsfyYGuWSuvKs',	NULL,	'178.211.139.123',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36 Edg/90.0.818.46',	'YToyOntzOjY6Il90b2tlbiI7czo0MDoiVHdCcWJXb0t6bWNVUm9ObEtnbUk1aUQ5bzBud2VsSUlPNE0ya3hNQiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746504059),
('yCNsjMGIbVEtrybFRvgyswuJ68egz2U9pOZhppoV',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiczR6R0ptS29lalMyRzlrelV2b3hVSkNMa0VoV2t1SDRLVnJUY0NCZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDM6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9mb3J3YXJkPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746512045),
('YgbacJczJD9KU7WapH4pgFVo0DexqTyjz4Fbxp0O',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVUJZRUNZeFZONDFGZ2wyang4c050aFptRlplN2RzZVIxcmZScUJMYyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czo0NjoiaHR0cDovLzE1Ny4yMzAuNi4yMjMvYWRtaW4/anNvbl9jYWxsYmFjaz1hbGVydCI7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjQ2OiJodHRwOi8vMTU3LjIzMC42LjIyMy9hZG1pbj9qc29uX2NhbGxiYWNrPWFsZXJ0Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746512112),
('yPQbIZWC9FVuVPSlWOyRa7RrlIY5y2Vfv4Nut10c',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoicklvRFl6ZG1YTm0xSlNTWGRvRFJhODRrRzZNc2lBVkN1NlFlS1NQbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',	1746509544),
('YwoEJZ8OiLrtqYA8POAou4HtAgRgDpCKUsqaLTlS',	NULL,	'43.130.3.122',	'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',	'YTo0OntzOjY6Il90b2tlbiI7czo0MDoidEs3NkRJUGdMamJieUxJYkJNOFpPelJvUTc1ZHA2TXBObE4zWFdGOCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozODoiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2FwcGx5Lzk/cT0iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czozODoiaHR0cDovL2dldHRpbmdyZWFsYWdhaW4uY29tL2FwcGx5Lzk/cT0iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746503555),
('YzfYQeYHt8lV7ELGRXZdJpesWElHXHVDVQPsebDR',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNEhRSXB5amNUTDRNMGtvTmJzR2NOSzBrY1NJRXhVZ2Z2YXc1T2NWUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjM6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz90ZW1wbGF0ZT0uLiUyRi4uJTJGLi4lMkYuLiUyRmV0YyUyRnBhc3N3ZCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746509513),
('ZcWVOO46C5DEBsuZnEFbyL2DO6FHUjBpP91eHX8O',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaDJLZUJvMTRIYlZkVUtoM3BxeWRhVFB0NzJzM3dGNW4zS0xhWTFYWSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDU6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luP2FjY2Vzc190b2tlbj1hLmIuYyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746512217),
('ZJze6zE3q93yYGMgifvMSKzryLwWZhx52iBEdqAv',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMFdsQ3ZCbHNVNVVSdlExRG96dDhCNFdRaXFUQ2FreGNqTUFRUTViUyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTE6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9kYXRhPWh0dHAlM0ElMkYlMkZpbnRlcm5hbCUyRiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746511650),
('zuoPIhdWu6J3YJfKXLKn8RYirXlEmOehYpkBd298',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoibUJNODRxTXd4ZXhpY0p4dlhnNG5KUThhV3lvem9QemRhVFgwbGVOZSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz91cmw9aHR0cCUzQSUyRiUyRjEyNy4wLjAuMSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',	1746511681),
('zvwH13mgxanvkpMslHTb1ygW7wHeCzWYVu5ytQeA',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWkVhdUVDU0Yxd1JtSk8zV3pqSUZORUdzbVFrNEVOb1lBS2VSVkNzTCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDk6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2luZGV4LnBocD9vcHRpb249Y29tX2NvbnRlbnQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746510096),
('zyA3cGm88Hn6wz4reBd3xQJvkYCNhFiSv85XrvtX',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRkFIdGF5ZGI1N3N0SklXOGo4RFNJNW14RkliZXZPVFFQWFNxeW5PcyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzL2xvZ2luP2ZvcndhcmRUb2tlbj0iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746512218),
('zyjIsN7849G7GN88TC3jxqlkEMqmlWWeuVrQjFUN',	NULL,	'154.83.103.179',	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiOWJTSnJ2Yjg1OW0zOVM0cmlyNnNzemxDNDJuZ1hWenViV0VIaFNPcCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly8xNTcuMjMwLjYuMjIzLz9vcGVuPWh0dHAlM0ElMkYlMkYiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1746511651);

DROP TABLE IF EXISTS `tenants`;
CREATE TABLE `tenants` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `database` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenants_domain_unique` (`domain`),
  UNIQUE KEY `tenants_database_unique` (`database`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `uploads_managers`;
CREATE TABLE `uploads_managers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `required` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `file_size` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '2048',
  `created_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `uploads_managers` (`id`, `file_name`, `slug`, `required`, `file_size`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1,	'Personal statement/reflective thinking summary about your passion for the course and desired impact post-training.',	'application_letter',	'Yes',	'2048',	'2025-02-27 16:31:54',	'2025-02-27 16:31:54',	NULL),
(2,	'Updated curriculum vitae',	'cv',	'Yes',	'2048',	'2025-02-27 16:33:15',	'2025-02-27 16:33:15',	NULL),
(3,	'Copies of relevant academic certificates, licenses, and transcripts(Scan and combine)',	'certificates',	'Yes',	'2048',	'2025-02-27 16:33:30',	'2025-02-27 16:33:30',	NULL),
(4,	'Copy of national identity card/passport',	'national_id',	'Yes',	'2048',	'2025-02-27 16:34:14',	'2025-02-27 16:34:14',	NULL),
(14,	'Proof of Application Fee Payment',	'proof_of_payment',	'false',	'2048',	'2025-03-19 15:42:07',	'2025-03-19 15:42:07',	NULL),
(15,	'Signed Pre-Auth Form',	'signed_pre_auth_form',	'false',	'2048',	'2025-03-19 15:42:17',	'2025-03-19 15:42:17',	NULL),
(16,	'Blank or Raw Bonding Form',	'blank_or_raw_bonding_form',	'false',	'2048',	'2025-03-19 15:42:17',	'2025-03-19 15:42:17',	NULL),
(17,	'Fully filled Bonding & Release Form',	'fully_filled_bonding_and_form',	'false',	'2048',	'2025-05-05 10:18:38',	'2025-05-05 10:18:38',	NULL);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_number` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `institution_id` int unsigned DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `county` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_expires_at` datetime DEFAULT NULL,
  `is_verified` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'true',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `institution_fk_538818` (`institution_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`institution_id`) REFERENCES `institutions` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `first_name`, `middle_name`, `last_name`, `id_number`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`, `institution_id`, `phone`, `gender`, `dob`, `county`, `country`, `otp`, `otp_expires_at`, `is_verified`) VALUES
(1,	'Admin',	NULL,	NULL,	NULL,	'admin@admin.com',	NULL,	'$2y$12$YL8uFDWFMiuDMl8cR/8dG.gCWEU.iJjruCKPFmuFf9ltZ5dNS76G2',	NULL,	NULL,	'2025-05-06 05:03:52',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(19,	'Super',	'A',	'Admin',	'11223344',	'super@admin.com',	NULL,	'$2y$12$3Cc3gfLv.MHl7xHtnugdjuIDw5to2gBj2aEH0cBQN06UTXG.jjfO6',	NULL,	'2024-01-01 16:03:01',	'2025-03-25 14:22:02',	NULL,	NULL,	'0715882227',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(20,	'Ivor',	'Gavin Hess',	'Olsen',	'89837362',	'gapp@gertrudes.com',	NULL,	'$2y$12$3Cc3gfLv.MHl7xHtnugdjuIDw5to2gBj2aEH0cBQN06UTXG.jjfO6',	NULL,	'2025-03-25 14:28:39',	'2025-03-25 14:28:39',	NULL,	8,	'07157625263',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(22,	'Gabriel',	'Janna Allison',	'Joseph',	'878',	'admin@knh.or.ke',	NULL,	'$2y$12$ecUW70RSmX6hdvS4VkaMi.K/8fH7NW8jV881gjWVUBBilGzQiq.Y2',	NULL,	'2025-03-26 04:37:41',	'2025-03-26 04:37:41',	NULL,	1,	'42',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(23,	'Lucy',	'Dana Macdonald',	'Bullock',	'980',	'admin@uon.ac.ke',	NULL,	'$2y$12$SdkZen/2Mvus3f9Spj5NUOvazb/sG5u20L7aNGLZ3vcCax5sbYWBa',	NULL,	'2025-03-26 04:38:31',	'2025-03-26 04:38:31',	NULL,	5,	'61',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(24,	'Hayfa',	'Vera Cote',	'Padilla',	'957',	'admin@aghkhan.ac.ke',	NULL,	'$2y$12$5hKGG/Yw2n2sE2TfuK440uAiQ91/ga44Ov4XkKfctnUtBzEeCAdcO',	NULL,	'2025-03-26 04:39:20',	'2025-03-26 04:39:20',	NULL,	4,	'30',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(25,	'Audra',	'Rama Dawson',	'Mcintosh',	'246',	'student1@gmail.com',	NULL,	'$2y$12$J/JZ1pdgrkUb6rJYCUdWnO4NIumr0utRXu6PAO2ciYHiBJ.Q1vdgS',	NULL,	'2025-03-26 05:13:28',	'2025-03-26 05:13:28',	NULL,	NULL,	'+1 (151) 349-1055',	'Female',	'2004-01-22',	NULL,	NULL,	NULL,	NULL,	'true'),
(26,	'Moi University',	'-',	'Admin',	'111222333',	'admin@moi.ac.ke',	NULL,	'$2y$12$yxaNSzzxJysxHZobPqL60.AnN/E0JTCu0QPavdIkBkLBDuZe5Jtiy',	NULL,	'2025-04-02 07:28:31',	'2025-04-02 07:28:31',	NULL,	9,	'0700000000',	NULL,	NULL,	NULL,	NULL,	NULL,	NULL,	'true'),
(27,	'Linus',	'Octavius Peck',	'Preston',	'892',	'zezabupuk@mailinator.com',	NULL,	'$2y$12$T1M6l4vGw5P9Tn3We.kVw.gFB5eKWe6DA14g1H9F9D9iKrT6Tir2K',	NULL,	'2025-04-28 08:19:34',	'2025-04-28 08:19:34',	NULL,	NULL,	'+1 (945) 444-7831',	'Female',	'2016-01-21',	NULL,	NULL,	NULL,	NULL,	'true'),
(28,	'Galena',	'Murphy Mccarty',	'Giles',	'880',	'hecifyne@mailinator.com',	NULL,	'$2y$12$Rw.s4Z9ils0kFaGZECPU9eK5i3jmEpxb/Z3AoAdMmQQlwwr3KEvUu',	NULL,	'2025-04-29 07:27:46',	'2025-04-29 07:27:46',	NULL,	NULL,	'+254715882217',	'Female',	'1995-01-18',	NULL,	NULL,	NULL,	NULL,	'true'),
(29,	'Wade',	'Logan Sellers',	'Tran',	'881',	'alpho07@gmail.com',	NULL,	'$2y$12$Rd2ozHikcPi86Bdou83rfe3DBiwFOby4ovbvarrpEvRhOssvzBXRm',	'CCq0MaAP7VPpPVu8L7jBcAL4C5k1ONcyFsKXvnWQwAipukxxvtVkDV3WMSUb',	'2025-05-04 16:31:43',	'2025-05-05 11:37:38',	NULL,	NULL,	'+1 (356) 757-8821',	'Female',	'2006-01-11',	NULL,	NULL,	NULL,	NULL,	'true');

DROP VIEW IF EXISTS `vw_master_course_app`;
CREATE TABLE `vw_master_course_app` (`id` int, `payment_verified` varchar(20), `sponsorship_type` varchar(20), `county` varchar(50), `course` varchar(255), `category` varchar(255), `period` varchar(267), `status` varchar(20), `phone` varchar(20), `gender` varchar(10), `dob` date, `application_id` int unsigned, `name` varchar(152), `created_at` timestamp, `age` bigint, `national_id` varchar(100), `nck_lic` varchar(100), `nck_cert` varchar(100), `kcse_cse` varchar(100), `passport` varchar(100), `sponsorship_id` varchar(100), `application_letter` varchar(100), `dip_deg` varchar(100), `comments` longtext, `institution_id` int unsigned);


DROP TABLE IF EXISTS `master_course_app`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `master_course_app` AS select `ca`.`id` AS `id`,`ca`.`payment_verified` AS `payment_verified`,`cm`.`name` AS `course`,`cc`.`name` AS `category`,concat(`cmos`.`name`,'-',`ca`.`year`) AS `period`,`ca`.`status` AS `status`,`u`.`phone` AS `phone`,`u`.`gender` AS `gender`,`u`.`dob` AS `dob`,`u`.`id` AS `application_id`,concat_ws(' ',`u`.`first_name`,`u`.`middle_name`,`u`.`last_name`) AS `name`,`ca`.`created_at` AS `created_at`,floor(((to_days(curdate()) - to_days(`u`.`dob`)) / 365.25)) AS `age`,`up`.`national_id` AS `national_id`,`up`.`nck_lic` AS `nck_lic`,`up`.`nck_cert` AS `nck_cert`,`up`.`kcse_cse` AS `kcse_cse`,`up`.`passport` AS `passport`,`ca`.`sponsorship_id` AS `sponsorship_id`,`ca`.`institution_id` AS `institution_id` from (((((`course_application` `ca` join `course_manager` `cm` on((`ca`.`course_id` = `cm`.`id`))) join `course_category` `cc` on((`cc`.`id` = `cm`.`category_id`))) left join `course_months` `cmos` on((`cmos`.`id` = `cm`.`month_id`))) left join `users` `u` on((`u`.`id` = `ca`.`student_id`))) left join `course_uploads` `up` on((`up`.`student_id` = `u`.`id`)));

DROP TABLE IF EXISTS `vw_master_course_app`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw_master_course_app` AS select `ca`.`id` AS `id`,`ca`.`payment_verified` AS `payment_verified`,`ca`.`sponsorship_type` AS `sponsorship_type`,`u`.`county` AS `county`,`cm`.`name` AS `course`,`cc`.`name` AS `category`,concat(`cmos`.`name`,'-',`ca`.`year`) AS `period`,`ca`.`status` AS `status`,`u`.`phone` AS `phone`,`u`.`gender` AS `gender`,`u`.`dob` AS `dob`,`u`.`id` AS `application_id`,concat_ws(' ',`u`.`first_name`,`u`.`middle_name`,`u`.`last_name`) AS `name`,`ca`.`created_at` AS `created_at`,floor(((to_days(curdate()) - to_days(`u`.`dob`)) / 365.25)) AS `age`,`up`.`national_id` AS `national_id`,`up`.`nck_lic` AS `nck_lic`,`up`.`nck_cert` AS `nck_cert`,`up`.`kcse_cse` AS `kcse_cse`,`up`.`passport` AS `passport`,`ca`.`sponsorship_id` AS `sponsorship_id`,`up`.`application_letter` AS `application_letter`,`up`.`dip_deg` AS `dip_deg`,`ca`.`comments` AS `comments`,`ca`.`institution_id` AS `institution_id` from (((((`course_application` `ca` join `course_manager` `cm` on((`ca`.`course_id` = `cm`.`id`))) join `course_category` `cc` on((`cc`.`id` = `cm`.`category_id`))) left join `course_months` `cmos` on((`cmos`.`id` = `cm`.`month_id`))) left join `users` `u` on((`u`.`id` = `ca`.`student_id`))) left join `course_uploads` `up` on((`up`.`student_id` = `u`.`id`))) where (`ca`.`sponsorship_type` = 'Self Sponsored');

-- 2025-05-06 06:22:52
